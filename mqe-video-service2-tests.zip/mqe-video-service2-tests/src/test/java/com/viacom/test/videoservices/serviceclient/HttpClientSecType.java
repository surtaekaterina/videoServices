package com.viacom.test.videoservices.serviceclient;

public enum HttpClientSecType {
	TRUST_SSL, COMMON_HTTP;
}
