package com.viacom.test.videoservices.tests.deliveryservice;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ContextExtractorParameterType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.UUID;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.constants.HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN;
import static com.viacom.test.videoservices.constants.HeaderConstants.CONTENT_TYPE;
import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.POST;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.ACCOUNT_MTV_COM;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.CDN.LEVEL_3;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.defineDebugHost;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.defineTShost;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMediaPlaylistLink;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.isDevEnv;
import static com.viacom.test.videoservices.utils.app.HostManager.getKeyServiceHost;
import static com.viacom.test.videoservices.utils.app.HostManager.getProxyHost;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class DeliveryCDNPositiveContentFromLevel3Test extends AbstractBaseTest {

    private static final int TS_COUNT = 5;

    private String TEST_NAME = "DeliveryTests/positive_flow_content_from_level3/" + UUID.randomUUID();

    private static String KEY_URI(String resolution) {
        return "KEY_URI_" + resolution;
    }

    private static String MEDIA_PLAYLIST_URI(String resolution) {
        return "MPL_" + resolution;
    }

    private static final String ACCOUNT_AND_CDN = "account=" + ACCOUNT_MTV_COM + "&cdn=" + LEVEL_3;

    private static final String MEDIA_URL_QUERY_PARAMETERS_DEV = "\\?" + ACCOUNT_AND_CDN;

    private static final String MEDIA_URL_QUERY_PARAMETERS_UAT_LIVE = "\\?tk=st=.*&" + ACCOUNT_AND_CDN;

    private String MEDIA_URL_QUERY_PARAMETERS = isDevEnv() ? MEDIA_URL_QUERY_PARAMETERS_DEV : MEDIA_URL_QUERY_PARAMETERS_UAT_LIVE;

    private VideoUrl videoUrl_1 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194055").setHashcode("2607552757").build();

    private VideoUrl videoUrl_2 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("320x240_2880_3streams_Main_29_97.mp4").setResolution("320x240").setBitrate("281456").setHashcode("1694877362").build();

    private VideoUrl videoUrl_3 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("480x360_5067_3streams_Main_29_97.mp4").setResolution("480x360").setBitrate("485528").setHashcode("329765914").build();

    private String DEBUG_INFO_MASTER_PLAYLIST = "################################################\n" +
            "#DEBUG-INFO\n" +
            "# STARTUP-BITRATE=600000\n" +
            "# CDN:" + LEVEL_3 + "\n" +
            "#REQUIRED:\n" +
            "# SIZE=3\n" +
            "# /" + videoUrl_1.getStreamUploadPath() + "\n" +
            "# /" + videoUrl_2.getStreamUploadPath() + "\n" +
            "# /" + videoUrl_3.getStreamUploadPath() + "\n" +
            "#DOWNLOADED:\n" +
            "# SIZE=3\n" +
            "# /" + videoUrl_1.getStreamUploadPath() + "\n" +
            "# /" + videoUrl_2.getStreamUploadPath() + "\n" +
            "# /" + videoUrl_3.getStreamUploadPath();

    private String DEBUG_INFO_MEDIA_PLAYLIST = "################################################\n" +
            "#DEBUG-INFO\n" +
            "# CP-CODE=mtv\n" +
            "# HOST=" + defineDebugHost(LEVEL_3, ACCOUNT_MTV_COM) + "\n" +
            "# PROVIDER=" + LEVEL_3;

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl_1, videoUrl_2, videoUrl_3);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForDeliveryCDNPositiveContentFromLevel3Test() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setHttpMethod(POST);
        test.setUrl(getProxyHost() + "proxy/addMessages");

        test.setPostbody(postBodyProxyAddMessage(videoUrl_1, videoUrl_2, videoUrl_3));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}"));

        testRequest(test, v.getAll());

        test.setUrl(getProxyHost() + "proxy/checkService");
        test.setPostbody(postBodyProxyCheckService(videoUrl_1, videoUrl_2, videoUrl_3));

        v = new Validators();
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"));
        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.renditions.length()", "3"));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS).until(new WaitForValidatorsPredicateImpl(test, v.getAll()));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("100387")
    @Test(groups = {DELIVERY})
    public void checkMasterDeliveryCDNPositiveContentFromLevel3Test() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistUrlWithToken(videoUrl_1, videoUrl_2, videoUrl_3));
        test.addParameter("account", ACCOUNT_MTV_COM);
        test.addParameter("cdn", LEVEL_3);
        test.addParameter("debug", "true");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*Created by Viacom Delivery Service.*\\s#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289[\\s\\S]*")); //check that first playlist is the list with AVERAGE-BANDWIDTH closest to 600kbps (default value)

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=227171,BANDWIDTH=258197,FRAME-RATE=15,CODECS=\"avc1.42C00C,mp4a.40.5\",RESOLUTION=384x216"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=360453,BANDWIDTH=437994,FRAME-RATE=29.97,CODECS=\"avc1.4D401E,mp4a.40.2\",RESOLUTION=320x240"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289,BANDWIDTH=644220,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=480x360"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, DEBUG_INFO_MASTER_PLAYLIST));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_1).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_2).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_3).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));

        ContextExtractorParameterType e1 = new ContextExtractorParameterType();
        e1.setName(MEDIA_PLAYLIST_URI("384x216"));
        e1.setRegex(getMediaPlaylistLink(videoUrl_1) + ".*");

        ContextExtractorParameterType e2 = new ContextExtractorParameterType();
        e2.setName(MEDIA_PLAYLIST_URI("320x240"));
        e2.setRegex(getMediaPlaylistLink(videoUrl_2) + ".*");

        ContextExtractorParameterType e3 = new ContextExtractorParameterType();
        e3.setName(MEDIA_PLAYLIST_URI("480x360"));
        e3.setRegex(getMediaPlaylistLink(videoUrl_3) + ".*");

        test.setContextextractor(getContextExtractors(of(e1, e2, e3)));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("100387")
    @Test(groups = {DELIVERY}, dependsOnMethods = "checkMasterDeliveryCDNPositiveContentFromLevel3Test")
    public void checkMediaDeliveryCDNPositiveContentFromLevel3Test() {
        of(videoUrl_1, videoUrl_2, videoUrl_3).forEach(this::checkMediaPlaylist);
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("100387")
    @Test(groups = {DELIVERY}, dependsOnMethods = "checkMediaDeliveryCDNPositiveContentFromLevel3Test")
    public void checkKeysDeliveryCDNPositiveContentFromLevel3Test() {
        of("384x216", "320x240", "480x360").forEach(this::checkKey);
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("100387")
    @Test(groups = {DELIVERY}, dependsOnMethods = "checkMediaDeliveryCDNPositiveContentFromLevel3Test")
    public void checkTSsDeliveryCDNPositiveContentFromLevel3Test() {
        of(videoUrl_1, videoUrl_2, videoUrl_3).forEach(this::checkTSs);
    }

    private void checkMediaPlaylist(VideoUrl videoUrl) {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext(MEDIA_PLAYLIST_URI(videoUrl.getResolution())));
        test.addParameter("debug", "true");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-PLAYLIST-TYPE:VOD"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-INDEPENDENT-SEGMENTS"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-TARGETDURATION:6"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-MEDIA-SEQUENCE:0"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-ENDLIST"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                String.format("#EXT-X-KEY:METHOD=AES-128,URI=\"%sget/encrypt.key?acl=%s&tk=", getKeyServiceHost(), videoUrl.getUploadPath())));

        for (int i = 0; i < TS_COUNT; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, defineTShost(LEVEL_3, ACCOUNT_MTV_COM) + videoUrl.getTsUploadPathByIndex(i)));
        }

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, DEBUG_INFO_MEDIA_PLAYLIST));


        ContextExtractorParameterType e1 = new ContextExtractorParameterType();
        e1.setName(KEY_URI(videoUrl.getResolution()));
        e1.setRegex(getKeyServiceHost() + ".*(?=\\\")");

        test.setContextextractor(getContextExtractors(of(e1)));

        testRequest(test, v.getAll());
    }

    private void checkKey(String resolution) {
        Validators v = new Validators();

        String url = testContext.getValueFromContext(KEY_URI(resolution));
        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/octet-stream"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, "Content-Length", "16"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.NOT_EQUALS, ""));

        TestType test = new TestType();
        test.setIsReadByteResponse(true);
        test.setUrl(url);

        testRequest(test, v.getAll());
    }

    private void checkTSs(VideoUrl videoUrl) {
        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "video/mp2t"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        TestType test = new TestType();
        test.setUrl(defineTShost(LEVEL_3, ACCOUNT_MTV_COM) + videoUrl.getTsUploadPathByIndex(0));
        testRequest(test, v.getAll());

        test.setUrl(defineTShost(LEVEL_3, ACCOUNT_MTV_COM) + videoUrl.getTsUploadPathByIndex(TS_COUNT - 1));
        testRequest(test, v.getAll());
    }
}