package com.viacom.test.videoservices.tests.mediagen.qa.inspectmedia;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HeaderType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.INSPECT_MEDIA_QA;

public class Test_VS_1676_cognik_partner_forbidden extends AbstractBaseTest {

    @Features(INSPECT_MEDIA_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26238")
    @Test(groups = {INSPECT_MEDIA_QA})
    @Description("VS-1676 cognik partner forbidden")
    public void test_VS_1676_cognik_partner_forbidden() {
        TestType test = new TestType();

        test.setUrl("services/InspectMedia/cognik/mtv.com/mgid:arc:video:mtv.com:15c54f02-5666-48f1-9260-5483d8a3f048");


        test.setNetwork("origin");


        test.addHeader(new HeaderType("True-Client-IP", "69.164.2.12"));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleTypes = new ArrayList<>();
        statusLineValidatorRuleTypes.add(new StatusLineValidatorRuleType("403", null, "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(statusCodeValidator);

        testRequest(test, validators);
    }
}