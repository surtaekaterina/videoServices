package com.viacom.test.videoservices.constants;

public final class HeaderConstants {

	private HeaderConstants() {
	}

	public static final String X_CDN_L3_ACCESS_HEADER = "X-CDN-L3-Access";

	public static final String X_CDN_L3_ACCESS_VALUE = "MG4PBdnyBqmaR2eQltoW7yf1UDHjVgLU2O";

	public static final String X_VIA_PURGE_KEY = "X-VIA-PURGE-KEY";

	public static final String X_VIA_PURGE_KEY_VALUE = "1r41jvbeledanudgou3ae8a2e9rkuplujkkm7uipetjq8uilehi6";

	public static final String REFERER = "Referer";

	public static final String HUDSON_REFERER_VALUE = "http://hudson.mtvi.com/hudson/view/MediaServices/job/pkg-tests/";

	public static final String HOST = "host";

	public static final String USER_AGENT = "User-Agent";

	public static final String CONTENT_TYPE = "Content-Type";

    public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

    public static final String CONTENT_TYPE_VALUE_VIDEO = "video/";

    public static final String CONTENT_TYPE_IMAGE_JPEG = "image/jpeg";

	public static final String CONTENT_TYPE_VALUE_STREAM = "application/octet-stream";

	public static final String CONTENT_TYPE_VALUE_JSON = "application/json";

	public static final String CONTENT_TYPE_VALUE_AUDIO = "video/MP2T";

	public static final String VALUE_OF_USER_AGENT_FIREFOX = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1";

	public static final String X_SECURITY_KEY = "X-SECURITY-KEY";

	public static final String X_CACHE_KEY = "X-Cache-Key";

    public static final String PRAGMA_HEADER = "Pragma";

    public static final String PRAGMA_VALUE = "akamai-x-cache-on, akamai-x-cache-remote-on, akamai-x-check-cacheable, akamai-x-get-cache-key, akamai-x-get-extracted-values, akamai-x-get-nonces, akamai-x-get-ssl-client-session-id, akamai-x-get-true-cache-key, akamai-x-serial-no";

	public static final String X_SECRET_PRAGMA_HEADER = "X-Secret-Pragma";

	public static final String X_SECRET_PRAGMA_VALUE = "9a33243a-f580-4348-b0c1-6b2c2855e0de";

	public static final String VALID_X_SECURITY_KEY_1 = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzUxMiJ9.eyJpc3MiOiJQa2dTdmMiLCJpYXQiOjE0OTI1MDU5MzF9.bXrvIdcosCaawX5a4H9YPD5w_1YAdOOvJ4whb0oMsJfDwqsLJB0VyAOveqWmyKO6K30V6XXmGoq4DRRReuS7lHRI4__hl6uDnZ7gm4ZHOHs_rIFIh-iw2lvOM_YTsLeJZUWJdxGAePUXYXgfJoRz88wyUsHWc-8T1A3GTshngoySnc0OuXVn4kfnOETerYgJpDybQz2TsNugWzY84UXtYPW80zrahWGd7xD51M_L2raoH8ZgZ8KHL6Dk8-SRZjby2Oe7sW797_pN8w9-y7U50AnRD__W4jKldr5htsSGHc67EnzepS1s4Fslc99XGoQRO1HAmyKEcEig_epu75HbsQ";

	public static final String VALID_X_SECURITY_KEY_2 = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzUxMiJ9.eyJpc3MiOiJQa2dTdmMiLCJpYXQiOjE1MDE2ODA4MjJ9.EGoLmHZNJe20wkFRrG-wN4WQbbo31JHNVlDZ2aa670fvswuN5NTblKsL1Ip4GtZUyutnZntvzynkVN00dsEqnRL44wrjvsbOF2FVk0VkeA7vnqw-vbjWNWubOiVvO3XiZ_cFwgEDg72iutSr9Hz0ToRWSWcIMleykF4yDt6ZEyeKP_jnoXiqBH8Lg23yLGwdC4DM34WGBzD8LiudkW-ZovIEHnesvXGgOXs2ANsYzr-JpwLhhXsE7YBvwkj5StN_8xhozlpwQJtTGNyj3KChW3cV0BSPMQifEhxLe2arbw_eMPW4y3Pt-DkYqLIc7idV09-Suxui-_QKXK-HNvFp4w";

	public static final String INVALID_X_SECURITY_KEY = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzUxMiJ9.eyJpc3MiOiJQa2dTdmMiLCJleHAiOjE1MDExNjAyNzEsImlhdCI6MTUwMTE1OTY3MX0.HiVvdCwA70y9NK9swncVdCMKKspeKCLv43rm7kWL4twWruUERUPaNek0YsM18LTzqCG3ajXfPMMX9aLw_ZBWnAneTfqoTqF9dbO0OJ7C_rHJl5IVgUbr4czY0iliNdSLytdkmjW-tD4tMg7BtxnJ7lGbslADnPJiJx_OHHt75FlPtyn_ERW-_NkIhjmFSQ4cwmypENpNCd9qANDNJny2uZ3MLw620_laHXDlpmL0jWiyHXDdaAtEsrAI6LPGv3Wt66AyL16HbMoIikCE9MR1569VQ2lP1GAqaq8y5XsFPL9shL8kc4tHu5POR24fX1UYJ44bAq8OqmHlGD010KsBoQ";

	public static final String EXPIRED_X_SECURITY_KEY = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzUxMiJ9.eyJpc3MiOiJQa2dTdmMiLCJleHAiOjE1MDExNjAyNzEsImlhdCI6MTUwMTE1OTY3MX0.HiVvdCwA70y9NK9swncVdCMKKspeKCLv43rm7kWL4twWruUERUPaNek0YsM18LTzqCG3ajXfPMMX9aLw_ZBWnAneTfqoTqF9dbO0OJ7C_rHJl5IVgUbr4czY0iliNdSLytdkmjW-tD4tMg7BtxnJ7lGbslADnPJiJx_OHHt75FlPtyn_ERW-_NkIhjmFSQ4cwmypENpNCd9qANDNJny2uZ3MLw620_laHXDlpmL0jWiyHXDdaAtEsrAI6LPGv3Wt66AyL16HbMoIikCE9MRjlgaVQ2lP1GAqaq8y5XsFPL9shL8kc4tHu5POR24fX1UYJ44bAq8OqmHlGD010KsBoQ";
}
