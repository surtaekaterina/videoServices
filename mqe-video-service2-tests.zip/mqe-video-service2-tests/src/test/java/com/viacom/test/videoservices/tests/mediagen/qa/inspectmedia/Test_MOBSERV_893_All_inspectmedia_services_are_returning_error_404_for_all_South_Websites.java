package com.viacom.test.videoservices.tests.mediagen.qa.inspectmedia;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.INSPECT_MEDIA_QA;

public class Test_MOBSERV_893_All_inspectmedia_services_are_returning_error_404_for_all_South_Websites extends AbstractBaseTest {

    @Features(INSPECT_MEDIA_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26367")
    @Test(groups = {INSPECT_MEDIA_QA})
    @Description("MOBSERV-893 All inspectmedia services are returning error 404 for all South Websites")
    public void test_MOBSERV_893_All_inspectmedia_services_are_returning_error_404_for_all_South_Websites() {
        TestType test = new TestType();

        test.setUrl("services/InspectMedia/dailymotion/nickelodeonjunior.fr/mgid:uma:video:nickelodeonjunior.fr:881167");

        test.setSetFollowRedirects(false);


        test.addParameter(new ParameterType("bypass", "true"));


        List<StatusLineValidatorRuleType> statusLineValidatorRuleTypes = new ArrayList<>();
        statusLineValidatorRuleTypes.add(new StatusLineValidatorRuleType("404", null, "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(statusCodeValidator);

        testRequest(test, validators);
    }
}