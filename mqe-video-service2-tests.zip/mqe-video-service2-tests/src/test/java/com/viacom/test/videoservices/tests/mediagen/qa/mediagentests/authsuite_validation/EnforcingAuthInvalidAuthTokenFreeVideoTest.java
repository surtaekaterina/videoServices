package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.authsuite_validation;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class EnforcingAuthInvalidAuthTokenFreeVideoTest extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(BLOCKER)
    @TestCaseId("22137870")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description("VS-5487: Enforcing Auth for the Namespace (enforceAuth:true, enableAuthLogging:false) - AuthToken is available for the request but invalid")

    public void checkAuthSuiteValidationForEnforcingAuthInvalidAuthTokenFreeVideoTest() {

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:noggin.us:c861c791-bf69-47cd-97b9-1f829ab280d7");

        test.addParameter("accountOverride", "nickjr.com");
        test.addParameter("ep", "2527aaac");
        test.addParameter("geo", "US");
        test.addParameter("arcStage", "authoring");
        test.addParameter("device", "iPad");
        test.addParameter("authPlatform", "ios");
        test.addParameter("nodp", "true");

        test.addHeader("X-VIA-TVE-MEDIATOKEN", "invalidAuthTokenValue");

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.NOT_CONTAINS, XpathConstantType.NODE, "*//item", "Error - Auth failed or missing"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//rendition"));

        testRequest(test, v.getAll());

    }

}
