package com.viacom.test.videoservices.model.test.types;

import java.util.ArrayList;
import java.util.List;

import com.viacom.test.videoservices.model.test.Validator;

public class VideoQualityValidatorType extends Validator {
	
	private String streamUrl;
	private List<HeaderType> headers;
	protected List<VideoQualityValidatorRuleType> rules;
	
	public VideoQualityValidatorType(String streamUrl, List<HeaderType> headers, List<VideoQualityValidatorRuleType> rules) {
		this.streamUrl = streamUrl;
		this.headers = headers;
		this.rules = rules;
	}
	
	public String getStreamUrl() {
		return streamUrl;
	}

	public void setStreamUrl(String streamUrl) {
		this.streamUrl = streamUrl;
	}
	
	public List<HeaderType> getHeaders() {
		return headers;
	}

	public void setHeaders(List<HeaderType> headers) {
		this.headers = headers;
	}

    @SuppressWarnings("unchecked")
	public List<VideoQualityValidatorRuleType> getRule() {
        if (rules == null) {
        	rules = new ArrayList<VideoQualityValidatorRuleType>();
        }
        return this.rules;
    }

}
