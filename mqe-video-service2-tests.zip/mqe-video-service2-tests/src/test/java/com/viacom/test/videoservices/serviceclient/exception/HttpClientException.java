package com.viacom.test.videoservices.serviceclient.exception;

public class HttpClientException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -717569467749571132L;

	public HttpClientException(String message) {
		super(message);
	}

	public HttpClientException(String message, Throwable e) {
		super(message, e);
	}

}
