package com.viacom.test.videoservices.tests.deliveryservice;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType.EQUALS;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_2;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class DeliveryApiStatusTest extends AbstractBaseTest {

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("102278")
    @Test(groups = {DELIVERY, DELIVERY_2})
    public void deliveryApiStatusTest() {
        TestType test = new TestType();

        test.setUrl("api/status");

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new JsonPathValidatorRuleType(EQUALS, "$.message", "passed"));
        v.add(new JsonPathValidatorRuleType(EQUALS, "$.services.packager.message", "passed"));
        v.add(new JsonPathValidatorRuleType(EQUALS, "$.services.netstorage.message", "passed"));
        v.add(new JsonPathValidatorRuleType(EQUALS, "$.services.redis.message", "passed"));

        testRequest(test, v.getAll());
    }
}
