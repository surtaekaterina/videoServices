package com.viacom.test.videoservices.listeners;

import com.viacom.test.core.lab.Logger;
import com.viacom.test.core.report.AllureManager;
import com.viacom.test.core.report.TestRailManager;
import com.viacom.test.videoservices.utils.AppLib;
import com.viacom.test.videoservices.utils.IProps.ConfigProps;
import com.viacom.test.videoservices.utils.app.MediagenHostUtils;
import org.testng.IExecutionListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestNGMethod;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.LinkedHashMap;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;

import static com.viacom.test.videoservices.utils.IProps.ConfigProps.LOCAL_RUN;
import static com.viacom.test.videoservices.utils.IProps.ConfigProps.TESTRAIL_PROJECT_ID;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_RELATED_GROUPS;
import static com.viacom.test.videoservices.utils.IProps.StaticProps.TEST_ID;
import static java.util.stream.Collectors.toList;

public class SuiteListener implements ISuiteListener, IExecutionListener {

    private AllureManager allureManager;

    @Override
    public void onStart(ISuite iSuite) {
        System.setProperty("allure.max.title.length", "10000");

        Logger.disableLog4JConsoleOutput();

        if (!LOCAL_RUN) {
            allureManager = new AllureManager();

            List<String> allTestCaseIDs = iSuite.getAllMethods().stream()
                    .map(iTestNGMethod -> iTestNGMethod.getConstructorOrMethod().getMethod().getAnnotation(TestCaseId.class))
                    .filter(Objects::nonNull).map(TestCaseId::value)
                    .flatMap(id -> Pattern.compile("-").splitAsStream(id))
                    .distinct().collect(toList());

            if (!allTestCaseIDs.isEmpty()) {
                TestRailManager.startNewSuiteRun(iSuite.getName(), TESTRAIL_PROJECT_ID, allTestCaseIDs);
            }
        }

        for (ITestNGMethod method : iSuite.getAllMethods()) {
            String[] testGroups = method.getConstructorOrMethod().getMethod().getAnnotation(Test.class).groups();
            if (Arrays.stream(testGroups).anyMatch(MEDIAGEN_RELATED_GROUPS::contains)) {
                MediagenHostUtils.identifyEndpointType();
                break;
            }
        }
    }

    @Override
    public void onFinish(ISuite iSuite) {
        if (!LOCAL_RUN) {
            Set<String> groupsOfSuite = iSuite.getMethodsByGroups().keySet();
            String groups = String.join(",", groupsOfSuite);

            LinkedHashMap<String, String> envProps = new LinkedHashMap<>();
            envProps.put(groups, ConfigProps.ENV_OF_INITIAL_ENDPOINT);

            allureManager.createAllurePropertyFile(envProps)
                    .setSuiteName(groups)
                    .removePendingTests()
                    .setBrokenTestsToFailures()
                    .setRepeatsBrokenOnSuccess()
                    .setTestNamesFromTestIDs(TEST_ID.toLowerCase())
                    .generateReport();

            // upload report to s3
            String s3ReportUrl = null;
            if (ConfigProps.UPLOAD_REPORT_S3) {
                s3ReportUrl = allureManager.uploadReportToS3();
                Logger.logMessage("Test report: " + s3ReportUrl);
            }

            // get the test counts
            Integer passCount = allureManager.getTestPassedCount();
            Integer failCount = allureManager.getTestFailureCount();
            Integer skipCount = allureManager.getTestSkippedCount();

            // send auto email and chat
            if (ConfigProps.SEND_REPORT_EMAILS) {
                AppLib.sendResultEmail(s3ReportUrl, groups, passCount, failCount, skipCount);
            }
            if (ConfigProps.SEND_REPORT_CHAT) {
                AppLib.sendResultHipChat(s3ReportUrl, passCount, failCount, skipCount);
            }
        }
    }

    @Override
    public void onExecutionStart() {
    }

    @Override
    public void onExecutionFinish() {
    }

}