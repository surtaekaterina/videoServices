package com.viacom.test.videoservices.constants;

public class URLConstants {

    private URLConstants() {
    }

    public static final String HTTP = "http://";

    public static final String HTTPS = "https://";

    public static final String FTP = "ftp://";

    public static final String S3_PACKAGER_AUTOTEST_PATH = "s3.amazonaws.com/mtvnet-seamless/qa-artifacts/HLS_statick_packager/packagerTestVideos/autoTests";

    public static final String S3_PACKAGER_AUTOTEST_FOLDER_PATH = HTTP + S3_PACKAGER_AUTOTEST_PATH;

    public static final String S3_SMALLEST_MP4_FILE_URL = S3_PACKAGER_AUTOTEST_FOLDER_PATH + "/384x216_278_30sec.mp4";
}
