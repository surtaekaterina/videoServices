package com.viacom.test.videoservices.tests;

import com.viacom.test.videoservices.model.test.types.HeaderType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.constants.HeaderConstants.VALID_X_SECURITY_KEY_1;
import static com.viacom.test.videoservices.constants.HeaderConstants.X_SECURITY_KEY;

public class HlsDeliveryServicesStatusTest extends AbstractBaseTest {

    private static final String PACKAGER_URL = "http://origin.hlspkg-uat.mtvnservices.com/packager/status";
    private static final String PROXY_URL = "http://origin.hlspkg-uat.mtvnservices.com/proxy/status";
    private static final String DLVR_URL = "http://dlvrsvc.mtvnservices.com/api/status";
    private static final String KEY_SERVICE_URL = "http://origin.keysvc-uat.mtvnservices.com/api/version";

    //private static final String PACKAGER_RP = "^\\{\"message\":\"passed\",\"version\":\"1.0.9\",\"services\":\\{\"mongodb\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3}},\"sqs\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3},\"messagesInQueue\":\"0\"\\},\"key-services\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3}},\"netstorage\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3}\\}\\}\\}$";

    private static final String PACKAGER_RP = "^\\{\"message\":\"passed\",\"version\":\"1.0.9\".*";
    private static final String PROXY_RP = "^\\{\"message\":\"passed\",\"version\":\"1.0.6\",\"services\":\\{\"redis\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3}\\},\"sqs\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3}\\},\"mongodb\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3}\\}\\}\\}$";
    private static final String DLVR_RP = "\\{\"message\":\"passed\",\"version\":\"1.[\\d]{1}(-SNAPSHOT)?\",\"services\":\\{\"packager\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3}},\"netstorage\":\\{\"message\":\"passed\",\"time\":[\\d]{1,3}\\}\\}\\}";
    private static final String KEY_SERVICE_RP = "^The current version is 1.[\\d]{1}(-SNAPSHOT)?$";


    @DataProvider(name = "data", parallel = true)
    public static Object[][] playersDataProvider() {
        return new Object[][]{
                new Object[]{PACKAGER_URL, PACKAGER_RP},
                new Object[]{PROXY_URL, PROXY_RP},
                new Object[]{DLVR_URL, DLVR_RP},
                new Object[]{KEY_SERVICE_URL, KEY_SERVICE_RP}
        };
    }

    @Test(groups = "hlsstatus", dataProvider = "data")
    public void test(String url, String rpPattern) {
        go(url, rpPattern);
    }

    private void go(String url, String rpPattern) {
        TestType test = new TestType();

        test.setUrl(url);

        test.addHeader(new HeaderType(X_SECURITY_KEY, VALID_X_SECURITY_KEY_1));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, rpPattern));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        testRequest(test, of(statusCodeValidator, textValidator));
    }
}
