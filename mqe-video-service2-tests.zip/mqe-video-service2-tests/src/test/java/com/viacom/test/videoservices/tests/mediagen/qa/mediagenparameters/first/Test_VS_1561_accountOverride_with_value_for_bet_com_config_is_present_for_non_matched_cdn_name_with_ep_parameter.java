package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.first;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathConstantType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.RegionUtils;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class Test_VS_1561_accountOverride_with_value_for_bet_com_config_is_present_for_non_matched_cdn_name_with_ep_parameter extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(BLOCKER)
    @TestCaseId("26158")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-1561: accountOverride with value for bet.com config is present for non matched cdn name with ep parameter")
    public void test_VS_1561_accountOverride_with_value_for_bet_com_config_is_present_for_non_matched_cdn_name_with_ep_parameter() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl("services/MediaGenerator/mgid:arc:video:mtvplay.com:ce743124-2790-4c7f-a0de-12ffc69a38bb");
        //test.setNetwork("akamai");

        test.addParameter("accountOverride", "spike.com");
        test.addParameter("pkgOverride", "akamaidynpkg");
        test.addParameter("device", "iPad");
        test.addParameter("ep", "f4973205");

        test.addHeader("X-Forwarded-For", RegionUtils.getIP("br"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "https://cp477482-vh.akamaihd.net"));
        v.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//item/rendition"));

        testRequest(test, v.getAll());
    }

}