package com.viacom.test.videoservices.model.test.types;

public enum VideoQualityRuleNameType {

    VIDEO("video"), AUDIO("audio"), FORMAT("format"), DATA("data");

    private String streamName;
    
    private VideoQualityRuleNameType(String streamName) {
        this.streamName = streamName;
    }

    public String getStreamName() {
        return this.streamName;
    }
}
