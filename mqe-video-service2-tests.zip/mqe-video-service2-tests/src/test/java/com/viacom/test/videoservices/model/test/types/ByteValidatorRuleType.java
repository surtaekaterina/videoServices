package com.viacom.test.videoservices.model.test.types;

import com.viacom.test.videoservices.model.test.Rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ByteValidatorRuleType")
public class ByteValidatorRuleType extends Rule {

    @XmlAttribute(required = true)
    protected ByteValidatorRuleNameType name;
    @XmlAttribute(required = true)
    protected byte [] value;

    public ByteValidatorRuleType() {
    }

    public ByteValidatorRuleType(ByteValidatorRuleNameType name, byte [] value) {
        this.name = name;
        this.value = value;
    }

    public ByteValidatorRuleNameType getName() {
        return name;
    }

    public void setName(ByteValidatorRuleNameType value) {
        this.name = value;
    }

    public byte [] getValue() {
        return value;
    }

    public void setValue(byte [] value) {
        this.value = value;
    }

}
