package com.viacom.test.videoservices.tests.deliveryservice;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import com.viacom.test.videoservices.utils.app.HostManager;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class DeliveryCDNWithoutAccountParameterTest extends AbstractBaseTest {
    private String TEST_NAME = "DeliveryTests/flow_without_account_parameter/" + UUID.randomUUID();

    private VideoUrl videoUrl_1 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194055").setHashcode("2607552757").build();

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl_1);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForDeliveryCDNWithoutAccountParameterTest() {
        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);
        test.setUrl(HostManager.getProxyHost() + "proxy/addMessages");

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(postBodyProxyAddMessage(videoUrl_1));
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);


        test.setUrl(HostManager.getProxyHost() + "proxy/checkService");

        postBodyType.setString(postBodyProxyCheckService(videoUrl_1));
        test.setPostbody(postBodyType);

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS)
                .until(new WaitForValidatorsPredicateImpl(test, of(new TextValidatorType(of(
                        new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"))))));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("103676")
    @Test(groups = {DELIVERY})
    @Description(value = "https://jira.mtvi.com/browse/VS-5019")
    public void checkMasterDeliveryCDNWithoutAccountParameterTest() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistUrlWithToken(videoUrl_1));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("400", "Bad Request", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"errors\":[\"Bad request. Media urls could not be created due to missing CDN configurations for the account\"]}"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }
}
