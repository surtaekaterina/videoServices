package com.viacom.test.videoservices.tests.mediagen.qa.inspectmedia;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorType;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.INSPECT_MEDIA_QA;

public class Test_MOBSERV_950_InspectMedia_response_code_200_successful_ORIGIN_ONLY extends AbstractBaseTest {

    @Features(INSPECT_MEDIA_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26416")
    @Test(groups = {INSPECT_MEDIA_QA})
    @Description("MOBSERV-950 InspectMedia response code = 200, successful (ORIGIN ONLY)")
    public void test_MOBSERV_950_InspectMedia_response_code_200_successful_ORIGIN_ONLY() {
        TestType test = new TestType();

        test.setUrl("services/InspectMedia/dailymotion/nickelodeonjunior.fr/mgid:uma:video:nickelodeonjunior.fr:881167");


        test.setNetwork("origin");

        test.addParameter(new ParameterType("metadata", "true"));


        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, "Edge-control", "cache-maxage=30m,!no-store"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<Validator> validators = new ArrayList<>();

        validators.add(headerValidator);

        testRequest(test, validators);
    }
}