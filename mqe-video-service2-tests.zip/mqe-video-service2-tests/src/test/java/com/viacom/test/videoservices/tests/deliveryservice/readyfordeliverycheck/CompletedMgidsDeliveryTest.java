package com.viacom.test.videoservices.tests.deliveryservice.readyfordeliverycheck;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.HostManager;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyDlvrApiCheck;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class CompletedMgidsDeliveryTest extends AbstractBaseTest {

    private static final String UNIQUE_ID = "CompletedMgidsDeliveryTest" + UUID.randomUUID().toString();

    private static VideoUrl videoUrl1 = new VideoUrl.Builder().setNamespaceAndUploadPathWithoutS3path(UNIQUE_ID + "/1")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").setBitrate("403057").setHashcode("3469779259")
            .build();

    private static VideoUrl videoUrl2 = new VideoUrl.Builder().setNamespaceAndUploadPathWithoutS3path(UNIQUE_ID + "/2")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").setBitrate("403057").setHashcode("3469779259")
            .build();

    private static VideoUrl videoUrl3 = new VideoUrl.Builder().setNamespaceAndUploadPathWithoutS3path(UNIQUE_ID + "/3")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").setBitrate("403057").setHashcode("3469779259")
            .build();

    @AfterClass
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl1, videoUrl2, videoUrl3);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForCompletedMgidsDeliveryTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(HostManager.getProxyHost() + "proxy/addMessages");
        test.setHttpMethod(HttpMethodNameType.POST);
        test.setPostbody(postBodyProxyAddMessage(videoUrl1, videoUrl2, videoUrl3));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}||\"message\":\"All messages have already been queued"));

        testRequest(test, v.getAll());

        test.setUrl(HostManager.getProxyHost() + "proxy/checkService");
        test.setPostbody(postBodyProxyCheckService(videoUrl1, videoUrl2, videoUrl3));

        v = new Validators();
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"));
        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.renditions.length()", "3"));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS).until(new WaitForValidatorsPredicateImpl(test, v.getAll()));
    }


    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("25936")
    @Test(groups = {DELIVERY})
    public void checkCompletedWorkflowsDeliveryTest() {

        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);

        test.setUrl(HostManager.getDeliveryOriginHost() + "api/check");

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(postBodyDlvrApiCheck(videoUrl1, videoUrl2, videoUrl3));
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"ref\":\"" + videoUrl1.getNamespaceDecoded() + "\",\"path\":\"/" + videoUrl1.getStreamUploadPath() + "\",\"iframe\":\"/" + videoUrl1.getIFrameUploadPath() + "\"}"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"ref\":\"" + videoUrl2.getNamespaceDecoded() + "\",\"path\":\"/" + videoUrl2.getStreamUploadPath() + "\",\"iframe\":\"/" + videoUrl2.getIFrameUploadPath() + "\"}"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"ref\":\"" + videoUrl3.getNamespaceDecoded() + "\",\"path\":\"/" + videoUrl3.getStreamUploadPath() + "\",\"iframe\":\"/" + videoUrl3.getIFrameUploadPath() + "\"}"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }
}
