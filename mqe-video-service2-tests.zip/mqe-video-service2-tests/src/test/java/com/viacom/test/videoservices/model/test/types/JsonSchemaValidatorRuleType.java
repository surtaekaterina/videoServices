package com.viacom.test.videoservices.model.test.types;

import com.viacom.test.videoservices.model.test.Rule;

public class JsonSchemaValidatorRuleType extends Rule {

	protected JsonSchemaValidatorRuleNameType name;
	protected String pathToJsonSchema;
	
	public JsonSchemaValidatorRuleType() {		
	}

	public JsonSchemaValidatorRuleType(JsonSchemaValidatorRuleNameType name, String pathToJsonSchema) {
		this.name = name;
		this.pathToJsonSchema = pathToJsonSchema;
	}
	
	public JsonSchemaValidatorRuleNameType getName() {
		return name;
	}

	public String getPathToJsonSchema() {
		return pathToJsonSchema;
	}
}
