package com.viacom.test.videoservices.model.test.types;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * <p>
 * Java class for HttpMethodNameType.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * <p>
 * 
 * <pre>
 * &lt;simpleType name="HttpMethodNameType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="exist"/>
 *     &lt;enumeration value="not exist"/>
 *     &lt;enumeration value="contains"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlEnum
public enum HttpMethodNameType {

	@XmlEnumValue("GET") GET("GET"),
	@XmlEnumValue("POST") POST("POST"),
	@XmlEnumValue("HEAD") HEAD("HEAD"),
	@XmlEnumValue("OPTIONS") OPTIONS("OPTIONS"),
	@XmlEnumValue("DELETE") DELETE("DELETE");
	private final String value;

	HttpMethodNameType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static HttpMethodNameType fromValue(String v) {
		for (HttpMethodNameType c : HttpMethodNameType.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v.toString());
	}
}
