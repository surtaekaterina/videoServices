package com.viacom.test.videoservices.model.test.types;

import java.util.ArrayList;
import java.util.List;

import com.viacom.test.videoservices.model.test.Validator;

public class JsonComparisonValidatorType extends Validator {

	protected List<JsonComparisonValidatorRuleType> rule;
	
	public JsonComparisonValidatorType(List<JsonComparisonValidatorRuleType> rule) {
		this.rule = rule;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<JsonComparisonValidatorRuleType> getRule() {
		if (rule == null) {
			rule = new ArrayList<JsonComparisonValidatorRuleType>();
		}
		return this.rule;
	}

}
