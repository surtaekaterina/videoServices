package com.viacom.test.videoservices.tests.deliveryservice.submit;

import com.viacom.test.core.lab.Logger;
import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HeaderType;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.serviceclient.Endpoint;
import com.viacom.test.videoservices.serviceclient.Response;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.PropertyUtils;
import com.viacom.test.videoservices.utils.app.HostManager;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.test.TestContext;
import com.viacom.test.videoservices.utils.test.TestTypeUtils;
import com.viacom.test.videoservices.validation.ValidatorExecution;
import org.testng.Assert;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyDlvrApiSubmit;

public class SubmitVideoContentTypeHeaderMissingTest extends AbstractBaseTest {

    private static final String HEADER_PROPERTIES_PATH = "src/test/resources/header.properties";
    private static final String CONTENT_TYPE_HEADER_NAME = "Content-Type";

    private static final String EXPECTED_RP_BODY = "{\"errors\":[\"videos: field is required\"]}";

    private VideoUrl videoUrl = new VideoUrl.Builder().setNamespaceAndUploadPathWithoutS3path("SubmitVideoContentTypeHeaderMissingTest")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").build();

    @Features(DELIVERY)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25962")
//26040
    @Test(groups = {DELIVERY})
    public void submitVideoContentTypeHeaderMissingTest() {
        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);

        test.setUrl(HostManager.getDeliveryOriginHost() + "api/submit");

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(postBodyDlvrApiSubmit(videoUrl));
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("400", "Bad Request", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.EQUALS, EXPECTED_RP_BODY));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        String url = Endpoint.buildUrl(test.getUrl());
        test.setUrl(testContext.processValue(url));

        processHeadersByTestContext(test.getHeader(), testContext);
        processPostBodyByTestContext(test.getPostbody(), testContext);

        Map<String, String> headers = PropertyUtils.getProperties(HEADER_PROPERTIES_PATH, false);
        headers.remove(CONTENT_TYPE_HEADER_NAME);
        addHeadersFromMapToTestHeaders(headers, test.getHeader());

        Response response = TestTypeUtils.executeHttpRequest(test);
        String validateMessage = ValidatorExecution.execute(validators, response);
        if (!validateMessage.isEmpty()) {
            Assert.fail(validateMessage);
        }
    }

    private void processHeadersByTestContext(List<HeaderType> headers, TestContext testContext) {
        if (headers == null || headers.isEmpty()) {
            return;
        }

        for (HeaderType h : headers) {
            h.setName(h.getName());
            h.setValue(testContext.processValue(h.getValue()));
            Logger.logMessage("Request has header - " + h.getName() + " : " + h.getValue());
        }
    }

    private void processPostBodyByTestContext(PostBodyType postBodyType, TestContext testContext) {
        if (null != postBodyType && null != postBodyType.getString()) {
            postBodyType.setString(testContext.processBody(postBodyType.getString()));
        }
    }

    private void addHeadersFromMapToTestHeaders(Map<String, String> headers, List<HeaderType> testHeaders) {
        if (null == headers || headers.isEmpty() || null == testHeaders) {
            return;
        }

        List<String> nameOfHeadersInTest = testHeaders.stream().map(HeaderType::getName).collect(Collectors.toList());
        for (Map.Entry<String, String> headerEntry : headers.entrySet()) {
            String headerName = headerEntry.getKey();
            String headerValue = headerEntry.getValue();
            if (!nameOfHeadersInTest.contains(headerName)) {
                testHeaders.add(new HeaderType(headerName, headerValue));
            }
        }
    }

}
