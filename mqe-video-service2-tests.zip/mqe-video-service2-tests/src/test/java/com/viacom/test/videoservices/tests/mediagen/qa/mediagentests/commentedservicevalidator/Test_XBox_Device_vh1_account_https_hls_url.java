package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.commentedservicevalidator;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;

public class Test_XBox_Device_vh1_account_https_hls_url extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description("XBox Device: vh1 account, https, hls url")
    public void test_XBox_Device_vh1_account_https_hls_url() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:vh1.com:09d30e27-e058-4ae1-9bb3-8470b0660c15");


        test.addParameter(new ParameterType("device", "xbox"));
        test.addParameter(new ParameterType("pkgOverride", "akamaidynpkg"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "https://"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "cp477481-vh||dlvrsvc"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}