package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.bwcorrection;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class BwCorrectionTest_5 extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26269")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-1565: bwcorrection parameter with value more than 100")
    public void test_VS_1565_bwcorrection_parameter_with_value_more_than_100() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:ed840685-e3ed-42db-b2cc-d90c315828c9");
        //test.setNetwork("akamai");

        test.addParameter(new ParameterType("acceptMethods", "hls"));
        test.addParameter(new ParameterType("device", "iPad"));
        test.addParameter(new ParameterType("bwcorrection", "150"));
        test.addParameter(new ParameterType("pkgOverride", "akamaidynpkg"));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "https://cp103040-vh.akamaihd.net/||dlvrsvc"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "bwcorrection=100%20100%20100%20100%20100%20100"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);

        List<XpathValidatorRuleType> xpathValidatorRuleType = new ArrayList<>();
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//item/rendition"));
        XpathValidatorType xpathValidator = new XpathValidatorType(xpathValidatorRuleType);

        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);
        validators.add(xpathValidator);

        ContextExtractorParameterType contextExtractorParameterType1 = new ContextExtractorParameterType();
        contextExtractorParameterType1.setName("masterE");
        contextExtractorParameterType1.setXpath("//src/text()");

        List<ContextExtractorParameterType> contextExtractorParameterTypes = new ArrayList<>();
        contextExtractorParameterTypes.add(contextExtractorParameterType1);

        test.setContextextractor(getContextExtractors(contextExtractorParameterTypes));

        testRequest(test, validators);
    }

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26269")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA}, dependsOnMethods = "test_VS_1565_bwcorrection_parameter_with_value_more_than_100")
    @Description("VS-1565: Master for bwcorrection parameter with value more than 100")
    public void test_VS_1565_Master_for_bwcorrection_parameter_with_value_more_than_100() {
        TestType test = new TestType();

        test.setUrl("{$context:masterE}");
        //test.setNetwork("akamai");

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=990000"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=558000"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=1956000"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=2686000"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=4068000"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=6104000"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=9504000"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);

        testRequest(test, validators);
    }
}