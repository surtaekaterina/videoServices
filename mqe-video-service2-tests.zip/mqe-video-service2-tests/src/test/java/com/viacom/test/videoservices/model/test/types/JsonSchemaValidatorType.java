package com.viacom.test.videoservices.model.test.types;

import java.util.ArrayList;
import java.util.List;

import com.viacom.test.videoservices.model.test.Validator;

public class JsonSchemaValidatorType extends Validator {

	protected List<JsonSchemaValidatorRuleType> rule;
	
	public JsonSchemaValidatorType(List<JsonSchemaValidatorRuleType> rule) {
		this.rule = rule;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<JsonSchemaValidatorRuleType> getRule() {
		if (rule == null) {
			rule = new ArrayList<JsonSchemaValidatorRuleType>();
		}
		return this.rule;
	}

}
