package com.viacom.test.videoservices.model.test.types;

public enum JsonComparisonValidatorRuleNameType {

	URL("url"), FILE_SYSTEM("file_system");
	private final String value;

	private JsonComparisonValidatorRuleNameType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}
}
