package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.authsuite_validation;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class EnforcingAuthNoAuthPlatformRestrictedVideoTest extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(BLOCKER)
    @TestCaseId("22137868")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description(value = "VS-5487: Enforcing Auth for the Namespace (enforceAuth:true, enableAuthLogging:false) - AuthPlatform is not available as part of the request")

    public void checkAuthSuiteValidationForEnforcingAuthRestrictedVideoTest() {

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:noggin.us:aabda5f0-9973-11e3-83eb-0026b9414f30");

        test.addParameter("accountOverride", "nickjr.com");
        test.addParameter("ep", "2527aaac");
        test.addParameter("geo", "US");
        test.addParameter("arcStage", "authoring");
        test.addParameter("device", "iPad");

        test.addHeader("X-VIA-TVE-MEDIATOKEN", "eyJhbGciOiJSUzI1NiJ9.eyJicmFuZCI6Im10diIsImFwcGxpY2F0aW9uIjoibXR2IiwicGxhdGZvcm0iOiJpb3MiLCJjb3VudHJ5IjoidXMiLCJyZXNvdXJjZSI6Im10diIsImV4cCI6MjE4Mzk4MjM4M30.u2ooNKg60rFBp-ovfdESjr8-i83f1Cq-9ySVwGnrc2-ZudP6HEAp7EZPP6kEcR79Uyqh9AkX2nOZGFP7HDApbFpAjxJWlewv-MqbnnBsNlvCJWSIEF4N_-bDn0aahO9YyHD_6PAzBZEZbZCw5ENixj6VBqMlpRmoUu88e9NoecptHbBGTItrVieuLfVImBg_ngkKpz2UOYPz5bR4w7o-DFph3rK4k3F2Q8sqOgkFt1KF0oH2NNviLQgOihgT2U6CFTV--kSHehavJg8gf6KBbMpOABqNWhaq_OFa-9RtrNQM7TMwbNciow0YjMp4bsd4hyh1TwGrmuyK5TH8BoszCg");

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item", "Error - Auth failed or missing"));

        testRequest(test, v.getAll());
    }
}
