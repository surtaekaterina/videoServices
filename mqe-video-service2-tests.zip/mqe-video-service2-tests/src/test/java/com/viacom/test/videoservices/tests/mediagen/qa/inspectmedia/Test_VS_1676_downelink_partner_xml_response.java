package com.viacom.test.videoservices.tests.mediagen.qa.inspectmedia;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.model.test.types.XpathConstantType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.INSPECT_MEDIA_QA;

public class Test_VS_1676_downelink_partner_xml_response extends AbstractBaseTest {

    @Features(INSPECT_MEDIA_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26286")
    @Test(groups = {INSPECT_MEDIA_QA})
    @Description("VS-1676 downelink partner xml response")
    public void test_VS_1676_downelink_partner_xml_response() {
        TestType test = new TestType();

        test.setUrl("services/InspectMedia/downelink/mtv.com/mgid:arc:video:mtv.com:cd77ebf5-ffcf-409f-b1c9-e3dc763dfa4b");


        test.addParameter(new ParameterType("metadata", "xml"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "type=\"video/mp4\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "format=\"mp4_h264_high\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "bitrate=\"2747\""));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);


        List<XpathValidatorRuleType> xpathValidatorRuleType = new ArrayList<>();
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "/metadata"));
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EQUALS, XpathConstantType.NUMBER, "count(/metadata/rendition)", "1"));
        XpathValidatorType xpathValidator = new XpathValidatorType(xpathValidatorRuleType);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(xpathValidator);

        testRequest(test, validators);
    }
}