package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.aspectratio;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HeaderType;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.model.test.types.XpathConstantType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.RegionUtils;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class Test_VS_2321_aspectRatio_parameter_with_value_4_3_for_item_only_with_16_9_aspectRatioreturns_16_9_renditions extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26441")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-2321: aspectRatio parameter with value=4:3 for item only with 16:9 aspectRatio(returns 16:9 renditions)")
    public void test_VS_2321_aspectRatio_parameter_with_value_4_3_for_item_only_with_16_9_aspectRatioreturns_16_9_renditions() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:southparkstudios.com:e6877a38-ed00-11e0-aca6-0026b9414f30");
        //test.setNetwork("akamai");

        test.addParameter(new ParameterType("aspectRatio", "4:3"));
        test.addParameter(new ParameterType("debug", "true"));

        test.addHeader(new HeaderType("X-Forwarded-For", RegionUtils.getIP("us")));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "aspectRatio=16:9"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "aspectRatio=none"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "rtmpe://cp9950.edgefcs.net/ondemand/mtvnorigin/gsp.comedystor/com/sp/season-8/0804/acts/sp_0804_actHD_01_B_384x216_300.mp4"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "rtmpe://cp9950.edgefcs.net/ondemand/mtvnorigin/gsp.comedystor/com/sp/season-8/0804/acts/sp_0804_actHD_01_B_512x288_450.mp4"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);

        List<XpathValidatorRuleType> xpathValidatorRuleType = new ArrayList<>();
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//item/rendition"));
        XpathValidatorType xpathValidator = new XpathValidatorType(xpathValidatorRuleType);

        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);
        validators.add(xpathValidator);

        testRequest(test, validators);
    }
}