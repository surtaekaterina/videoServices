package com.viacom.test.videoservices.serviceclient;

import com.viacom.test.core.lab.Logger;
import com.viacom.test.videoservices.serviceclient.exception.HttpClientException;
import org.apache.http.HttpHost;
import org.apache.http.StatusLine;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import static com.viacom.test.videoservices.utils.IProps.ConfigProps.IS_PROXY_ENABLED;
import static com.viacom.test.videoservices.utils.IProps.ConfigProps.PROXY_HOST;
import static com.viacom.test.videoservices.utils.IProps.ConfigProps.PROXY_PORT;
import static com.viacom.test.videoservices.utils.IProps.ConfigProps.REQUEST_TIMEOUT_SECONDS;

public class HttpClient {

    private static final Map<HttpClientSecType, HttpClientBuilder> HTTP_CLIENT_BUILDER_BY_SEC_TYPE = new HashMap<>();

    private static HttpClient instance;

    private HttpClient() {
    }

    public static HttpClient getInstance() {
        if (null == instance) {
            instance = new HttpClient();
        }
        return instance;
    }

    private static HttpClientBuilder loadHttpClientSecType(HttpClientSecType httpClientSecType) {
        if (!HTTP_CLIENT_BUILDER_BY_SEC_TYPE.containsKey(httpClientSecType)) {
            HTTP_CLIENT_BUILDER_BY_SEC_TYPE.put(httpClientSecType, HttpClientSecFactory.create(httpClientSecType));
        }
        return HTTP_CLIENT_BUILDER_BY_SEC_TYPE.get(httpClientSecType);
    }

    private HttpClientContext process(HttpClientSecType httpClientSecType, BasicHttpEntityEnclosingRequest request, boolean setFollowRedirects) {
        try {
            HttpClientBuilder httpClientBuilder = loadHttpClientSecType(httpClientSecType);
            setFollowRedirects(httpClientBuilder, setFollowRedirects);
            setTimeout(httpClientBuilder, REQUEST_TIMEOUT_SECONDS);
            HttpClientContext context = HttpClientContext.create();
            CloseableHttpClient httpClient;

            if (IS_PROXY_ENABLED) {
                HttpHost proxy = new HttpHost(PROXY_HOST, PROXY_PORT, "http");
                httpClient = httpClientBuilder.create().setProxy(proxy).build();
            } else {
                httpClient = httpClientBuilder.build();
            }

            HttpHost host;
            try {
                host = URIUtils.extractHost(new URI(request.getRequestLine().getUri().split("\\?")[0]));
            } catch (URISyntaxException e) {
                throw new RuntimeException(e.getMessage());
            }
            httpClient.execute(host, request, context);

            return context;
        } catch (IOException e) {
            throw new HttpClientException("Couldn't send request due to : " + e.getMessage(), e);
        }
    }

    public Response send(HttpClientSecType httpClientSecType, BasicHttpEntityEnclosingRequest request, boolean setFollowRedirects, boolean isReadByteResponse) {
        Logger.logMessage("Sending request...");
        Logger.logMessage(request.getRequestLine());
        HttpClientContext httpContext = process(httpClientSecType, request, setFollowRedirects);
        Response response = ResponseFactory.create(httpContext, isReadByteResponse);
        Logger.logMessage("Getting response...");
        String content = response.getContentString();
        StatusLine statusLine = response.getStatusLine();
        Logger.logMessage("Status Line: " + statusLine);
        Logger.logMessage("Content: " + content);
        return response;
    }

    private static void setFollowRedirects(HttpClientBuilder httpClientBuilder, boolean setFollowRedirects) {
        if (setFollowRedirects) {
            httpClientBuilder.setRedirectStrategy(new LaxRedirectStrategy());
        } else {
            httpClientBuilder.disableRedirectHandling();
        }
    }

    private static void setTimeout(HttpClientBuilder httpClientBuilder, int timeoutSeconds) {
        int timeoutMillis = timeoutSeconds * 1000;
        httpClientBuilder.setDefaultRequestConfig(RequestConfig.custom()
                .setConnectTimeout(timeoutMillis)
                .setConnectionRequestTimeout(timeoutMillis)
                .setSocketTimeout(timeoutMillis)
                .build());
    }

}
