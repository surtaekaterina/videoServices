package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.commentedservicevalidator;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.model.test.types.XpathConstantType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;

public class Test_MOBSERV_1047_MediaGen_Android_OS_Version_4_0_3 extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description("MOBSERV-1047 MediaGen: Android OS Version 4.0.3")
    public void test_MOBSERV_1047_MediaGen_Android_OS_Version_4_0_3() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:comedycentral.com:8aa30dca-767f-4241-a62b-799adf9649ec");


        test.addParameter(new ParameterType("device", "android"));
        test.addParameter(new ParameterType("deviceOsVersion", "4.0.3"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "_,384x216_400_m30,512x288_750_m30,640x360_1200_m30,768x432_1700_m30,960x540_2200_m31,.mp4.csmil/master.m3u8"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);

        List<XpathValidatorRuleType> xpathValidatorRuleType = new ArrayList<>();
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EQUALS, XpathConstantType.NUMBER, "count(*//item/rendition)", "1"));
        XpathValidatorType xpathValidator = new XpathValidatorType(xpathValidatorRuleType);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(xpathValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}