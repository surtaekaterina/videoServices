package com.viacom.test.videoservices.serviceclient.exception;

public class HttpMethodNotSupportedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5002807887633321304L;

	public HttpMethodNotSupportedException(String message) {

	}

}
