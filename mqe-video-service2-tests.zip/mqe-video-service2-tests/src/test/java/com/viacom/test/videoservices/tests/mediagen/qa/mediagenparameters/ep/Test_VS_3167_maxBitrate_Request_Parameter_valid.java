package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.ep;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class Test_VS_3167_maxBitrate_Request_Parameter_valid extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26510")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-3167: maxBitrate Request Parameter valid")
    public void test_VS_3167_maxBitrate_Request_Parameter_valid() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:comedycentral.com:78256eab-eb1a-4c3e-ad0b-832adb8e9758");


        test.addParameter(new ParameterType("debug", "true"));
        test.addParameter(new ParameterType("acceptMethods", "hls"));
        test.addParameter(new ParameterType("maxBitrate", "1500"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "Full initial renditions list: (count=7)"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "Final filtered renditions list: (count=3)"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "640x360_1028.mp4"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "maxBitrate=1500"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}