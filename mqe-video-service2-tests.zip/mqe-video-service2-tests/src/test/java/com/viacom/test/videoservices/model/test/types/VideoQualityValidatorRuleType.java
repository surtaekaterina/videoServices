package com.viacom.test.videoservices.model.test.types;

import java.util.Map;

import com.viacom.test.videoservices.model.test.Rule;

public class VideoQualityValidatorRuleType extends Rule {
	
	private VideoQualityRuleNameType name;
	private Map<String, String> expectedResult;

	public VideoQualityValidatorRuleType() {
	}
	
	public VideoQualityValidatorRuleType(VideoQualityRuleNameType name, Map<String, String> expectedResult) {
		this.name = name;
		this.expectedResult = expectedResult;
	}
	
	public Map<String, String> getExpectedResult() {
		return expectedResult;
	}

	public void setExpectedResult(Map<String, String> expectedResult) {
		this.expectedResult = expectedResult;
	}

	public VideoQualityRuleNameType getName() {
		return name;
	}

	public void setName(VideoQualityRuleNameType name) {
		this.name = name;
	}
	
}
