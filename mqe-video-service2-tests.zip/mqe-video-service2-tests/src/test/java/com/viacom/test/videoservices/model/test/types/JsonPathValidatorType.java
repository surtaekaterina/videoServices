package com.viacom.test.videoservices.model.test.types;


import com.viacom.test.videoservices.model.test.Validator;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JsonPathValidatorType", propOrder = {"rule"})
public class JsonPathValidatorType extends Validator {

    protected List<JsonPathValidatorRuleType> rule;

    public JsonPathValidatorType() {
    }

    public JsonPathValidatorType(List<JsonPathValidatorRuleType> rules) {
        this.rule = rules;
    }

    public JsonPathValidatorType(JsonPathValidatorRuleType rule) {
        this.rule = new ArrayList<>();
        this.rule.add(rule);
    }

    public void setRule(List<JsonPathValidatorRuleType> rule) {
        this.rule = rule;
    }

    @SuppressWarnings("unchecked")
    public List<JsonPathValidatorRuleType> getRule() {
        if (rule == null) {
            rule = new ArrayList<>();
        }
        return this.rule;
    }
}
