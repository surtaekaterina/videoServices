package com.viacom.test.videoservices.model.test.types;

import java.util.ArrayList;
import java.util.List;

import com.viacom.test.videoservices.model.test.Validator;

public class WebVttCaptionValidatorType extends Validator {
	
	protected List<WebVttCaptionValidatorRuleType> rule;
	private List<HeaderType> headers;

	public WebVttCaptionValidatorType() {
	}	

	public WebVttCaptionValidatorType(List<HeaderType> headers) {
		this.headers = headers;
	}

	public void setHeaders(List<HeaderType> headers) {
		this.headers = headers;
	}
	
	public List<HeaderType> getHeaders() {
		if (headers == null) {
			headers = new ArrayList<HeaderType>();
		}
		return this.headers;
		
	}

	@SuppressWarnings("unchecked")
	public List<WebVttCaptionValidatorRuleType> getRule() {
		if (rule == null) {
			rule = new ArrayList<WebVttCaptionValidatorRuleType>();
		}
		return this.rule;
	}

}
