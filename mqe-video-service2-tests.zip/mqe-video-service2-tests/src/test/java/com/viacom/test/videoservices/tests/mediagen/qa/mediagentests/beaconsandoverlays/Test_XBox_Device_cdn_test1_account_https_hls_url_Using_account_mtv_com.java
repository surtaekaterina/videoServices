package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.beaconsandoverlays;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;

public class Test_XBox_Device_cdn_test1_account_https_hls_url_Using_account_mtv_com extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description("XBox Device: cdn_test1 account, https, hls url Using account mtv.com")
    public void test_XBox_Device_cdn_test1_account_https_hls_url_Using_account_mtv_com() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:ed840685-e3ed-42db-b2cc-d90c315828c9");

        test.addParameter(new ParameterType("arcStage", "authoring"));
        test.addParameter(new ParameterType("nodp", "true"));
        test.addParameter(new ParameterType("device", "xbox"));
        test.addParameter(new ParameterType("pkgOverride", "akamaidynpkg"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "https://"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "cp103040||dlvrsvc"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "768x432_1528||stream_640x360_1024030"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}