package com.viacom.test.videoservices.model.test;

import com.viacom.test.videoservices.model.test.types.ByteValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ByteValidatorType;
import com.viacom.test.videoservices.model.test.types.EqualResponseValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.EqualResponseValidatorType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorType;
import com.viacom.test.videoservices.model.test.types.JsonComparisonValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonComparisonValidatorType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorType;
import com.viacom.test.videoservices.model.test.types.JsonSchemaValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonSchemaValidatorType;
import com.viacom.test.videoservices.model.test.types.JsonValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonValidatorType;
import com.viacom.test.videoservices.model.test.types.RedirectValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.RedirectValidatorType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorType;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.ImmutableList.of;

public class Validators {

    private List<Validator> list = new ArrayList<>();

    public List<Validator> getAll() {
        return list;
    }

    public void add(Validator v) {
        list.add(v);
    }

    public void add(Rule r) {
        list.add(getValidatorByRule(r));
    }

    public void add(Validators vs) {
        list.addAll(vs.getAll());
    }
    
    public static Validator getValidatorByRule(Rule r){
        Validator v;
        if (r.getClass().equals(JsonPathValidatorRuleType.class)) {
            v = new JsonPathValidatorType(of((JsonPathValidatorRuleType)r));
        }

        else if (r.getClass().equals(TextValidatorRuleType.class)) {
            v = new TextValidatorType(of((TextValidatorRuleType)r));
        }

        else if (r.getClass().equals(ByteValidatorRuleType.class)) {
            v = new ByteValidatorType(of((ByteValidatorRuleType)r));
        }

        else if (r.getClass().equals(JsonValidatorRuleType.class)) {
            v = new JsonValidatorType(of((JsonValidatorRuleType)r));
        }

        else if (r.getClass().equals(XpathValidatorRuleType.class)) {
            v = new XpathValidatorType(of((XpathValidatorRuleType)r));
        }

        else if (r.getClass().equals(ServiceValidatorRuleType.class)) {
            v = new ServiceValidatorType(of((ServiceValidatorRuleType)r));
        }

        else if (r.getClass().equals(StatusLineValidatorRuleType.class)) {
            v = new StatusLineValidatorType(of((StatusLineValidatorRuleType)r));
        }

        else if (r.getClass().equals(HeaderValidatorRuleType.class)) {
            v = new HeaderValidatorType(of((HeaderValidatorRuleType)r));
        }

        else if (r.getClass().equals(RedirectValidatorRuleType.class)) {
            v = new RedirectValidatorType(of((RedirectValidatorRuleType)r));
        }

        else if (r.getClass().equals(JsonComparisonValidatorRuleType.class)) {
            v = new JsonComparisonValidatorType(of((JsonComparisonValidatorRuleType)r));
        }

        else if (r.getClass().equals(JsonSchemaValidatorRuleType.class)) {
            v = new JsonSchemaValidatorType(of((JsonSchemaValidatorRuleType)r));
        }

        else if (r.getClass().equals(EqualResponseValidatorRuleType.class)) {
            v = new EqualResponseValidatorType(of((EqualResponseValidatorRuleType)r));
        }

        else {
            throw new RuntimeException("Unexpected Validator Rule Type: " + r.getClass().toString());
        }

        return v;
        
    }
}
