package com.viacom.test.videoservices.tests.deliveryservice.master;

import com.viacom.test.videoservices.constants.HeaderConstants;
import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.UUID;

import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.POST;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.DLVR_CDN_TEST1_ACCOUNT;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.CDN.DEFAULT_CDN;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMasterPlaylistPathWoCommonPrefix;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMediaPlaylistLink;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.isDevEnv;
import static com.viacom.test.videoservices.utils.app.HostManager.getProxyHost;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class DeliveryPlaylistsFromDifferentRootFoldersTest extends AbstractBaseTest {

    private static final String TEST_NAME = "DeliveryTests/PlaylistsFromDifferentRootFolders/5089/" + UUID.randomUUID().toString();

    private static final String NAMESPACE_1 = "mgid:file:gsp:pkgtestVS5089_1:/" + TEST_NAME;
    private static final String UPLOAD_PATH_1 = "gsp.pkgtestVS5089_1/" + TEST_NAME;
    private static final String NAMESPACE_2 = "mgid:file:gsp:pkgtestVS5089_2:/" + TEST_NAME;
    private static final String UPLOAD_PATH_2 = "gsp.pkgtestVS5089_2/" + TEST_NAME;

    private static final String ACCOUNT_AND_CDN = "account=" + DLVR_CDN_TEST1_ACCOUNT + "&cdn=" + DEFAULT_CDN;

    private static final String MEDIA_URL_QUERY_PARAMETERS_DEV = "\\?" + ACCOUNT_AND_CDN;

    private static final String MEDIA_URL_QUERY_PARAMETERS_UAT_LIVE = "\\?tk=st=.*&" + ACCOUNT_AND_CDN;

    private String MEDIA_URL_QUERY_PARAMETERS = isDevEnv() ? MEDIA_URL_QUERY_PARAMETERS_DEV : MEDIA_URL_QUERY_PARAMETERS_UAT_LIVE;

    private VideoUrl videoUrl_1 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194055").setHashcode("2607552757").build();

    private VideoUrl videoUrl_2 = new VideoUrl.Builder()
            .setNamespaceWoFileName(NAMESPACE_1).setUploadPath(UPLOAD_PATH_1)
            .setFileName("320x240_2880_3streams_Main_29_97.mp4").setResolution("320x240").setBitrate("281456").setHashcode("1694877362").build();

    private VideoUrl videoUrl_3 = new VideoUrl.Builder()
            .setNamespaceWoFileName(NAMESPACE_2).setUploadPath(UPLOAD_PATH_2)
            .setFileName("480x360_5067_3streams_Main_29_97.mp4").setResolution("480x360").setBitrate("485528").setHashcode("329765914").build();

    @AfterMethod(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl_1, videoUrl_2, videoUrl_3);
    }

    @Features(DELIVERY)
    @BeforeMethod(alwaysRun = true)
    public void packageVideosForDeliveryPlaylistsFromDifferentRootFoldersTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setHttpMethod(POST);
        test.setUrl(getProxyHost() + "proxy/addMessages");
        test.setPostbody(postBodyProxyAddMessage(videoUrl_1, videoUrl_2, videoUrl_3));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}"));

        testRequest(test, v.getAll());

        test.setUrl(getProxyHost() + "proxy/checkService");
        test.setPostbody(postBodyProxyCheckService(videoUrl_1, videoUrl_2, videoUrl_3));

        v = new Validators();
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"));
        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.renditions.length()", "3"));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS).until(new WaitForValidatorsPredicateImpl(test, v.getAll()));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("129411")
    @Test(groups = {DELIVERY})
    public void checkMasterWithPlaylistsFromDifferentRootFoldersTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathWoCommonPrefix(videoUrl_1, videoUrl_2, videoUrl_3));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, HeaderConstants.CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*Created by Viacom Delivery Service.*\\s#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289[\\s\\S]*")); //check that first playlist is the list with AVERAGE-BANDWIDTH closest to 600kbps (default value)

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=227171,BANDWIDTH=258197,FRAME-RATE=15,CODECS=\"avc1.42C00C,mp4a.40.5\",RESOLUTION=384x216"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=360453,BANDWIDTH=437994,FRAME-RATE=29.97,CODECS=\"avc1.4D401E,mp4a.40.2\",RESOLUTION=320x240"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289,BANDWIDTH=644220,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=480x360"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_1).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_2).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_3).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));


        testRequest(test, v.getAll());
    }
}