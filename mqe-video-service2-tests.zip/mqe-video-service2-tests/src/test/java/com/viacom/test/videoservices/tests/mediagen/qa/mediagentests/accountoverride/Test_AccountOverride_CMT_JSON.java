package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.accountoverride;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;

public class Test_AccountOverride_CMT_JSON extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description("AccountOverride CMT JSON")
    public void test_AccountOverride_CMT_JSON() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:ed840685-e3ed-42db-b2cc-d90c315828c9");

        test.addParameter(new ParameterType("arcStage", "authoring"));
        test.addParameter(new ParameterType("nodp", "true"));
        test.addParameter(new ParameterType("accountOverride", "cmt.com"));
        test.addParameter(new ParameterType("format", "json"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"cdn\": \"akamai\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "rtmpe://cp3547.edgefcs.net/ondemand/mtvnorigin"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);


        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, "Content-Type", "application/json"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(headerValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}