package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.commentedservicevalidator;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;
import static com.viacom.test.videoservices.utils.app.MediagenHostUtils.isDevEnv;

public class Test_Device_device_iPad_account_vh1_com_no_mov_support extends AbstractBaseTest {

    private static String STREAM_VALUE_DEV = "stream_1280x720_3468343_2041205920";
    private static String STREAM_VALUE_UAT_LIVE = "stream_960x540_2150628_3533254192||stream_960x540_2149425";

    private String STREAM_VALUE = isDevEnv() ? STREAM_VALUE_DEV : STREAM_VALUE_UAT_LIVE;

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description("Device device=iPad account=vh1.com, no .mov support")
    public void test_Device_device_iPad_account_vh1_com_no_mov_support() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:vh1.com:5ec3b991-c88e-404b-af98-2ac5452a5cd3");


        test.addParameter(new ParameterType("device", "iPad"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, STREAM_VALUE));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}