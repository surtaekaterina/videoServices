package com.viacom.test.videoservices.tests.deliveryservice.submit.token;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.TokenGenerator;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_TOKEN;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyDlvrApiSubmit;

public class SubmitSingleVideoWithInvalidTokenTest extends AbstractBaseTest {

    private static final String PATH = TokenGenerator.getUrlPathWithInvalidTokenForDeliveryService("api/submit");

    private VideoUrl videoUrl = new VideoUrl.Builder().setNamespaceAndUploadPathWithoutS3path("SubmitSingleVideoTest")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").build();

    @Features(DELIVERY_TOKEN)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25970")
    @Test(groups = {DELIVERY_TOKEN})
    public void submitSingleVideoWithInvalidTokenTest() {
        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);

        test.setUrl(PATH);

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(postBodyDlvrApiSubmit(videoUrl));
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("403", "Forbidden", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "An error occurred while processing your request."));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }
}
