package com.viacom.test.videoservices.model.ffprobe;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "filename",
    "nb_streams",
    "nb_programs",
    "format_name",
    "format_long_name",
    "start_time",
    "duration",
    "size",
    "bit_rate",
    "probe_score"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Format {

    @JsonProperty("filename")
    private String filename;
    @JsonProperty("nb_streams")
    private Integer nbStreams;
    @JsonProperty("nb_programs")
    private Integer nbPrograms;
    @JsonProperty("format_name")
    private String formatName;
    @JsonProperty("format_long_name")
    private String formatLongName;
    @JsonProperty("start_time")
    private String startTime;
    @JsonProperty("duration")
    private String duration;
    @JsonProperty("size")
    private String size;
    @JsonProperty("bit_rate")
    private String bitRate;
    @JsonProperty("probe_score")
    private Integer probeScore;

    @JsonProperty("filename")
    public String getFilename() {
        return filename;
    }

    @JsonProperty("filename")
    public void setFilename(String filename) {
        this.filename = filename;
    }

    @JsonProperty("nb_streams")
    public Integer getNbStreams() {
        return nbStreams;
    }

    @JsonProperty("nb_streams")
    public void setNbStreams(Integer nbStreams) {
        this.nbStreams = nbStreams;
    }

    @JsonProperty("nb_programs")
    public Integer getNbPrograms() {
        return nbPrograms;
    }

    @JsonProperty("nb_programs")
    public void setNbPrograms(Integer nbPrograms) {
        this.nbPrograms = nbPrograms;
    }

    @JsonProperty("format_name")
    public String getFormatName() {
        return formatName;
    }

    @JsonProperty("format_name")
    public void setFormatName(String formatName) {
        this.formatName = formatName;
    }

    @JsonProperty("format_long_name")
    public String getFormatLongName() {
        return formatLongName;
    }

    @JsonProperty("format_long_name")
    public void setFormatLongName(String formatLongName) {
        this.formatLongName = formatLongName;
    }

    @JsonProperty("start_time")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("start_time")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    @JsonProperty("duration")
    public String getDuration() {
        return duration;
    }

    @JsonProperty("duration")
    public void setDuration(String duration) {
        this.duration = duration;
    }

    @JsonProperty("size")
    public String getSize() {
        return size;
    }

    @JsonProperty("size")
    public void setSize(String size) {
        this.size = size;
    }

    @JsonProperty("bit_rate")
    public String getBitRate() {
        return bitRate;
    }

    @JsonProperty("bit_rate")
    public void setBitRate(String bitRate) {
        this.bitRate = bitRate;
    }

    @JsonProperty("probe_score")
    public Integer getProbeScore() {
        return probeScore;
    }

    @JsonProperty("probe_score")
    public void setProbeScore(Integer probeScore) {
        this.probeScore = probeScore;
    }

}
