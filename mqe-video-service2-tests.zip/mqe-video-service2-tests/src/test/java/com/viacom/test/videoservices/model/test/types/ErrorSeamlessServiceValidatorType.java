package com.viacom.test.videoservices.model.test.types;

import java.util.ArrayList;
import java.util.List;

import com.viacom.test.videoservices.model.test.Validator;

public class ErrorSeamlessServiceValidatorType extends Validator {
	
	protected List<ErrorSeamlessServiceValidatorRuleType> rule;
	protected String id;
	
	
	public ErrorSeamlessServiceValidatorType(List<ErrorSeamlessServiceValidatorRuleType> rules, String id) {
		this.rule = rules;
		this.id = id;
	}
	
	public String getId() {
		return id;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<ErrorSeamlessServiceValidatorRuleType> getRule() {
		if (rule == null) {
			rule = new ArrayList<ErrorSeamlessServiceValidatorRuleType>();
		}
		return this.rule;
	}

}
