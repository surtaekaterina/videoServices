package com.viacom.test.videoservices.tests.deliveryservice;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.UUID;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.POST;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMasterPlaylistUrlWithToken;
import static com.viacom.test.videoservices.utils.app.HostManager.getProxyHost;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class DeliveryCDNWithEmptyAccountParameterTest extends AbstractBaseTest {

    private String TEST_NAME = "DeliveryTests/flow_with_empty_account_parameter/" + UUID.randomUUID();

    private VideoUrl videoUrl = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194055").setHashcode("2607552757").build();

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForDeliveryCDNWithEmptyAccountParameterTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setHttpMethod(POST);
        test.setUrl(getProxyHost() + "proxy/addMessages");

        test.setPostbody(postBodyProxyAddMessage(videoUrl));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}"));

        testRequest(test, v.getAll());

        test.setUrl(getProxyHost() + "proxy/checkService");

        test.setPostbody(postBodyProxyCheckService(videoUrl));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS)
                .until(new WaitForValidatorsPredicateImpl(test, of(new TextValidatorType(of(
                        new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"))))));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("103675")
    @Test(groups = {DELIVERY})
    @Description(value = "https://jira.mtvi.com/browse/VS-5019")
    public void checkMasterDeliveryCDNWithEmptyAccountParameterTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistUrlWithToken(videoUrl));
        test.addParameter("account", "");

        v.add(new StatusLineValidatorRuleType("400", "Bad Request", "HTTP"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"errors\":[\"Bad request. Media urls could not be created due to missing CDN configurations for the account\"]}"));

        testRequest(test, v.getAll());
    }
}
