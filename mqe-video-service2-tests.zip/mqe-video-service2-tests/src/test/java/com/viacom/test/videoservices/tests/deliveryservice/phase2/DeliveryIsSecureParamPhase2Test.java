package com.viacom.test.videoservices.tests.deliveryservice.phase2;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ContextExtractorParameterType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.serviceclient.Endpoint;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrlP2;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.UUID;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.constants.HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN;
import static com.viacom.test.videoservices.constants.HeaderConstants.CONTENT_TYPE;
import static com.viacom.test.videoservices.constants.URLConstants.HTTP;
import static com.viacom.test.videoservices.constants.URLConstants.HTTPS;
import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.POST;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_2;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.ACCOUNT_MTV_COM;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.CDN.AKAMAI;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.CDN.EDGE_CAST;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.CDN.LEVEL_3;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.defineTShost;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMasterPlaylistPathPhase2;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMediaPlaylistLink;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getPlaylistLink;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.isDevEnv;
import static com.viacom.test.videoservices.utils.app.HostManager.getKeyServiceHost;
import static com.viacom.test.videoservices.utils.app.HostManager.getProxy2Host;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.CAPTIONS;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.THUMBS;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.VIDEO_AUDIO;
import static com.viacom.test.videoservices.utils.app.VideoUrlP2.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrlP2.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class DeliveryIsSecureParamPhase2Test extends AbstractBaseTest {

    private String IS_SECURE_VALUE, CDN, MEDIA_URL_QUERY_PARAMETERS, tsHost;

    private static final int TS_COUNT = 5;

    private static String TEST_NAME = "DeliveryTests/DeliveryIsSecureParamTest2/" + UUID.randomUUID();

    private VideoUrlP2 videoUrl_1 = new VideoUrlP2.Builder().setNamespaceAndUploadPathWithoutS3path(TEST_NAME + "/1")
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194055")
            .setPackageTypes(VIDEO_AUDIO).setHashcode("2607552757").setLanguageCode("en").build();

    private VideoUrlP2 videoUrl_2 = new VideoUrlP2.Builder().setNamespaceAndUploadPathWithoutS3path(TEST_NAME + "/2")
            .setBitrate("403063").setHashcode("3469779259").setFileName("384x216_278_30sec.mp4").setResolution("384x216")
            .setPackageTypes(VIDEO_AUDIO, THUMBS).setLanguageCode("es").build();

    private VideoUrlP2 videoUrl_1_C = new VideoUrlP2.Builder().setDefaultNamespaceAndUploadPath(TEST_NAME + "/1")
            .setFileName("captions2.vtt").setResolution("384x216").setHashcode("3117149298").setPackageTypes(CAPTIONS)
            .setReferenceVideo(videoUrl_1, null).build();

    @DataProvider(name = "data", parallel = true)
    public static Object[][] playersDataProvider() {
        return new Object[][]{
                new Object[]{LEVEL_3, "true"},
                new Object[]{LEVEL_3, "false"},
                new Object[]{AKAMAI, "true"},
                new Object[]{AKAMAI, "false"},
                new Object[]{EDGE_CAST, "true"},
                new Object[]{EDGE_CAST, "false"}
        };
    }

    @Factory(dataProvider = "data")
    public DeliveryIsSecureParamPhase2Test(String cdn, String isSecure) {
        IS_SECURE_VALUE = isSecure;
        CDN = cdn;
        String QUERY_STRING = "account=" + ACCOUNT_MTV_COM + "&isSecure=" + IS_SECURE_VALUE + "&cdn=" + CDN;
        String MEDIA_URL_QUERY_PARAMETERS_DEV = "\\?" + QUERY_STRING;
        String MEDIA_URL_QUERY_PARAMETERS_UAT_LIVE = "\\?tk=st=.*&" + QUERY_STRING;
        MEDIA_URL_QUERY_PARAMETERS = isDevEnv() ? MEDIA_URL_QUERY_PARAMETERS_DEV : MEDIA_URL_QUERY_PARAMETERS_UAT_LIVE;
        tsHost = defineTShost(CDN, ACCOUNT_MTV_COM);
        tsHost = null == tsHost ? null : tsHost.replaceFirst("http(s)?://", IS_SECURE_VALUE.equals("true") ? HTTPS : HTTP);
    }

    @AfterTest(groups = {DELIVERY_2})
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl_1, videoUrl_2);
    }

    @Features(DELIVERY)
    @BeforeTest(groups = {DELIVERY_2})
    public void packageVideosForDeliveryIsSecureParamTest2() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setHttpMethod(POST);
        test.setUrl(getProxy2Host() + "proxy/addMessages");

        test.setPostbody(postBodyProxyAddMessage(videoUrl_1, videoUrl_2));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}"));

        testRequest(test, v.getAll());

        test.setUrl(getProxy2Host() + "proxy/checkService");
        test.setPostbody(postBodyProxyCheckService(videoUrl_1, videoUrl_2));

        v = new Validators();
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"));
        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.renditions.length()", "2"));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS).until(new WaitForValidatorsPredicateImpl(test, v.getAll()));

        test = new TestType();
        v = new Validators();

        test.setHttpMethod(POST);
        test.setUrl(getProxy2Host() + "proxy/addMessages");

        test.setPostbody(postBodyProxyAddMessage(videoUrl_1_C));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}"));

        testRequest(test, v.getAll());

        test.setUrl(getProxy2Host() + "proxy/checkService");
        test.setPostbody(postBodyProxyCheckService(videoUrl_1_C));

        v = new Validators();
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"));
        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.renditions.length()", "1"));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS).until(new WaitForValidatorsPredicateImpl(test, v.getAll()));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("100387")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2_IsSecureParam_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194055_2607552757,1/0/audio/en_2607552757,2/0/thumbs/320x180_3469779259.vtt,1/0/captions/subtitles_default_3117149298"));

        test.addParameter("account", ACCOUNT_MTV_COM);
        test.addParameter("cdn", CDN);
        test.addParameter("isSecure", IS_SECURE_VALUE);

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:BANDWIDTH=260547,AVERAGE-BANDWIDTH=227955,CODECS=\"avc1.42c00c,mp4a.40.5\",RESOLUTION=384x216,AUDIO=\"audio\",NAME=\"en\",LANGUAGE=\"en\",FRAME-RATE=15"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_1).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"en\",NAME=\"en\",AUTOSELECT=YES,CHANNELS=\"2\",DEFAULT=YES,URI=\"" + getPlaylistLink(videoUrl_1.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));

        ContextExtractorParameterType e1 = new ContextExtractorParameterType();
        e1.setName("audio_stream");
        e1.setRegex(getPlaylistLink(videoUrl_1.getAudioStreamUploadPath()) + ".*(?=\")");

        ContextExtractorParameterType e2 = new ContextExtractorParameterType();
        e2.setName("video_stream");
        e2.setRegex(getMediaPlaylistLink(videoUrl_1) + ".*");

        ContextExtractorParameterType e3 = new ContextExtractorParameterType();
        e3.setName("thumbs");
        e3.setRegex(getPlaylistLink(videoUrl_2.getThumbsUploadPath("320x180")) + ".*(?=\")");

        ContextExtractorParameterType e4 = new ContextExtractorParameterType();
        e4.setName("captions");
        e4.setRegex(getPlaylistLink(videoUrl_1_C.getCaptionsUploadPath()) + ".*(?=\")");

        test.setContextextractor(getContextExtractors(of(e1, e2, e3, e4)));

        testRequest(test, v.getAll());
    }


    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2_IsSecureParam_Master")
    public void checkPhase2_IsSecureParam_VideoM3u8() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("video_stream"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-PLAYLIST-TYPE:VOD"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-INDEPENDENT-SEGMENTS"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-TARGETDURATION:6"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-MEDIA-SEQUENCE:0"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-ENDLIST"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, String.format("#EXT-X-KEY:METHOD=AES-128,URI=\"%sget/encrypt.key?acl=%s&tk=",
                getKeyServiceHost().replaceFirst("http(s)?://", (IS_SECURE_VALUE.equals("true") || Endpoint.HOST.startsWith(HTTPS)) ? HTTPS : HTTP), videoUrl_1.getUploadPath())));

        for (int i = 0; i < TS_COUNT; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, tsHost + videoUrl_1.getTsUploadPathByIndex(i)));
        }

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2_IsSecureParam_Master")
    public void checkPhase2_IsSecureParam_AudioM3u8() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("audio_stream"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U\n#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-TARGETDURATION:6\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-MEDIA-SEQUENCE:0"));


        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, String.format("#EXT-X-KEY:METHOD=AES-128,URI=\"%sget/encrypt.key?acl=%s&tk=",
                getKeyServiceHost().replaceFirst("http(s)?://", (IS_SECURE_VALUE.equals("true") || Endpoint.HOST.startsWith(HTTPS)) ? HTTPS : HTTP), videoUrl_1.getUploadPath())));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTINF:6.037000,"));

        for (int i = 0; i < TS_COUNT; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, tsHost + videoUrl_1.getAudioTsUploadPathByIndex(i)));
        }

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-ENDLIST"));

        testRequest(test, v.getAll());
    }


    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2_IsSecureParam_Master")
    public void checkPhase2_IsSecureParam_Thumbs() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("thumbs"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "text/vtt"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.STARTS_WITH, "WEBVTT\n00:00:00.066 --> 00:00:08.408\n"));

        for (int i = 1; i < 5; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, tsHost + videoUrl_2.getThumbsImgUploadPath("320x180", i)));
        }

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2_IsSecureParam_Master")
    public void checkPhase2_IsSecureParam_Captions() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("captions"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-PLAYLIST-TYPE:VOD"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-MEDIA-SEQUENCE:0"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTINF:60.000000,"));

        for (int i = 0; i < 3; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, tsHost + videoUrl_1_C.getCaptionSegmentUploadPathByIndex(i)));
        }

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-ENDLIST"));

        testRequest(test, v.getAll());
    }
}
