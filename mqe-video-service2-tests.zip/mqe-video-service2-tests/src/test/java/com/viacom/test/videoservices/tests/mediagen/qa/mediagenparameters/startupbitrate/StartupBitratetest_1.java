package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.startupbitrate;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;
import static com.viacom.test.videoservices.utils.app.MediagenHostUtils.isDevEnv;

public class StartupBitratetest_1 extends AbstractBaseTest {

    private static String BANDWIDTH1_DEV = "640974";
    private static String BANDWIDTH2_DEV = "3744607";
    private static String BANDWIDTH3_DEV = "403888";
    private static String BANDWIDTH4_DEV = "2535537";
    private static String BANDWIDTH5_DEV = "1800550";
    private static String BANDWIDTH6_DEV = "5503615";
    private static String BANDWIDTH7_DEV = "1263066";
    private static String BANDWIDTH1_UAT_LIVE = "598244";
    private static String BANDWIDTH2_UAT_LIVE = "365107";
    private static String BANDWIDTH3_UAT_LIVE = "1225036";
    private static String BANDWIDTH4_UAT_LIVE = "1757672";
    private static String BANDWIDTH5_UAT_LIVE = "2428512";
    private static String BANDWIDTH6_UAT_LIVE = "3582787";
    private static String BANDWIDTH7_UAT_LIVE = "5467343";

    private String BANDWIDTH1 = isDevEnv() ? BANDWIDTH1_DEV : BANDWIDTH1_UAT_LIVE;
    private String BANDWIDTH2 = isDevEnv() ? BANDWIDTH2_DEV : BANDWIDTH2_UAT_LIVE;
    private String BANDWIDTH3 = isDevEnv() ? BANDWIDTH3_DEV : BANDWIDTH3_UAT_LIVE;
    private String BANDWIDTH4 = isDevEnv() ? BANDWIDTH4_DEV : BANDWIDTH4_UAT_LIVE;
    private String BANDWIDTH5 = isDevEnv() ? BANDWIDTH5_DEV : BANDWIDTH5_UAT_LIVE;
    private String BANDWIDTH6 = isDevEnv() ? BANDWIDTH6_DEV : BANDWIDTH6_UAT_LIVE;
    private String BANDWIDTH7 = isDevEnv() ? BANDWIDTH7_DEV : BANDWIDTH7_UAT_LIVE;

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26521")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-3176: Default startupBitrate=450, canSubstituteStartupBitrate=false")
    public void test_VS_3176_Default_startupBitrate_450_canSubstituteStartupBitrate_false() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:ed840685-e3ed-42db-b2cc-d90c315828c9");

        test.addParameter(new ParameterType("acceptMethods", "hls"));
        test.addParameter(new ParameterType("device", "iPad"));
        test.addParameter(new ParameterType("network", "wifi"));
        test.addParameter(new ParameterType("debug", "true"));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "canSubstituteStartupBitrate=false"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);

        ContextExtractorParameterType contextExtractorParameterType1 = new ContextExtractorParameterType();
        contextExtractorParameterType1.setName("masterSTA");
        contextExtractorParameterType1.setXpath("//src/text()");

        List<ContextExtractorParameterType> contextExtractorParameterTypes = new ArrayList<>();
        contextExtractorParameterTypes.add(contextExtractorParameterType1);

        test.setContextextractor(getContextExtractors(contextExtractorParameterTypes));

        testRequest(test, validators);
    }

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26521")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA}, dependsOnMethods = "test_VS_3176_Default_startupBitrate_450_canSubstituteStartupBitrate_false")
    @Description("VS-3176: Master for Default startupBitrate=450, canSubstituteStartupBitrate=false")
    public void test_VS_3176_Master_for_Default_startupBitrate_450_canSubstituteStartupBitrate_false() {
        TestType test = new TestType();

        test.setUrl("{$context:masterSTA}");

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=" + BANDWIDTH1));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=" + BANDWIDTH2));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=" + BANDWIDTH3));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=" + BANDWIDTH4));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=" + BANDWIDTH5));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=" + BANDWIDTH6));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "BANDWIDTH=" + BANDWIDTH7));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);

        testRequest(test, validators);
    }
}