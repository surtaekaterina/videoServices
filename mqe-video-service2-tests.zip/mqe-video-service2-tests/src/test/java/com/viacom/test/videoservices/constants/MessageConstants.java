package com.viacom.test.videoservices.constants;

public final class MessageConstants {

	private MessageConstants() {
	}
	
	public static final String MSG_OF_FAILURE_OF_CONFIG_FILE = "Failed to retrieve configuration value from Config File. Path: %s";
		
}
