package com.viacom.test.videoservices.model.test.types;

import com.viacom.test.videoservices.model.test.Rule;

public class JsonComparisonValidatorRuleType extends Rule {

	protected JsonSchemaValidatorRuleNameType name;
	protected String pathToExpectedJson;

	public JsonComparisonValidatorRuleType(JsonSchemaValidatorRuleNameType name, String pathToExpectedJson) {
		this.name = name;
		this.pathToExpectedJson = pathToExpectedJson;
	}

	public String getPathToExpectedJson() {
		return pathToExpectedJson;
	}
	
	public JsonSchemaValidatorRuleNameType getName() {
		return name;
	}
}
