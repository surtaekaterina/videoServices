package com.viacom.test.videoservices.tests.deliveryservice.submit.token;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.TokenGenerator;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_TOKEN;
import static com.viacom.test.videoservices.utils.app.VideoUrl.Builder;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyDlvrApiCheck;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyDlvrApiSubmit;
import static java.util.concurrent.TimeUnit.SECONDS;

public class SubmitSingleVideoWithTokenTest extends AbstractBaseTest {

    private static final String PATH_SUBMIT = TokenGenerator.getUrlPathWithTokenForDeliveryService("api/submit");
    private static final String PATH_CHECK = TokenGenerator.getUrlPathWithTokenForDeliveryService("api/check");

    private VideoUrl videoUrl = new Builder().setDefaultNamespaceAndUploadPath("SubmitSingleVideoTest/" + UUID.randomUUID())
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").build();

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl);
    }

    @Features(DELIVERY_TOKEN)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25968")
    @Test(groups = {DELIVERY_TOKEN})
    public void submitSingleVideoWithTokenTest() {
        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);

        test.setUrl(PATH_SUBMIT);

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(postBodyDlvrApiSubmit(videoUrl));
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.EQUALS, "{\"message\":\"All messages added to queue\",\"success\":true}"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);

        TestType test2 = new TestType();

        test2.setHttpMethod(HttpMethodNameType.POST);

        test2.setUrl(PATH_CHECK);

        PostBodyType postBodyType2 = new PostBodyType();
        postBodyType2.setString(postBodyDlvrApiCheck(videoUrl));
        test2.setPostbody(postBodyType2);

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(3, SECONDS).until(new WaitForValidatorsPredicateImpl
                (test2, new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true")));
    }
}
