package com.viacom.test.videoservices.tests.deliveryservice.master.token;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorType;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_TOKEN;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.COMPLETED_MGIDS_UPLOAD_PATH;

public class MasterPlaylistCDNoptionsTest extends AbstractBaseTest {

    @Features(DELIVERY_TOKEN)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("53074")
    @Test(groups = {DELIVERY_TOKEN})
    @Description(value = "https://jira.mtvi.com/browse/VS-2715")
    public void checkMasterPlaylistOptionsTest() {
        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.OPTIONS);

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistUrlWithToken(COMPLETED_MGIDS_UPLOAD_PATH, ",stream_480x320_616246,stream_384x216_403052,4/3/2/1/stream_384x216_403052,4/stream_384x216_403052"));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, "access-control-allow-headers", "*"));
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, "access-control-allow-methods", "GET, POST, OPTIONS"));
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, "access-control-allow-origin", "*"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(headerValidator);

        testRequest(test, validators);
    }
}
