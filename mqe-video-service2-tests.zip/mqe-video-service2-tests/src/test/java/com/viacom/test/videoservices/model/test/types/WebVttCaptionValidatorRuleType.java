package com.viacom.test.videoservices.model.test.types;

import com.viacom.test.videoservices.model.test.Rule;

public class WebVttCaptionValidatorRuleType extends Rule {
	
	public WebVttCaptionValidatorRuleType() {
	}

}
