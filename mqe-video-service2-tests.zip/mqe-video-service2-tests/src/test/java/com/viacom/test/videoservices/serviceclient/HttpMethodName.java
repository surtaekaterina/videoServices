package com.viacom.test.videoservices.serviceclient;

public enum HttpMethodName {

	GET, POST, HEAD, OPTIONS;
}
