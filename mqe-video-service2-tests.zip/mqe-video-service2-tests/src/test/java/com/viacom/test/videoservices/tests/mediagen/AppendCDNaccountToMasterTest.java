package com.viacom.test.videoservices.tests.mediagen;


import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ContextExtractorParameterType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathConstantType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_LIVE;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class AppendCDNaccountToMasterTest extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_LIVE)
    @Severity(BLOCKER)
    @TestCaseId("100956")
    @Test(groups = {MEDIAGEN_TESTS_LIVE, MEDIAGEN_TESTS_QA})
    public void overridenAccountParamMasterForPackagerEnabledBrand() {
        TestType mediagenTest = new TestType();
        Validators v  = new Validators();

        mediagenTest.setUrl("services/MediaGenerator/mgid:arc:video:vh1.com:22f26a8a-0c3a-493a-9359-c2cea6c7b37a");

        mediagenTest.addParameter("acceptMethods", "hls");
        mediagenTest.addParameter("accountOverride", "mtv.com");

        ContextExtractorParameterType masterUrl = new ContextExtractorParameterType();
        masterUrl.setName("masterUrl");
        masterUrl.setXpath("*//item/rendition/src/text()");

        mediagenTest.setContextextractor(getContextExtractors(of(masterUrl)));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item/rendition/src", "master.m3u8"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item/rendition/src", "account=mtv.com"));

        testRequest(mediagenTest, v.getAll());

        TestType masterTest = new TestType();
        v = new Validators();

        masterTest.setUrl("{$context:masterUrl}");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_512x288_.*.m3u8(\\?|.*&)account=mtv.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_384x216_.*.m3u8(\\?|.*&)account=mtv.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_640x360_.*.m3u8(\\?|.*&)account=mtv.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_768x432_.*.m3u8(\\?|.*&)account=mtv.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_960x540_.*.m3u8(\\?|.*&)account=mtv.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_1280x720_.*.m3u8(\\?|.*&)account=mtv.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_1920x1080_.*.m3u8(\\?|.*&)account=mtv.com[\\s\\S]*"));

        testRequest(masterTest, v.getAll());
    }

    @Features(MEDIAGEN_TESTS_LIVE)
    @Severity(BLOCKER)
    @TestCaseId("100955")
    @Test(groups = {MEDIAGEN_TESTS_LIVE, MEDIAGEN_TESTS_QA})
    public void accountParamMasterForPackagerEnabledBrand() {
        TestType mediagenTest = new TestType();
        Validators v  = new Validators();

        mediagenTest.setUrl("services/MediaGenerator/mgid:arc:video:vh1.com:22f26a8a-0c3a-493a-9359-c2cea6c7b37a");

        mediagenTest.addParameter("acceptMethods", "hls");

        ContextExtractorParameterType masterUrl = new ContextExtractorParameterType();
        masterUrl.setName("masterUrl2");
        masterUrl.setXpath("*//item/rendition/src/text()");

        mediagenTest.setContextextractor(getContextExtractors(of(masterUrl)));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item/rendition/src", "master.m3u8"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item/rendition/src", "account=vh1.com"));

        testRequest(mediagenTest, v.getAll());

        TestType masterTest = new TestType();
        v = new Validators();

        masterTest.setUrl("{$context:masterUrl2}");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_512x288_.*.m3u8(\\?|.*&)account=vh1.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_384x216_.*.m3u8(\\?|.*&)account=vh1.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_640x360_.*.m3u8(\\?|.*&)account=vh1.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_768x432_.*.m3u8(\\?|.*&)account=vh1.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_960x540_.*.m3u8(\\?|.*&)account=vh1.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_1280x720_.*.m3u8(\\?|.*&)account=vh1.com[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*stream_1920x1080_.*.m3u8(\\?|.*&)account=vh1.com[\\s\\S]*"));

        testRequest(masterTest, v.getAll());
    }

    @Features(MEDIAGEN_TESTS_LIVE)
    @Severity(BLOCKER)
    @TestCaseId("100957")
    @Test(groups = {MEDIAGEN_TESTS_LIVE, MEDIAGEN_TESTS_QA})
    public void accountParamNotAddedMasterForPackagerNotEnabled() {
        TestType mediagenTest = new TestType();
        Validators v = new Validators();

        mediagenTest.setUrl("services/MediaGenerator/mgid:arc:video:central:ed840685-e3ed-42db-b2cc-d90c315828c9");

        mediagenTest.addParameter("acceptMethods", "hls");
        mediagenTest.addParameter("pkgOverride", "akamaidynpkg");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item/rendition/src", "master.m3u8"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.NOT_CONTAINS, XpathConstantType.NODE, "*//item/rendition/src", "account"));

        testRequest(mediagenTest, v.getAll());
    }

}
