package com.viacom.test.videoservices.constants;

public final class PatternConstant {
	
	private PatternConstant() {
	}

	public static final String HTTP_HTTPS_PATTERN = "http(s)?://";
	
	public static final String WHITE_SPACE_SYM_PATTERN = "\\s";
	
	public static final String VOID_PATTERN = " ";

}
