package com.viacom.test.videoservices.model.test.types;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum JsonPathValidatorRuleNameType {

    @XmlEnumValue("exist")
    EXIST("exist"),

    @XmlEnumValue("not exist")
    NOT_EXIST("not exist"),

    @XmlEnumValue("range")
    RANGE("range"),

    @XmlEnumValue("match")
    MATCH("match"),

    @XmlEnumValue("equals")
    EQUALS("equals"),

    @XmlEnumValue("equals ignore case")
    EQUALS_IGNORE_CASE("equals ignore case"),

    @XmlEnumValue("contains")
    CONTAINS("contains"),

    @XmlEnumValue("contains ignore case")
    CONTAINS_IGNORE_CASE("contains ignore case"),
    
    @XmlEnumValue("not contains")
    NOT_CONTAINS("not contains"),

    @XmlEnumValue("split contains")
    SPLIT_CONTAINS("split contains");

    private final String value;

    JsonPathValidatorRuleNameType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static JsonPathValidatorRuleNameType fromValue(String v) {
        for (JsonPathValidatorRuleNameType c : JsonPathValidatorRuleNameType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
