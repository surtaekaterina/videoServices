package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.first;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.RegionUtils;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class Test_VS_1561_accountOverride_is_absent_for_non_matched_cdn_name extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26089")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-1561: accountOverride is absent for non matched cdn name")
    public void test_VS_1561_accountOverride_is_absent_for_non_matched_cdn_name() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:mtvplay.com:ce743124-2790-4c7f-a0de-12ffc69a38bb");
        //test.setNetwork("akamai");

        test.addParameter(new ParameterType("device", "iPad"));
        test.addParameter(new ParameterType("ep", "f4973205"));

        test.addHeader(new HeaderType("X-Forwarded-For", RegionUtils.getIP("br")));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "Error - Media urls could not be created due to missing CDN configurations for the account"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}