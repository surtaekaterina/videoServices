package com.viacom.test.videoservices.serviceclient;

import com.viacom.test.core.lab.Logger;
import org.apache.commons.lang.exception.ExceptionUtils;

import java.io.IOException;
import java.util.Properties;

import static com.viacom.test.videoservices.constants.URLConstants.HTTP;
import static com.viacom.test.videoservices.constants.URLConstants.HTTPS;
import static com.viacom.test.videoservices.utils.IProps.ConfigProps.ENV_OF_INITIAL_ENDPOINT;

public class Endpoint {

	private static final String ENDPOINT_PROPS_FILENAME = "endpoint.properties";

	private static final Properties ENDPOINTS;
	public static final String HOST;

	static {
		ENDPOINTS = new Properties();
		try {
			ENDPOINTS.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(ENDPOINT_PROPS_FILENAME));
		} catch (IOException e) {
			Logger.logConsoleMessage(ExceptionUtils.getMessage(e));
		}
		HOST = getEndpoint(ENV_OF_INITIAL_ENDPOINT);
	}

	public static String getEndpoint(String env){
		return ENDPOINTS.getProperty(env);
	}

    public static String buildUrl(String url) {
        return (url.startsWith(HTTP) || url.startsWith(HTTPS)) ? url : Endpoint.HOST + url;
    }
    public static boolean isSecure(){
		return HOST.startsWith(HTTPS);
	}

}

