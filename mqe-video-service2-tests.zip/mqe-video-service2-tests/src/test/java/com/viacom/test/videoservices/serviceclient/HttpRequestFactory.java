package com.viacom.test.videoservices.serviceclient;

import com.viacom.test.core.lab.Logger;
import com.viacom.test.videoservices.model.test.types.HeaderType;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.PostPartType;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;
import org.apache.http.message.BasicHttpRequest;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringJoiner;

public class HttpRequestFactory {

    private static final String UTF_8 = "UTF-8";

    public static BasicHttpEntityEnclosingRequest create(HttpMethodNameType method, String url) {
        return new BasicHttpEntityEnclosingRequest(method.toString(), url);
    }

    public static BasicHttpEntityEnclosingRequest create(HttpMethodNameType method, URI uri) {
        return create(method, uri.toString());
    }

    public static void addHeaders(BasicHttpRequest request, Map<String, String> headerProps) {
        for (Entry<String, String> header : headerProps.entrySet()) {
            request.addHeader(header.getKey(), header.getValue());
        }
    }

    public static void addHeaders(BasicHttpRequest request, List<HeaderType> headers) {
        for (HeaderType header : headers) {
            request.addHeader(header.getName(), header.getValue());
        }
    }

    public static void addHeader(BasicHttpEntityEnclosingRequest request, String name, String value) {
        request.addHeader(name, value);
    }

    public static void setHeader(HttpRequestBase request, String name, String value) {
        request.setHeader(name, value);
    }

    public static BasicHttpEntityEnclosingRequest addParameters(BasicHttpRequest request, List<ParameterType> params) {

        String url = request.getRequestLine().getUri();

        StringJoiner queryParamsString = new StringJoiner("&");

        for (ParameterType param : params) {
            queryParamsString.add(param.getName() + "=" + param.getValue());
        }
        url = url + (url.contains("?") ? "&" : "?") + queryParamsString.toString();

        return create(HttpMethodNameType.valueOf(request.getRequestLine().getMethod()), url);
    }

    public static BasicHttpEntityEnclosingRequest addPostBody(BasicHttpEntityEnclosingRequest request, PostBodyType postbody) {
        if (postbody != null) {

            String stringBody = postbody.getString();
            List<PostPartType> parts = postbody.getPart();

            Logger.logMessage("Request Body: " + stringBody);

            if (stringBody != null) {
                HttpEntity entity;
                entity = new StringEntity(stringBody, UTF_8);
                request.setEntity(entity);
            }

            if (!parts.isEmpty()) {
                MultipartEntityBuilder multipartEntityBuilder = MultipartEntityBuilder.create();
                try {
                    addPostParts(multipartEntityBuilder, parts);
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
                request.setEntity(multipartEntityBuilder.build());
            }
        }
        return request;
    }

    private static void addPostParts(MultipartEntityBuilder multipartEntityBuilder, List<PostPartType> parts)
            throws UnsupportedEncodingException {
        for (PostPartType part : parts) {
            String partName = part.getName();
            String partValue = part.getValue();
            if (partName != null && partValue != null) {
                multipartEntityBuilder.addTextBody(partName, partValue, ContentType.TEXT_PLAIN);
                multipartEntityBuilder.setCharset(Charset.forName(UTF_8));
            }
        }
    }
}
