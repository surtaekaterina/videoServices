package com.viacom.test.videoservices.tests.deliveryservice;

import com.viacom.test.videoservices.constants.HeaderConstants;
import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorType;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import com.viacom.test.videoservices.utils.app.HostManager;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.constants.SymbolConstants.SPECIAL_SYMBOLS;
import static com.viacom.test.videoservices.utils.EncodeUtils.encodeToUTF8;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_TOKEN;
import static com.viacom.test.videoservices.utils.app.HostManager.getDeliveryHost;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;

public class MasterAndMediaPlaylistsSpecialSymbolsTest extends AbstractBaseTest {

    private String TEST_NAME = "DeliveryTests/special" + SPECIAL_SYMBOLS + "/" + UUID.randomUUID().toString();

    private VideoUrl videoUrl = new VideoUrl.Builder().setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194055").setHashcode("2607552757").build();

    private String MASTER_ORIGIN_PATH = DeliveryServiceUtils.getMasterPlaylistPath(encodeToUTF8(videoUrl.getUploadPath()), ",stream_384x216_194055_2607552757");
    private String MASTER_CDN_URL = DeliveryServiceUtils.getMasterPlaylistUrlWithToken(encodeToUTF8(videoUrl.getUploadPath()), ",stream_384x216_194055_2607552757");

    private String MEDIA_ORIGIN_PATH = DeliveryServiceUtils.getMediaPlaylistPath(encodeToUTF8(videoUrl.getUploadPath()), "stream_384x216_194055_2607552757");
    private String MEDIA_CDN_URL = DeliveryServiceUtils.getMediaPlaylistUrlWithToken(encodeToUTF8(videoUrl.getUploadPath()), "stream_384x216_194055_2607552757");

    private String MEDIA_URL = String.format("%sapi/playlist/%s/%s", getDeliveryHost(), videoUrl.getUploadPathEncoded(), videoUrl.getStreamName());

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl);
    }

    @BeforeClass(alwaysRun = true)
    public void packageVideoForMasterPlaylistSpecialSymbolsTest() {
        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);

        test.setUrl(HostManager.getProxyHost() + "proxy/addMessages");

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(postBodyProxyAddMessage(videoUrl));
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                "{\"message\":\"All messages added to queue\",\"success\":true}"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);


        test.setUrl(HostManager.getProxyHost() + "proxy/checkService");

        postBodyType.setString(postBodyProxyCheckService(videoUrl));
        test.setPostbody(postBodyType);

        FluentWait.create().withTimeout(120, SECONDS).pollingEvery(6, SECONDS)
                .until(new WaitForValidatorsPredicateImpl(test, of(new TextValidatorType(of(
                        new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"))))));
    }

    @Features(DELIVERY)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25939")
    @Test(groups = {DELIVERY}, enabled = false)
    public void masterPlaylistSpecialSymbolsTest() {
        masterPlaylistSpecialSymbolsTest(MASTER_ORIGIN_PATH);
    }

    @Features(DELIVERY)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25938")
    @Test(groups = {DELIVERY}, enabled = false)
    public void mediaPlaylistSpecialSymbolsTest() {
        mediaPlaylistSpecialSymbolsTest(MEDIA_ORIGIN_PATH);
    }

    @Features(DELIVERY_TOKEN)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("36455")
    @Test(groups = {DELIVERY_TOKEN}, enabled = false)
    public void masterPlaylistWithTokenSpecialSymbolsTest() {
        masterPlaylistSpecialSymbolsTest(MASTER_CDN_URL);
    }

    @Features(DELIVERY_TOKEN)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("37630")
    @Test(groups = {DELIVERY_TOKEN}, enabled = false)
    public void mediaPlaylistWithTokenSpecialSymbolsTest() {
        mediaPlaylistSpecialSymbolsTest(MEDIA_CDN_URL);
    }

    private void masterPlaylistSpecialSymbolsTest(String url) {
        TestType test = new TestType();

        test.setUrl(url);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=227171,BANDWIDTH=258197,FRAME-RATE=15,CODECS=\"avc1.42C00C,mp4a.40.5\",RESOLUTION=384x216"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, MEDIA_URL));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(headerValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }

    private void mediaPlaylistSpecialSymbolsTest(String url) {
        TestType test = new TestType();

        test.setUrl(url);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-PLAYLIST-TYPE:VOD"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-INDEPENDENT-SEGMENTS"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-TARGETDURATION:6"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(headerValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }
}
