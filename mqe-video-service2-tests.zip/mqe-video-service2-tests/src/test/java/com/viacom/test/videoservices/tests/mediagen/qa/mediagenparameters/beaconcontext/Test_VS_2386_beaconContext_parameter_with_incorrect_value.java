package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.beaconcontext;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathConstantType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.RegionUtils;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class Test_VS_2386_beaconContext_parameter_with_incorrect_value extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(BLOCKER)
    @TestCaseId("26458")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-2386: beaconContext parameter with incorrect value")
    public void test_VS_2386_beaconContext_parameter_with_incorrect_value() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl("services/MediaGenerator/mgid:arc:video:comedycentral.com:bc598e10-069f-484e-b91e-059ce24fbd13");
        //test.setNetwork("akamai");

        test.addParameter("device", "iPad");
        test.addParameter("beaconContext", "dgsgg234");
        test.addParameter("pkgOverride", "akamaidynpkg");
        test.addParameter("debug", "true");

        test.addHeader("X-Forwarded-For", RegionUtils.getIP("us"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "beaconContext=dgsgg234"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.NOT_CONTAINS, "//niagara.cc.com/register/comedycentral/clips/mgid:arc:video:comedycentral.com:bc598e10-069f-484e-b91e-059ce24fbd13"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.NOT_CONTAINS, "//mb.mtvnservices.com/data/collect/v1/data.gif?__t=me_niagara&u=mgid:arc:video:comedycentral.com:bc598e10-069f-484e-b91e-059ce24fbd13"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "https://cp541867-vh.akamaihd.net/"));
        v.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//item/rendition"));

        testRequest(test, v.getAll());
    }

}