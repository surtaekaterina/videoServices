package com.viacom.test.videoservices.model.test.types;

import com.viacom.test.videoservices.model.test.Rule;

public class ErrorSeamlessServiceValidatorRuleType extends Rule {
	
	protected ErrorSeamlessServiceValidatorRuleNameType name;
	protected String value;
	
	public ErrorSeamlessServiceValidatorRuleType(ErrorSeamlessServiceValidatorRuleNameType name) {
		this.name = name;
	}
	
	public ErrorSeamlessServiceValidatorRuleType(ErrorSeamlessServiceValidatorRuleNameType name, String value) {
		this.name = name;
		this.value = value;
	}
	
	public ErrorSeamlessServiceValidatorRuleNameType getName() {
		return name;
	}

	public void setName(ErrorSeamlessServiceValidatorRuleNameType value) {
		this.name = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
