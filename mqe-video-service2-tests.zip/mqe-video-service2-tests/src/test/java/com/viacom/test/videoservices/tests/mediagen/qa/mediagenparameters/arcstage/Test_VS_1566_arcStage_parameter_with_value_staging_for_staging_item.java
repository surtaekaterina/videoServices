package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.arcstage;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.RegionUtils;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class Test_VS_1566_arcStage_parameter_with_value_staging_for_staging_item extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26296")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-1566: arcStage parameter with value=staging for staging item")
    public void test_VS_1566_arcStage_parameter_with_value_staging_for_staging_item() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:spiketv.com:8dc50549-624e-45c1-a8c6-098e4c8b6e19");
        //test.setNetwork("akamai");

        test.addParameter(new ParameterType("device", "iPad"));
        test.addParameter(new ParameterType("arcPlatforms", "825b9f47-c092-4c68-bc1a-c6414a3bfbf9,43481e0a-01fd-4d71-81ef-727774bf10b1"));
        test.addParameter(new ParameterType("arcStage", "staging"));
        test.addParameter(new ParameterType("pkgOverride", "akamaidynpkg"));

        test.addHeader(new HeaderType("X-Forwarded-For", RegionUtils.getIP("us")));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "https://cp477482-vh.akamaihd.net"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);

        List<XpathValidatorRuleType> xpathValidatorRuleType = new ArrayList<>();
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//item/rendition"));
        XpathValidatorType xpathValidator = new XpathValidatorType(xpathValidatorRuleType);

        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);
        validators.add(xpathValidator);

        testRequest(test, validators);
    }
}