package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.authsuite_validation;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class EnforcingAuthInvalidAuthTokenRestrictedVideoTest extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(BLOCKER)
    @TestCaseId("22137870")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description("VS-5487: Enforcing Auth for the Namespace (enforceAuth:true, enableAuthLogging:false) - AuthToken is available for the request but invalid")

    public void checkAuthSuiteValidationForEnforcingAuthInvalidAuthTokenRestrictedVideoTest() {

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:noggin.us:aabda5f0-9973-11e3-83eb-0026b9414f30");

        test.addParameter("accountOverride", "nickjr.com");
        test.addParameter("ep", "2527aaac");
        test.addParameter("geo", "US");
        test.addParameter("arcStage", "authoring");
        test.addParameter("device", "iPad");
        test.addParameter("authPlatform", "ios");

        test.addHeader("X-VIA-TVE-MEDIATOKEN", "invalidAuthTokenValue");

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item", "Error - Auth failed or missing"));

        testRequest(test, v.getAll());

    }
}
