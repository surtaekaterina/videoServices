package com.viacom.test.videoservices.serviceclient;

import java.net.URI;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.StatusLine;

public class Response {

	private byte[] content;

	private StatusLine statusLine;

	private Header[] headers;

	private String contentType;
	
	private List<URI> redirectLocations;

	public List<URI> getRedirectLocations() {
		return redirectLocations;
	}

	public void setRedirectLocations(List<URI> redirectLocations) {
		this.redirectLocations = redirectLocations;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getContentString() {
		return content != null ? new String(content) : null;
	}

    public byte[] getContentByte() {
       return content;
    }

	public void setContent(byte[] content) {
		this.content = content;
	}

	public StatusLine getStatusLine() {
		return statusLine;
	}

	public void setStatusLine(StatusLine statusLine) {
		this.statusLine = statusLine;
	}

	public Header[] getHeaders() {
		return headers;
	}

	public void setHeaders(Header[] headers) {
		this.headers = headers;
	}

}
