package com.viacom.test.videoservices.model.test.types;

import java.util.ArrayList;
import java.util.List;

import com.viacom.test.videoservices.model.test.Validator;

public class EqualResponseValidatorType extends Validator {

	protected List<EqualResponseValidatorRuleType> rule;
	
	public EqualResponseValidatorType(List<EqualResponseValidatorRuleType> rule) {
		this.rule = rule;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EqualResponseValidatorRuleType> getRule() {
		if (rule == null) {
			rule = new ArrayList<EqualResponseValidatorRuleType>();
		}
		return this.rule;
	}

}
