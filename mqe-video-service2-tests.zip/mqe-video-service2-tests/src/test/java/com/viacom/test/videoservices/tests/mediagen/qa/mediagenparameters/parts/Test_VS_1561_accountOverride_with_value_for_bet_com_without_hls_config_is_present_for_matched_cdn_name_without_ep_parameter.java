package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.parts;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class Test_VS_1561_accountOverride_with_value_for_bet_com_without_hls_config_is_present_for_matched_cdn_name_without_ep_parameter extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26172")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-1561: accountOverride with value for bet.com without hls config is present for matched cdn name without ep parameter")
    public void test_VS_1561_accountOverride_with_value_for_bep_com_without_hls_config_is_present_for_matched_cdn_name_without_ep_parameter() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:nick-asia.com:7acfe8b6-4f52-4da9-8a14-59c7bd4f51f7");
        //test.setNetwork("akamai");

        test.addParameter(new ParameterType("accountOverride", "bep.com"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "addMediaRenditions(): formatted results for sourceUri: /intlod/MTVInternational/MBUS/TACTIC/201608/VIAMTVIPYC2799PFLT9/LoudHouse_MissionImpossibleSpot_INCHD1499-25_Original_20160810144051_384x216_400_m30.mp4 is null or blank"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}