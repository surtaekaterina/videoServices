package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;

public class ClosedCaptionsTest extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    public void captionsTtmlOnlyTest() {
        String captions = "<transcript kind=\"captions\" srclang=\"sw\" label=\"Swahili\">";

        TestType test = new TestType();

        //test.setUrl("services/MediaGenerator/mgid:arc:video:central:ed840685-e3ed-42db-b2cc-d90c315828c9");
        test.setUrl("services/MediaGenerator/mgid:arc:video:central:8d2138fd-1002-4b0b-bbc0-e15a7d7562aa");

        test.addParameter(new ParameterType("arcStage", "authoring"));
        test.addParameter(new ParameterType("nodp", "true"));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"ttml\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"vtt\""));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();
        validators.add(textValidator);

        testRequest(test, validators);
    }

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    public void captionsTtmlOnlyTranscriptTrueTest() {
        String captions1 = " <transcript role=\"captions\" format=\"TimedText\" lang=\"sw\" label=\"Swahili\" type=\"text/xml\"";
        String captions2 = " <transcript role=\"captions\" format=\"vtt\" lang=\"sw\" label=\"Swahili\" type=\"text/xml\"";

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:8d2138fd-1002-4b0b-bbc0-e15a7d7562aa");

        test.addParameter(new ParameterType("arcStage", "authoring"));
        test.addParameter(new ParameterType("nodp", "true"));
        test.addParameter(new ParameterType("transcript", "true"));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions1));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions2));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();
        validators.add(textValidator);

        testRequest(test, validators);
    }


    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    public void captionsTtmlDfxpTest() {
        String captions1 = "<transcript kind=\"captions\" srclang=\"sw\" label=\"Swahili\">";
        String captions2 = "<transcript kind=\"captions\" srclang=\"en\" label=\"English\">";

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:8d2138fd-1002-4b0b-bbc0-e15a7d7562aa");

        test.addParameter(new ParameterType("arcStage", "authoring"));
        test.addParameter(new ParameterType("nodp", "true"));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions1));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"ttml\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"vtt\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions2));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"ttml\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"vtt\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml&amp;accountName=central"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();
        validators.add(textValidator);

        testRequest(test, validators);
    }

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    public void captionsTtmlDfxpTranscriptTrueTest() {
        String captions1 = "<transcript role=\"captions\" format=\"TimedText\" lang=\"sw\" label=\"Swahili\" type=\"text/xml\"";
        String captions2 = "<transcript role=\"captions\" format=\"vtt\" lang=\"sw\" label=\"Swahili\" type=\"text/xml\"";
        String captions3 = "<transcript role=\"captions\" format=\"TimedText\" lang=\"en\" label=\"English\" type=\"text/xml\"";
        String captions4 = "<transcript role=\"captions\" format=\"vtt\" lang=\"en\" label=\"English\" type=\"text/xml\"";

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:8d2138fd-1002-4b0b-bbc0-e15a7d7562aa");

        test.addParameter(new ParameterType("arcStage", "authoring"));
        test.addParameter(new ParameterType("nodp", "true"));
        test.addParameter(new ParameterType("transcript", "true"));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions1));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions2));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions3));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions4));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml&amp;accountName=central"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();
        validators.add(textValidator);

        testRequest(test, validators);
    }


    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    public void captionsTtml2DfxpTest() {
        String captions1 = "<transcript kind=\"captions\" srclang=\"sw\" label=\"Swahili\">";
        String captions2 = " <transcript kind=\"captions\" srclang=\"en\" label=\"English\">";

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:8d2138fd-1002-4b0b-bbc0-e15a7d7562aa");

        test.addParameter(new ParameterType("arcStage", "authoring"));
        test.addParameter(new ParameterType("nodp", "true"));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions1));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions2));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"ttml\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"vtt\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"ttml\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"vtt\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml&amp;accountName=central"));
        //textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"ttml\""));
        //textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/NL/ni_kca2014_ocps_c07_subtitles_nl.dfxp.xml"));
        //textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<typographic format=\"vtt\""));
        //textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/NL/ni_kca2014_ocps_c07_subtitles_nl.dfxp.xml&amp;accountName=central"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();
        validators.add(textValidator);

        testRequest(test, validators);
    }

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    public void captionsTtml2DfxpTranscriptTrueTest() {
        String captions1 = "<transcript role=\"captions\" format=\"TimedText\" lang=\"sw\" label=\"Swahili\" type=\"text/xml\"";
        String captions2 = "<transcript role=\"captions\" format=\"vtt\" lang=\"sw\" label=\"Swahili\" type=\"text/xml\"";
        String captions3 = "<transcript role=\"captions\" format=\"TimedText\" lang=\"en\" label=\"English\" type=\"text/xml\"";
        String captions4 = "<transcript role=\"captions\" format=\"vtt\" lang=\"en\" label=\"English\" type=\"text/xml\"";
        String captions5 = "<transcript role=\"captions\" format=\"TimedText\" lang=\"en\" label=\"English\" type=\"text/xml\"";
        String captions6 = "<transcript role=\"captions\" format=\"vtt\" lang=\"en\" label=\"English\" type=\"text/xml\"";

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:central:8d2138fd-1002-4b0b-bbc0-e15a7d7562aa");

        test.addParameter(new ParameterType("arcStage", "authoring"));
        test.addParameter(new ParameterType("nodp", "true"));
        test.addParameter(new ParameterType("transcript", "true"));

        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions1));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions2));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions3));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions4));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions5));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions6));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml"));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml&amp;accountName=central"));
        //textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/NL/ni_kca2014_ocps_c07_subtitles_nl.dfxp.xml"));
        //textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ".mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/NL/ni_kca2014_ocps_c07_subtitles_nl.dfxp.xml&amp;accountName=central"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<Validator> validators = new ArrayList<>();
        validators.add(textValidator);

        testRequest(test, validators);
    }


//    @Features(MEDIAGEN_TESTS_QA)
//    @Severity(SeverityLevel.BLOCKER)
//    @TestCaseId("")
//    @Test(groups = {MEDIAGEN_TESTS_QA})
//    public void captionsTtmlSccDfxpTest() {
//        String captions = "<transcript kind=\"captions\" srclang=\"sw\" label=\"Swahili\">\n" +
//                "        <typographic format=\"ttml\" src=\"http://a14.akadl.mtvnservices.com/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml\"/>\n" +
//                "        <typographic format=\"vtt\" src=\"http://vs-tools.mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central\"/>\n" +
//                "      </transcript>\n" +
//                "      <transcript kind=\"captions\" srclang=\"en\" label=\"English\">\n" +
//                "        <typographic format=\"ttml\" src=\"http://a20.akadl.mtvnservices.com/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml\"/>\n" +
//                "        <typographic format=\"vtt\" src=\"http://vs-tools.mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml&amp;accountName=central\"/>\n" +
//                "        <typographic format=\"cea-608\" src=\"http://a9.akadl.mtvnservices.com/59003/mtvnorigin/gsp.spikecomstor/media/web/mma_uncensored/s01/e23/mma_uncensored_123_act4.SCC\"/>\n" +
//                "      </transcript>";
//
//        TestType test = new TestType();
//
//        test.setUrl("services/MediaGenerator/mgid:arc:video:central:5bde2902-35e4-49cb-a4fd-a50a0b967bd7");
//
//        test.addParameter(new ParameterType("arcStage", "authoring"));
//        test.addParameter(new ParameterType("nodp", "true"));
//
//        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
//        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions));
//        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);
//
//        List<Validator> validators = new ArrayList<>();
//        validators.add(textValidator);
//
//        testRequest(test, validators);
//    }
//
//    @Features(MEDIAGEN_TESTS_QA)
//    @Severity(SeverityLevel.BLOCKER)
//    @TestCaseId("")
//    @Test(groups = {MEDIAGEN_TESTS_QA})
//    public void captionsTtmlSccDfxpTranscriptTrueTest() {
//        String captions = " <transcript role=\"captions\" format=\"TimedText\" lang=\"sw\" label=\"English (CC)\" type=\"text/xml\" src=\"http://a14.akadl.mtvnservices.com/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml\"/>\n" +
//                "      <transcript role=\"captions\" format=\"vtt\" lang=\"sw\" label=\"English (CC)\" type=\"text/xml\" src=\"http://vs-tools.mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central\"/>\n" +
//                "      <transcript role=\"captions\" format=\"TimedText\" lang=\"en\" label=\"English (CC)\" type=\"text/xml\" src=\"http://a20.akadl.mtvnservices.com/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml\"/>\n" +
//                "      <transcript role=\"captions\" format=\"vtt\" lang=\"en\" label=\"English (CC)\" type=\"text/xml\" src=\"http://vs-tools.mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2014/subtitles/Orange-Carpet/ni_kca2014_ocps_c07_subtitles_sv.dfxp.xml&amp;accountName=central\"/>\n" +
//                "      <transcript role=\"captions\" format=\"scc\" lang=\"en\" label=\"English (CC)\" type=\"text/xml\" src=\"http://a9.akadl.mtvnservices.com/59003/mtvnorigin/gsp.spikecomstor/media/web/mma_uncensored/s01/e23/mma_uncensored_123_act4.SCC\"/>";
//
//        TestType test = new TestType();
//
//        test.setUrl("services/MediaGenerator/mgid:arc:video:central:5bde2902-35e4-49cb-a4fd-a50a0b967bd7");
//
//        test.addParameter(new ParameterType("arcStage", "authoring"));
//        test.addParameter(new ParameterType("nodp", "true"));
//        test.addParameter(new ParameterType("transcript", "true"));
//
//        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
//        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions));
//        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);
//
//        List<Validator> validators = new ArrayList<>();
//        validators.add(textValidator);
//
//        testRequest(test, validators);
//    }
//
//    @Features(MEDIAGEN_TESTS_QA)
//    @Severity(SeverityLevel.BLOCKER)
//    @TestCaseId("")
//    @Test(groups = {MEDIAGEN_TESTS_QA})
//    public void captionsTtmlSccTest() {
//        String captions = "      <transcript kind=\"captions\" srclang=\"sw\" label=\"Swahili\">\n" +
//                "        <typographic format=\"ttml\" src=\"http://a14.akadl.mtvnservices.com/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml\"/>\n" +
//                "        <typographic format=\"vtt\" src=\"http://vs-tools.mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central\"/>\n" +
//                "      </transcript>";
//
//        TestType test = new TestType();
//
//        test.setUrl("services/MediaGenerator/mgid:arc:video:central:b05ac9d4-85de-4252-b8a3-0a072e77fdb2");
//
//        test.addParameter(new ParameterType("arcStage", "authoring"));
//        test.addParameter(new ParameterType("nodp", "true"));
//
//        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
//        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, captions));
//        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);
//
//        List<Validator> validators = new ArrayList<>();
//        validators.add(textValidator);
//
//        testRequest(test, validators);
//    }
//
//    @Features(MEDIAGEN_TESTS_QA)
//    @Severity(SeverityLevel.BLOCKER)
//    @TestCaseId("")
//    @Test(groups = {MEDIAGEN_TESTS_QA})
//    public void captionsTtmlSccTranscriptTrueTest() {
//        TestType test = new TestType();
//
//        test.setUrl("services/MediaGenerator/mgid:arc:video:central:b05ac9d4-85de-4252-b8a3-0a072e77fdb2");
//
//        test.addParameter(new ParameterType("arcStage", "authoring"));
//        test.addParameter(new ParameterType("nodp", "true"));
//        test.addParameter(new ParameterType("transcript", "true"));
//
//        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
//        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<transcript role=\"captions\" format=\"TimedText\" lang=\"sw\" label=\"English (CC)\" type=\"text/xml\" src=\"http://a14.akadl.mtvnservices.com/59003/mtvnorigin/gsp.scenic/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml\"/>"));
//        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<transcript role=\"captions\" format=\"vtt\" lang=\"sw\" label=\"English (CC)\" type=\"text/xml\" src=\"http://vs-tools.mtvnservices.com/caption/convert?mgid=mgid:file:gsp:scenic:/international/kidschoiceawards.com/2017/subtitles/2017NickelodeonKCAs-ShowClip6KevinHartWinsFaveVillain_nb.ttml.xml&amp;accountName=central\"/>"));
//        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "<transcript role=\"captions\" format=\"scc\" lang=\"en\" label=\"English (CC)\" type=\"text/xml\" src=\"http://a9.akadl.mtvnservices.com/59003/mtvnorigin/gsp.spikecomstor/media/web/mma_uncensored/s01/e23/mma_uncensored_123_act4.SCC\"/>"));
//        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);
//
//        List<Validator> validators = new ArrayList<>();
//        validators.add(textValidator);
//
//        testRequest(test, validators);
//    }
}

