package com.viacom.test.videoservices.tests.deliveryservice.master;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.JsonComparisonValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonComparisonValidatorType;
import com.viacom.test.videoservices.model.test.types.JsonSchemaValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.ConfigProps.ENV_OF_INITIAL_ENDPOINT;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.COMPLETED_MGIDS_UPLOAD_PATH;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_4;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_4321;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_ROOT_384_X_216;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.DLVR_CDN_TEST1_ACCOUNT;
import static com.viacom.test.videoservices.utils.app.StaticPackagerUtils.checkStatus;

public class MasterPlaylist1PlaylistMissingDebugInfoTest extends AbstractBaseTest {

    private static final String PATH_TO_JSON = "./src/test/resources/testdata/deliveryservice/masterPlaylist1PlaylistMissingDebugInfo"
            + (ENV_OF_INITIAL_ENDPOINT.contains("vmn") ? "2" : "1") + ".json";

    @BeforeClass(alwaysRun = true)
    public void checkContentForMasterPlaylist1PlaylistMissingDebugInfoTest() {
        checkStatus(VIDEO_URL_4321, "Complete");
        checkStatus(VIDEO_URL_4, "Complete");
        checkStatus(VIDEO_URL_ROOT_384_X_216, "Complete");
    }

    @Features(DELIVERY)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("89897")
    @Test(groups = {DELIVERY})
    @Description(value = "https://jira.mtvi.com/browse/VS-4659")
    public void checkMasterPlaylist1PlaylistMissingDebugInfoTest() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistUrlWithToken(COMPLETED_MGIDS_UPLOAD_PATH, ",0/stream_480x310_616248,0/stream_384x216_403057_3469779259,4/3/2/1/0/stream_384x216_403057_3469779259,4/0/stream_384x216_403057_3469779259"));
        test.addParameter(new ParameterType("debug", "true"));
        test.addParameter(new ParameterType("account", DLVR_CDN_TEST1_ACCOUNT));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("404", "Not Found", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<JsonComparisonValidatorRuleType> jsonComparisonRule = new ArrayList<>();
        jsonComparisonRule.add(new JsonComparisonValidatorRuleType(JsonSchemaValidatorRuleNameType.FILE_SYSTEM, PATH_TO_JSON));
        JsonComparisonValidatorType jsonComparisonValidator = new JsonComparisonValidatorType(jsonComparisonRule);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(jsonComparisonValidator);

        testRequest(test, validators);
    }
}
