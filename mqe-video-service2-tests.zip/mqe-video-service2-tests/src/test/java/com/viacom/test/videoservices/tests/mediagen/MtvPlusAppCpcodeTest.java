package com.viacom.test.videoservices.tests.mediagen;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ContextExtractorParameterType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathConstantType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_LIVE;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class MtvPlusAppCpcodeTest extends AbstractBaseTest {


    @Features(MEDIAGEN_TESTS_LIVE)
    @Severity(BLOCKER)
    @TestCaseId("100968")
    @Test(groups = {MEDIAGEN_TESTS_LIVE, MEDIAGEN_TESTS_QA})
    public void mtvPlusAppCpcodeTest() {
        TestType mediagenTest = new TestType();
        Validators v = new Validators();

        mediagenTest.setUrl("services/MediaGenerator/mgid:arc:video:mtvplus.com:e868771f-7866-432b-8c55-6cbe8b9ed08c");

        mediagenTest.addParameter("ep", "dcc3faa5");
        mediagenTest.addParameter("device", "iPad7,2");
        mediagenTest.addParameter("pkgOverride", "akamaidynpkg");

        ContextExtractorParameterType masterUrl = new ContextExtractorParameterType();
        masterUrl.setName("masterUrl");
        masterUrl.setXpath("*//item/rendition/src/text()");

        mediagenTest.setContextextractor(getContextExtractors(of(masterUrl)));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item/rendition/src", "master.m3u8"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.CONTAINS, XpathConstantType.NODE, "*//item/rendition/src/text()", "http://mtvplus-vh.akamaihd.net/"));

        testRequest(mediagenTest, v.getAll());

        TestType masterTest = new TestType();
        v = new Validators();

        masterTest.setUrl("{$context:masterUrl}");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*http://mtvplus-vh.akamaihd.net/.*/index_0_av.m3u8[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*http://mtvplus-vh.akamaihd.net/.*/index_1_av.m3u8[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*http://mtvplus-vh.akamaihd.net/.*/index_2_av.m3u8[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*http://mtvplus-vh.akamaihd.net/.*/index_3_av.m3u8[\\s\\S]*"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*http://mtvplus-vh.akamaihd.net/.*/index_4_av.m3u8[\\s\\S]*"));

        testRequest(masterTest, v.getAll());
    }

}
