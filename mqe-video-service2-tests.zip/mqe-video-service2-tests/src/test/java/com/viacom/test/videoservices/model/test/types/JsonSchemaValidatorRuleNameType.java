package com.viacom.test.videoservices.model.test.types;

public enum JsonSchemaValidatorRuleNameType {

	URL("url"), FILE_SYSTEM("file_system"), STRING("string");
	private final String value;

	private JsonSchemaValidatorRuleNameType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}
	
}
