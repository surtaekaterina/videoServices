package com.viacom.test.videoservices.tests.deliveryservice.phase2;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ContextExtractorParameterType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrlP2;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.UUID;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.constants.HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN;
import static com.viacom.test.videoservices.constants.HeaderConstants.CONTENT_TYPE;
import static com.viacom.test.videoservices.constants.HeaderConstants.CONTENT_TYPE_IMAGE_JPEG;
import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.GET;
import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.POST;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_2;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.DLVR_CDN_TEST1_ACCOUNT;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.CDN.DEFAULT_CDN;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.defineTShost;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMediaPlaylistLink;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getPlaylistLink;
import static com.viacom.test.videoservices.utils.app.HostManager.getProxy2Host;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.THUMBS;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.VIDEO_AUDIO;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class DeliveryVideoAudioThumbsTest extends AbstractBaseTest {

    private String TEST_NAME = "DeliveryVideoAudioThumbsTest/" + UUID.randomUUID();

    private static final String MEDIA_URL_QUERY_PARAMETERS = "\\?tk=st=.*&";

    private VideoUrlP2 videoUrl_1 = new VideoUrlP2.Builder().setNamespaceAndUploadPathWithoutS3path(TEST_NAME + "/1")
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194055")
            .setPackageTypes(VIDEO_AUDIO, THUMBS).setLanguageCode("en").setHashcode("2607552757").build();

    private VideoUrlP2 videoUrl_2 = new VideoUrlP2.Builder().setNamespaceAndUploadPathWithoutS3path(TEST_NAME + "/2")
            .setBitrate("403063").setHashcode("3469779259").setFileName("384x216_278_30sec.mp4").setResolution("384x216")
            .setPackageTypes(VIDEO_AUDIO, THUMBS).setLanguageCode("en").build();

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl_1, videoUrl_2);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForDeliveryVideoAudioThumbsTest() {
        Validators addMsgV = new Validators();

        addMsgV.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        addMsgV.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, "Content-Type", "application/json"));
        addMsgV.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.success", "true"));

        TestType test = new TestType();
        test.setHttpMethod(POST);

        test.setUrl(getProxy2Host() + "proxy/addMessages");
        test.setPostbody(VideoUrlP2.postBodyProxyAddMessage(videoUrl_1, videoUrl_2));

        testRequest(test, addMsgV.getAll());

        test.setUrl(getProxy2Host() + "proxy/checkService");
        test.setPostbody(VideoUrlP2.postBodyProxyCheckService(videoUrl_1, videoUrl_2));

        FluentWait.create().withTimeout(180, SECONDS).pollingEvery(3, SECONDS).until(new WaitForValidatorsPredicateImpl
                (test, new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.CONTAINS, "$.renditions.length()", "2")));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkMasterVideoAudioThumbsTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194055_2607552757,1/0/audio/en_2607552757,1/0/thumbs/320x180_2607552757.vtt,1/0/thumbs/160x90_2607552757.vtt,2/0/thumbs/320x180_3469779259.vtt,2/0/thumbs/160x90_3469779259.vtt"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);
        test.addParameter("debug", "true");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:BANDWIDTH=260547,AVERAGE-BANDWIDTH=227955,CODECS=\"avc1.42c00c,mp4a.40.5\",RESOLUTION=384x216,AUDIO=\"audio\",NAME=\"en\",LANGUAGE=\"en\",FRAME-RATE=15"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_1).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"en\",NAME=\"en\",AUTOSELECT=YES,CHANNELS=\"2\",DEFAULT=YES,URI=\"" + getPlaylistLink(videoUrl_1.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#VIA-TRICKVTT:RESOLUTION=160x90,URI=\"" + getPlaylistLink(videoUrl_1.getThumbsUploadPath("160x90")).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#VIA-TRICKVTT:RESOLUTION=320x180,URI=\"" + getPlaylistLink(videoUrl_1.getThumbsUploadPath("320x180")).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#VIA-TRICKVTT:RESOLUTION=160x90,URI=\"" + getPlaylistLink(videoUrl_2.getThumbsUploadPath("160x90")).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#VIA-TRICKVTT:RESOLUTION=320x180,URI=\"" + getPlaylistLink(videoUrl_2.getThumbsUploadPath("320x180")).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                "################################################\n" +
                        "#DEBUG-INFO\n" +
                        "# STARTUP-BITRATE=600000\n" +
                        "# CDN:akamai\n" +
                        "# LANGUAGE:Not Specified\n" +
                        "#REQUIRED:\n" +
                        "# SIZE=6"));

        ContextExtractorParameterType e3 = new ContextExtractorParameterType();
        e3.setName("160x90");
        e3.setRegex(getPlaylistLink(videoUrl_1.getThumbsUploadPath("160x90")) + ".*(?=\")");

        ContextExtractorParameterType e4 = new ContextExtractorParameterType();
        e4.setName("320x180");
        e4.setRegex(getPlaylistLink(videoUrl_1.getThumbsUploadPath("320x180")) + ".*(?=\")");

        test.setContextextractor(getContextExtractors(of(e3, e4)));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkMasterVideoAudioThumbsTest")
    public void checkThumbs160x90Vtt() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("160x90"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "text/vtt"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.STARTS_WITH, "WEBVTT\n00:00:00.000 --> 00:00:03.000\n"));

        for (int i = 1; i < 11; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                    defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_1.getThumbsImgUploadPath("160x90", i)));
        }

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkMasterVideoAudioThumbsTest")
    public void checkThumbs320x180Vtt() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("320x180"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "text/vtt"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.STARTS_WITH, "WEBVTT\n00:00:00.000 --> 00:00:03.000\n"));

        for (int i = 1; i < 11; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                    defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_1.getThumbsImgUploadPath("320x180", i)));
        }

        testRequest(test, v.getAll());
    }


    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkMasterVideoAudioThumbsTest")
    public void checkhumbs320x180Images() {
        TestType test = new TestType();

        test.setHttpMethod(GET);

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, CONTENT_TYPE_IMAGE_JPEG));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        for (int i = 1; i < 11; i++) {
            test.setUrl(defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_1.getThumbsImgUploadPath("320x180", i));

            testRequest(test, v.getAll());
        }
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkMasterVideoAudioThumbsTest")
    public void checkThumbs160x90Images() {
        TestType test = new TestType();

        test.setHttpMethod(GET);

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, CONTENT_TYPE_IMAGE_JPEG));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        for (int i = 1; i < 11; i++) {
            test.setUrl(defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_1.getThumbsImgUploadPath("160x90", i));
            testRequest(test, v.getAll());
        }
    }
}


