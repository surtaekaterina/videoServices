package com.viacom.test.videoservices.tests.deliveryservice;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.POST;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_1;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_2;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class CorrectErrorForDubleRendTest extends AbstractBaseTest {

    private final String POST_BODY = "{\n" +
            "\"rend\": [\n" +
            "        \n" +
            "           \"" + VIDEO_URL_1.getNamespaceDecoded() + "\"\n" +
            "    ],\n" +
            "\"rend\": [\n" +
            "        \n" +
            "           \"" + VIDEO_URL_2.getNamespaceDecoded() + "\"\n" +
            "    ]\n" +
            "}";

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("345420")
    @Test(groups = {DELIVERY})
    public void checkRenditionsRequiredErrorForDubleRendTest() {
        TestType test = new TestType();

        test.setHttpMethod(POST);
        test.setUrl("api/check");
        test.setPostbody(POST_BODY);

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("400", "Bad Request", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"errors\":[\"renditions: field is required\"]"));

        testRequest(test, v.getAll());
    }
}
