package com.viacom.test.videoservices.tests.deliveryservice.master;


import com.viacom.test.videoservices.constants.HeaderConstants;
import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorType;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import com.viacom.test.videoservices.utils.app.HostManager;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.viacom.test.videoservices.utils.IProps.ConfigProps.ENV_OF_INITIAL_ENDPOINT;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.DLVR_CDN_TEST1_ACCOUNT;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMediaPlaylistLink;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class MasterPlaylistPositiveTest extends AbstractBaseTest {

    private static final String UNIQUE_NS_PATH = "MasterPlaylisPositiveTest/" + UUID.randomUUID().toString();

    private VideoUrl videoUrl01 = new VideoUrl.Builder().setDefaultNamespaceAndUploadPath(UNIQUE_NS_PATH)
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").setBitrate("403057").setHashcode("3469779259")
            .build();

    private VideoUrl videoUrl02 = new VideoUrl.Builder().setDefaultNamespaceAndUploadPath(UNIQUE_NS_PATH)
            .setFileName("480x320_646_2streams_High_29_97.mp4").setResolution("480x320").setBitrate("616248").setHashcode("247501290")
            .build();

    private VideoUrl videoUrl4 = new VideoUrl.Builder().setDefaultNamespaceAndUploadPath(UNIQUE_NS_PATH + "/4")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").setBitrate("403057").setHashcode("3469779259")
            .build();

    private VideoUrl videoUrl4321 = new VideoUrl.Builder().setDefaultNamespaceAndUploadPath(UNIQUE_NS_PATH + "/4/3/2/1")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").setBitrate("403057").setHashcode("3469779259")
            .build();

    private VideoUrl videoUrl4xx = new VideoUrl.Builder().setDefaultNamespaceAndUploadPath(UNIQUE_NS_PATH + "/4/x,x")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").setBitrate("403057").setHashcode("3469779259")
            .build();

    @AfterClass
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl01, videoUrl02, videoUrl4, videoUrl4321, videoUrl4xx);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForMasterPlaylistPositiveTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(HostManager.getProxyHost() + "proxy/addMessages");
        test.setHttpMethod(HttpMethodNameType.POST);

        test.setPostbody(postBodyProxyAddMessage(videoUrl01, videoUrl02, videoUrl4, videoUrl4321, videoUrl4xx));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}||\"message\":\"All messages have already been queued"));

        testRequest(test, v.getAll());

        test.setUrl(HostManager.getProxyHost() + "proxy/checkService");
        test.setPostbody(postBodyProxyCheckService(videoUrl01, videoUrl02, videoUrl4, videoUrl4321, videoUrl4xx));

        v = new Validators();
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"));
        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.renditions.length()", "5"));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS).until(new WaitForValidatorsPredicateImpl(test, v.getAll()));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("51681")
    @Test(groups = {DELIVERY})
    public void checkMasterWithStreamsFromDifferentFolders() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistPath("gsp.pkgtest/" + UNIQUE_NS_PATH, ",0/stream_480x320_616248_247501290,0/stream_384x216_403057_3469779259,4/3/2/1/0/stream_384x216_403057_3469779259,4/0/stream_384x216_403057_3469779259"));
        test.addParameter(new ParameterType("account", DLVR_CDN_TEST1_ACCOUNT));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS,
                HeaderConstants.CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST,
                HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "Created by Viacom Delivery Service"));

        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=471972,BANDWIDTH=1428332,FRAME-RATE=29.97,CODECS=\"avc1.64000D,mp4a.40.2\",RESOLUTION=384x216"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl01)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl4)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl4321)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=708436,BANDWIDTH=817678,FRAME-RATE=29.97,CODECS=\"avc1.640015,mp4a.40.2\",RESOLUTION=480x320"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl02)));

        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);
        validators.add(headerValidator);

        testRequest(test, validators);
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("51681")
    @Test(groups = {DELIVERY})
    public void checkMasterWithStreamsOneOfContainsEncodedComma() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistPath("gsp.pkgtest/" + UNIQUE_NS_PATH, ",0/stream_384x216_403057_3469779259,4/3/2/1/0/stream_384x216_403057_3469779259,4/x%2Cx/0/stream_384x216_403057_3469779259"));
        test.addParameter(new ParameterType("account", DLVR_CDN_TEST1_ACCOUNT));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS,
                HeaderConstants.CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST,
                HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "Created by Viacom Delivery Service"));

        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=471972,BANDWIDTH=1428332,FRAME-RATE=29.97,CODECS=\"avc1.64000D,mp4a.40.2\",RESOLUTION=384x216"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl01)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl4321)));

        String playlistWithComma = getMediaPlaylistLink(videoUrl4xx);
        if (ENV_OF_INITIAL_ENDPOINT.contains("dev")) {
            playlistWithComma = playlistWithComma.replaceAll("x,x", "x%2Cx");
        }

        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, playlistWithComma));

        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);
        validators.add(headerValidator);

        testRequest(test, validators);
    }
}
