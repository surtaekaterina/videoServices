package com.viacom.test.videoservices.tests.mediagen.qa.inspectmedia;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.model.test.types.XpathConstantType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.XpathValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.INSPECT_MEDIA_QA;

public class Test_MOBSERV_781_InspectMedia_Implement_Metadata_Xml_Response extends AbstractBaseTest {

    @Features(INSPECT_MEDIA_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26088")
    @Test(groups = {INSPECT_MEDIA_QA})
    @Description("MOBSERV-781 InspectMedia: Implement Metadata Xml Response")
    public void test_MOBSERV_781_InspectMedia_Implement_Metadata_Xml_Response() {
        TestType test = new TestType();

        test.setUrl("services/InspectMedia/microsoft/mtv.com/mgid:arc:episode:spiketv.com:fc73b9cf-14d0-41f2-b44b-b7e1112f0e04");


        test.addParameter(new ParameterType("metadata", "xml"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "type=\"video/mp4\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "format=\"mp4_h264_main\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "bitrate=\"750\""));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);


        List<XpathValidatorRuleType> xpathValidatorRuleType = new ArrayList<>();
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "/metadata"));
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EQUALS, XpathConstantType.NUMBER, "count(/metadata/rendition)", "1"));
        XpathValidatorType xpathValidator = new XpathValidatorType(xpathValidatorRuleType);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(xpathValidator);

        testRequest(test, validators);
    }
}