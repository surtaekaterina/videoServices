package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.parts;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class Test_VS_1561_accountOverride_with_value_for_cookie_less_cpcode_is_present_for_matched_cdn_name extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26143")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-1561: accountOverride with value for cookie-less cpcode is present for matched cdn name")
    public void test_VS_1561_accountOverride_with_value_for_cookie_less_cpcode_is_present_for_matched_cdn_name() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:nick-asia.com:7acfe8b6-4f52-4da9-8a14-59c7bd4f51f7");
        //test.setNetwork("akamai");

        test.addParameter(new ParameterType("accountOverride", "nick.com"));
        test.addParameter(new ParameterType("device", "iPad"));
        //test.addParameter(new ParameterType("pkgOverride", "akamaidynpkg"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "https://cp479184-vh.akamaihd.net||dlvrsvc"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);

        List<XpathValidatorRuleType> xpathValidatorRuleType = new ArrayList<>();
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//item/rendition"));
        XpathValidatorType xpathValidator = new XpathValidatorType(xpathValidatorRuleType);
        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);
        validators.add(xpathValidator);

        testRequest(test, validators);
    }
}