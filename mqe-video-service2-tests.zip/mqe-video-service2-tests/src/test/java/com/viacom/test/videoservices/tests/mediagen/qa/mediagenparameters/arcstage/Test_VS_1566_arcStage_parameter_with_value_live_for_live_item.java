package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.arcstage;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class Test_VS_1566_arcStage_parameter_with_value_live_for_live_item extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26285")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-1566: arcStage parameter with value=live for live item")
    public void test_VS_1566_arcStage_parameter_with_value_live_for_live_item() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:nick.com:93fbd742-3e52-4ee5-9839-63ad2a5a7246");
        //test.setNetwork("akamai");

        test.addParameter(new ParameterType("device", "iPad"));
        test.addParameter(new ParameterType("arcStage", "live"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "method=\"hls\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "https://cp479184-vh.akamaihd.net||dlvrsvc||dlvrsvc"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);

        List<XpathValidatorRuleType> xpathValidatorRuleType = new ArrayList<>();
        xpathValidatorRuleType.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//item/rendition"));
        XpathValidatorType xpathValidator = new XpathValidatorType(xpathValidatorRuleType);

        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);
        validators.add(xpathValidator);

        testRequest(test, validators);
    }
}