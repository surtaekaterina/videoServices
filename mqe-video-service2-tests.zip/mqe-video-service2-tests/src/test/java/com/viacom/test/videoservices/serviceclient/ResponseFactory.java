package com.viacom.test.videoservices.serviceclient;

import com.viacom.test.videoservices.constants.HeaderConstants;
import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.io.InputStream;

import static com.viacom.test.videoservices.utils.HttpUtils.isTextContent;

public class ResponseFactory {

    public static Response create(HttpClientContext httpContext, boolean isReadByteResponse) {
        Response response = new Response();
        HttpResponse httpResponse = httpContext.getResponse();
        String responseContentType = getContentType(httpResponse);

        response.setContentType(responseContentType);
        response.setStatusLine(httpResponse.getStatusLine());
        response.setHeaders(httpResponse.getAllHeaders());
        response.setRedirectLocations(httpContext.getRedirectLocations());

        if (isReadByteResponse || isTextContent(responseContentType)) {
            HttpEntity entity = httpResponse.getEntity();
            if (entity != null) {
                copyContent(entity, response);
            }
        }
        return response;
    }

	private static void copyContent(HttpEntity entity, Response response) {
		InputStream content;
		byte[] bytes;
		try {
			content = entity.getContent();
			bytes = IOUtils.toByteArray(content);
			response.setContent(bytes);
			EntityUtils.consume(entity);
		} catch (IllegalStateException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static String getContentType(HttpResponse httpResponse) {
		String responseContentType = "";
		Header[] contentTypeHeaders = httpResponse.getHeaders(HeaderConstants.CONTENT_TYPE);
		if (contentTypeHeaders != null && contentTypeHeaders.length > 0) {
			return contentTypeHeaders[0].getValue();
		}
		return responseContentType;
	}

}
