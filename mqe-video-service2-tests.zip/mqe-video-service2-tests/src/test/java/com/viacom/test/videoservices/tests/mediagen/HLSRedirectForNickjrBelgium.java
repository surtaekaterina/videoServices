package com.viacom.test.videoservices.tests.mediagen;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.*;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class HLSRedirectForNickjrBelgium extends AbstractBaseTest {

    @Features({MEDIAGEN_TESTS_LIVE})
    @Severity(BLOCKER)
    @TestCaseId("102230")
    @Test(groups = {MEDIAGEN_TESTS_QA, MEDIAGEN_TESTS_LIVE, DEV_BROKEN})
    @Description("VS-4794 Support HLS redirect for My NickJr via MediaGen - Belgium")
    public void checkHLSRedirectMynickjrBelg1000Test() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl("services/MediaGenerator/mgid:arc:video:nickjr.be:14ec178e-37a7-11e7-a442-0e40cf2fc285");

        test.addParameter("ep", "976bb76b");
        test.addParameter("acceptMethods", "hls");
        test.addParameter("maxBitrate", "1000");
        test.addParameter("format", "redirect");
        test.addParameter("accountOverride", "intl.mtvi.com");
        test.addParameter("pkgOverride", "akamaidynpkg");

        v.add(new StatusLineValidatorRuleType("302", null, "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, "Location",
                "https://cp450888-vh.akamaihd.net/i/mtviestor/_!/intlod/won-intl/bubble_guppies/bubble_guppies_1/104_bubble_guppies_104/ABC161952/ABC161952_nl-NL_,320x240_150,480x360_370,576x432_900,.mp4.csmil/master.m3u8"));

        testRequest(test, v.getAll());
    }

    @Features(MEDIAGEN_TESTS_LIVE)
    @Severity(BLOCKER)
    @TestCaseId("102230")
    @Test(groups = {MEDIAGEN_TESTS_QA, MEDIAGEN_TESTS_LIVE, DEV_BROKEN})
    @Description("VS-4794 Support HLS redirect for My NickJr via MediaGen - Belgium")
    public void checkHLSRedirectMynickjrBelg10000Test() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl("services/MediaGenerator/mgid:arc:video:nickjr.be:14ec178e-37a7-11e7-a442-0e40cf2fc285");

        test.addParameter("ep", "976bb76b");
        test.addParameter("acceptMethods", "hls");
        test.addParameter("maxBitrate", "10000");
        test.addParameter("format", "redirect");
        test.addParameter("accountOverride", "intl.mtvi.com");
        test.addParameter("pkgOverride", "akamaidynpkg");

        v.add(new StatusLineValidatorRuleType("302", null, "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, "Location",
                "https://cp450888-vh.akamaihd.net/i/mtviestor/_!/intlod/won-intl/bubble_guppies/bubble_guppies_1/104_bubble_guppies_104/ABC161952/ABC161952_nl-NL_,320x240_150,480x360_370,576x432_900,640x480_1330,768x576_1800,.mp4.csmil/master.m3u8"));

        testRequest(test, v.getAll());
    }

}
