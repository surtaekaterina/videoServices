package com.viacom.test.videoservices.constants;

public final class QueryConstants {

    private QueryConstants() {
    }

}
