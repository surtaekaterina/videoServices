package com.viacom.test.videoservices.model.test.types;

public enum ErrorSeamlessServiceValidatorRuleNameType {

	CACHEBUSTING("ord"), ASSETURI("asseturi"), TIMESTAMP("offset"), ERRORCODE("cn");
	private final String value;

	ErrorSeamlessServiceValidatorRuleNameType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static ErrorSeamlessServiceValidatorRuleNameType fromValue(String v) {
		for (ErrorSeamlessServiceValidatorRuleNameType c : ErrorSeamlessServiceValidatorRuleNameType.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v.toString());
	}
	
}
