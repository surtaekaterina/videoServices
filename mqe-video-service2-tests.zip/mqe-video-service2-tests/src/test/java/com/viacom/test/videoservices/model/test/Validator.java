package com.viacom.test.videoservices.model.test;

import java.util.List;

public abstract class Validator {

	public abstract <T extends Rule> List<T> getRule();

}
