package com.viacom.test.videoservices.tests.deliveryservice.submit;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.HostManager;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.constants.URLConstants.S3_SMALLEST_MP4_FILE_URL;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;

public class SubmitVideosFieldNotArrayTest extends AbstractBaseTest {

    private static String NAMESPACE = "mgid:file:gsp:pkgtest:/SubmitVideosFieldNotArrayTest/384x216_278.mp4";

    private static final String POST_BODY = "{\"videos\": { \"url\": \"" + S3_SMALLEST_MP4_FILE_URL + "\", \"mgid\": \"" + NAMESPACE + "\" }  }";

    private static final String EXPECTED_RP_BODY = "{\"errors\":[\"videos: 'videos' must be an Array\"]}";

    @Features(DELIVERY)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25966")
    @Test(groups = {DELIVERY})
    public void submitVideosFieldNotArrayTest() {
        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);

        test.setUrl(HostManager.getDeliveryOriginHost() + "api/submit");

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(POST_BODY);
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("400", "Bad Request", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.EQUALS, EXPECTED_RP_BODY));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }
}
