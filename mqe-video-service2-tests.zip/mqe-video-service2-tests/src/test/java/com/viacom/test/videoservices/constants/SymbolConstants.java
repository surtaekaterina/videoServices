package com.viacom.test.videoservices.constants;

public final class SymbolConstants {

	private SymbolConstants() {
	}

	public static final String FILE_SEPERATOR_SYMBOL = System.getProperty("file.separator");

	public static final String LESS_THAN_SYMBOL = "<";

	public static final String GREATER_THAN_SYMBOL = ">";

	public static final String LESS_THAN_SIGH = "&lt;";

	public static final String GREATER_THAN_SIGH = "&gt;";

	public static final String OR_SPLITTER_SYMBOL = "\\|\\|";

	public static final String OR_SYMBOL = "||";

	public static final String FILE_SEPARATOR_REG_EXP = "\\\\|\\/";

	public static final String QUESTION_SYMBOL = "?";

	public static final String QUESTION_ESCAPE_SYMBOL = "\\?";

	public static final String AND_SYMBOL = "&";

	public static final String EQUAL_SYMBOL = "=";

    public static final String SLASH_SYMBOL = "/";

	public static final String SPECIAL_SYMBOLS = "?!-_.,:;*'()[]{}&~#$=@^|%+\\";

}
