package com.viacom.test.videoservices.model.test.types;

import com.viacom.test.videoservices.model.test.Validator;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ByteValidatorType", propOrder = { "rule" })
public class ByteValidatorType extends Validator {
    protected List<ByteValidatorRuleType> rule;

    public ByteValidatorType() {
    }

    public ByteValidatorType(List<ByteValidatorRuleType> rules) {
        this.rule = rules;
    }

    public void setRule(List<ByteValidatorRuleType> rule) {
        this.rule = rule;
    }

    @SuppressWarnings("unchecked")
    public List<ByteValidatorRuleType> getRule() {
        if (rule == null) {
            rule = new ArrayList<ByteValidatorRuleType>();
        }
        return this.rule;
    }
}
