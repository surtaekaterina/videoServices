package com.viacom.test.videoservices.tests.deliveryservice.phase2;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ContextExtractorParameterType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrlP2;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.UUID;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.constants.HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN;
import static com.viacom.test.videoservices.constants.HeaderConstants.CONTENT_TYPE;
import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.POST;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_2;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.DLVR_CDN_TEST1_ACCOUNT;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.CDN.DEFAULT_CDN;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.defineTShost;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMasterPlaylistPathPhase2;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMediaPlaylistLink;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getPlaylistLink;
import static com.viacom.test.videoservices.utils.app.HostManager.getKeyServiceHost;
import static com.viacom.test.videoservices.utils.app.HostManager.getProxy2Host;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.VIDEO_AUDIO;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class DeliveryVideoAudioTest extends AbstractBaseTest {

    private String TEST_NAME = "DeliveryVideoAudioPhase2Test" + UUID.randomUUID();

    private static final String ACCOUNT_AND_CDN = "account=" + DLVR_CDN_TEST1_ACCOUNT + "&cdn=" + DEFAULT_CDN;

    private static final String MEDIA_URL_QUERY_PARAMETERS = "\\?tk=st=.*&" + ACCOUNT_AND_CDN;

    private VideoUrlP2 videoUrl_1 = new VideoUrlP2.Builder().setNamespaceAndUploadPathWithoutS3path(TEST_NAME + "/1")
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194070")
            .setPackageTypes(VIDEO_AUDIO).setHashcode("2607552757").setLanguageCode("en").build();

    private VideoUrlP2 videoUrl_2 = new VideoUrlP2.Builder().setNamespaceAndUploadPathWithoutS3path(TEST_NAME + "/2")
            .setBitrate("403063").setHashcode("3469779259").setFileName("384x216_278_30sec.mp4").setResolution("384x216")
            .setPackageTypes(VIDEO_AUDIO).setLanguageCode("es").build();

    private VideoUrlP2 videoUrl_3 = new VideoUrlP2.Builder().setNamespaceAndUploadPathWithoutS3path(TEST_NAME + "/3")
            .setBitrate("403063").setHashcode("3469779259").setFileName("384x216_278_30sec.mp4").setResolution("384x216")
            .setPackageTypes(VIDEO_AUDIO).setLanguageCode("en").build();

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl_1, videoUrl_2);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForDEliveryVideoAudioTest() {
        Validators addMsgV = new Validators();

        addMsgV.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        addMsgV.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, "Content-Type", "application/json"));
        addMsgV.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.success", "true"));

        TestType test = new TestType();
        test.setHttpMethod(POST);

        test.setUrl(getProxy2Host() + "proxy/addMessages");
        test.setPostbody(VideoUrlP2.postBodyProxyAddMessage(videoUrl_1, videoUrl_2, videoUrl_3));

        testRequest(test, addMsgV.getAll());

        test.setUrl(getProxy2Host() + "proxy/checkService");
        test.setPostbody(VideoUrlP2.postBodyProxyCheckService(videoUrl_1, videoUrl_2, videoUrl_3));

        FluentWait.create().withTimeout(180, SECONDS).pollingEvery(3, SECONDS).until(new WaitForValidatorsPredicateImpl
                (test, new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.CONTAINS, "$.renditions.length()", "3")));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("36046")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test6_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,1/0/audio/en_2607552757"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:BANDWIDTH=260547,AVERAGE-BANDWIDTH=227955,CODECS=\"avc1.42c00c,mp4a.40.5\",RESOLUTION=384x216,AUDIO=\"audio\",FRAME-RATE=15"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_1).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"en\",NAME=\"en\",AUTOSELECT=YES,CHANNELS=\"2\",DEFAULT=YES,URI=\"" + getPlaylistLink(videoUrl_1.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));

        ContextExtractorParameterType e1 = new ContextExtractorParameterType();
        e1.setName("audio_stream_6");
        e1.setRegex(getPlaylistLink(videoUrl_1.getAudioStreamUploadPath()) + ".*(?=\")");

        ContextExtractorParameterType e2 = new ContextExtractorParameterType();
        e2.setName("video_stream_6");
        e2.setRegex(getMediaPlaylistLink(videoUrl_1) + ".*");

        test.setContextextractor(getContextExtractors(of(e1, e2)));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2Test6_Master")
    public void checkPhase2Test6_VideoM3u8() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("video_stream_6"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-PLAYLIST-TYPE:VOD"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-INDEPENDENT-SEGMENTS"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-TARGETDURATION:6"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-MEDIA-SEQUENCE:0"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-ENDLIST"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                String.format("#EXT-X-KEY:METHOD=AES-128,URI=\"%sget/encrypt.key?acl=%s&tk=", getKeyServiceHost(), videoUrl_1.getUploadPath())));

        for (int i = 0; i < 5; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_1.getTsUploadPathByIndex(i)));
        }

        ContextExtractorParameterType e1 = new ContextExtractorParameterType();
        e1.setName("key_video_6");
        e1.setRegex(getKeyServiceHost() + ".*(?=\\\")");

        test.setContextextractor(getContextExtractors(of(e1)));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2Test6_Master")
    public void checkPhase2Test6_AudioM3u8() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("audio_stream_6"));

        test.addParameter("debug", "true");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U\n#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-TARGETDURATION:6\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-MEDIA-SEQUENCE:0"));


        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS,
                String.format("#EXT-X-KEY:METHOD=AES-128,URI=\"%sget/encrypt.key?acl=%s&tk=", getKeyServiceHost(), videoUrl_1.getUploadPath())));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTINF:6.037000,"));

        for (int i = 0; i < 5; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_1.getAudioTsUploadPathByIndex(i)));
        }

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-ENDLIST"));

        ContextExtractorParameterType e1 = new ContextExtractorParameterType();
        e1.setName("key_audio_6");
        e1.setRegex(getKeyServiceHost() + ".*(?=\\\")");
        test.setContextextractor(getContextExtractors(of(e1)));

        testRequest(test, v.getAll());
    }


    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2Test6_AudioM3u8")
    public void checkPhase2Test6_Key() {

        String key_video = testContext.getValueFromContext("key_audio_6");
        String key_audio = testContext.getValueFromContext("key_audio_6");

        Assert.assertEquals(key_video, key_audio, "Key url from audio and video streams is different");

        TestType test = new TestType();
        test.setIsReadByteResponse(true);
        test.setUrl(key_video);

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/octet-stream"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, "Content-Length", "16"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.NOT_EQUALS, ""));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2Test6_AudioM3u8")
    public void checkPhase2Test6_videoTSs() {
        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "video/MP2T"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        for (int i = 0; i < 5; i++) {
            TestType test = new TestType();
            test.setUrl(defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_1.getTsUploadPathByIndex(i));
            test.setIsReadByteResponse(false);
            testRequest(test, v.getAll());
        }
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkPhase2Test6_AudioM3u8")
    public void checkPhase2Test6_audioTSs() {
        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "video/MP2T"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        for (int i = 0; i < 5; i++) {
            TestType test = new TestType();
            test.setUrl(defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_1.getAudioTsUploadPathByIndex(i));
            test.setIsReadByteResponse(false);
            testRequest(test, v.getAll());
        }
    }

    //=======================

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test6_Es_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,2/0/audio/es_3469779259"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:BANDWIDTH=260547,AVERAGE-BANDWIDTH=227955,CODECS=\"avc1.42c00c,mp4a.40.5\",RESOLUTION=384x216,AUDIO=\"audio\",FRAME-RATE=15"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_1).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"es\",NAME=\"es\",AUTOSELECT=YES,CHANNELS=\"2\",DEFAULT=YES,URI=\"" + getPlaylistLink(videoUrl_2.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));

        testRequest(test, v.getAll());
    }

    //====================

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test1_Es_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,2/0/audio/es_3469779259"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);
        test.addParameter("lang", "en");

        v.add(new StatusLineValidatorRuleType("404", "Not Found", "HTTP"));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test1_En_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,1/0/audio/en_2607552757"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);
        test.addParameter("lang", "es");

        v.add(new StatusLineValidatorRuleType("404", "Not Found", "HTTP"));

        testRequest(test, v.getAll());
    }

    //==============

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test7_Es_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,2/0/audio/es_3469779259"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);
        test.addParameter("lang", "valera");

        v.add(new StatusLineValidatorRuleType("404", "Not Found", "HTTP"));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test7_En_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,1/0/audio/en_2607552757"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);
        test.addParameter("lang", "valera");

        v.add(new StatusLineValidatorRuleType("404", "Not Found", "HTTP"));

        testRequest(test, v.getAll());
    }

    //==============

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test2_En_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,2/0/audio/es_3469779259,1/0/audio/en_2607552757,3/0/audio/en_3469779259"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);

        test.addParameter("lang", "en");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:BANDWIDTH=260547,AVERAGE-BANDWIDTH=227955,CODECS=\"avc1.42c00c,mp4a.40.5\",RESOLUTION=384x216,AUDIO=\"audio\",FRAME-RATE=15"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_1).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"en\",NAME=\"en\",AUTOSELECT=YES,CHANNELS=\"2\",DEFAULT=YES,URI=\"" + getPlaylistLink(videoUrl_3.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"en\",NAME=\"en\",AUTOSELECT=YES,CHANNELS=\"2\",URI=\"" + getPlaylistLink(videoUrl_1.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"es\",NAME=\"es\",AUTOSELECT=YES,CHANNELS=\"2\",URI=\"" + getPlaylistLink(videoUrl_2.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test2_Es_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,2/0/audio/es_3469779259,1/0/audio/en_2607552757"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);

        test.addParameter("lang", "es");

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:BANDWIDTH=260547,AVERAGE-BANDWIDTH=227955,CODECS=\"avc1.42c00c,mp4a.40.5\",RESOLUTION=384x216,AUDIO=\"audio\",FRAME-RATE=15"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_1).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"en\",NAME=\"en\",AUTOSELECT=YES,CHANNELS=\"2\",URI=\"" + getPlaylistLink(videoUrl_1.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"es\",NAME=\"es\",AUTOSELECT=YES,CHANNELS=\"2\",DEFAULT=YES,URI=\"" + getPlaylistLink(videoUrl_2.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));

        testRequest(test, v.getAll());
    }

    //====================

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkPhase2Test4_Master() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_194070_2607552757,2/0/audio/es_3469779259,1/0/audio/en_2607552757"));

        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);

        test.addParameter("debug", "true");

        v.add(new StatusLineValidatorRuleType("404", "Not Found", "HTTP"));

        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.downloaded.size", "3"));
        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.error", "Default audio playlist not found."));

        testRequest(test, v.getAll());
    }

}



