package com.viacom.test.videoservices.tests.deliveryservice.master;

import com.viacom.test.videoservices.constants.HeaderConstants;
import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.HeaderType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorType;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import com.viacom.test.videoservices.utils.app.HostManager;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrl;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.viacom.test.videoservices.constants.HeaderConstants.PRAGMA_HEADER;
import static com.viacom.test.videoservices.constants.HeaderConstants.PRAGMA_VALUE;
import static com.viacom.test.videoservices.constants.HeaderConstants.X_SECRET_PRAGMA_HEADER;
import static com.viacom.test.videoservices.constants.HeaderConstants.X_SECRET_PRAGMA_VALUE;
import static com.viacom.test.videoservices.utils.IProps.ConfigProps.ENV_OF_INITIAL_ENDPOINT;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.DLVR_CDN_TEST1_ACCOUNT;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMediaPlaylistLink;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyAddMessage;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyProxyCheckService;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class MasterPlaylistWithCustomStartupBitrateTest extends AbstractBaseTest {

    private static String TEST_NAME = "DeliveryTests/custom_startup_bitrate/" + UUID.randomUUID();

    private static VideoUrl videoUrl_1 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setBitrate("194055").setHashcode("2607552757").build();

    private static VideoUrl videoUrl_2 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("320x240_2880_3streams_Main_29_97.mp4").setResolution("320x240").setBitrate("281456").setHashcode("1694877362").build();

    private static VideoUrl videoUrl_3 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("480x360_5067_3streams_Main_29_97.mp4").setResolution("480x360").setBitrate("485528").setHashcode("329765914").build();

    private static VideoUrl videoUrl_4 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("512x288_7483_2streams_Main_29_97.mp4").setResolution("512x288").setBitrate("800660").setHashcode("3063207450").build();

    private static VideoUrl videoUrl_5 = new VideoUrl.Builder()
            .setNamespaceAndUploadPathWithoutS3path(TEST_NAME)
            .setFileName("576x432_1012_3streams_Main_29_97.mp4").setResolution("576x432").setBitrate("984448").setHashcode("1561092532").build();

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl_1, videoUrl_2, videoUrl_3, videoUrl_4, videoUrl_5);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForMasterPlaylistWithCustomStartupBitrateTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(HostManager.getProxyHost() + "proxy/addMessages");
        test.setHttpMethod(HttpMethodNameType.POST);
        test.setPostbody(postBodyProxyAddMessage(videoUrl_1, videoUrl_2, videoUrl_3, videoUrl_4, videoUrl_5));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"message\":\"All messages added to queue\",\"success\":true}"));

        testRequest(test, v.getAll());

        test.setUrl(HostManager.getProxyHost() + "proxy/checkService");
        test.setPostbody(postBodyProxyCheckService(videoUrl_1, videoUrl_2, videoUrl_3, videoUrl_4, videoUrl_5));

        v = new Validators();
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "\"complete\":true"));
        v.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.renditions.length()", "5"));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(6, SECONDS).until(new WaitForValidatorsPredicateImpl(test, v.getAll()));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("73473")
    @Test(groups = {DELIVERY})
    public void checkMasterPlaylistWithCustomStartupBitrate300Test() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistPath(videoUrl_1, videoUrl_2, videoUrl_3, videoUrl_4, videoUrl_5));

        test.addParameter(new ParameterType("startupBitrate", "300"));
        test.addParameter(new ParameterType("account", DLVR_CDN_TEST1_ACCOUNT));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, HeaderConstants.CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*Created by Viacom Delivery Service.*\\s#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=360453[\\s\\S]*")); //check that first playlist is the list with AVERAGE-BANDWIDTH closest to 600kbps (default value)

        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=227171,BANDWIDTH=258197,FRAME-RATE=15,CODECS=\"avc1.42C00C,mp4a.40.5\",RESOLUTION=384x216"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_1)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=360453,BANDWIDTH=437994,FRAME-RATE=29.97,CODECS=\"avc1.4D401E,mp4a.40.2\",RESOLUTION=320x240"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_2)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289,BANDWIDTH=644220,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=480x360"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_3)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=856035,BANDWIDTH=1067284,FRAME-RATE=29.97,CODECS=\"avc1.4D001E,mp4a.40.2\",RESOLUTION=512x288"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_4)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=1129143,BANDWIDTH=1208040,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=576x432"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_5)));

        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);
        validators.add(headerValidator);

        testRequest(test, validators);
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("73474")
    @Test(groups = {DELIVERY})
    public void checkMasterPlaylistWithDefaultStartupBitrateCDNTest() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistUrlWithToken(videoUrl_1, videoUrl_2, videoUrl_3, videoUrl_4, videoUrl_5));

        test.addParameter(new ParameterType("account", DLVR_CDN_TEST1_ACCOUNT));

        test.addHeader(new HeaderType(PRAGMA_HEADER, PRAGMA_VALUE));
        test.addHeader(new HeaderType(X_SECRET_PRAGMA_HEADER, X_SECRET_PRAGMA_VALUE));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, HeaderConstants.CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*Created by Viacom Delivery Service.*\\s#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289[\\s\\S]*"));

        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=227171,BANDWIDTH=258197,FRAME-RATE=15,CODECS=\"avc1.42C00C,mp4a.40.5\",RESOLUTION=384x216"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_1)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=360453,BANDWIDTH=437994,FRAME-RATE=29.97,CODECS=\"avc1.4D401E,mp4a.40.2\",RESOLUTION=320x240"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_2)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289,BANDWIDTH=644220,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=480x360"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_3)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=856035,BANDWIDTH=1067284,FRAME-RATE=29.97,CODECS=\"avc1.4D001E,mp4a.40.2\",RESOLUTION=512x288"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_4)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=1129143,BANDWIDTH=1208040,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=576x432"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_5)));

        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);
        validators.add(headerValidator);

        testRequest(test, validators);
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("73474")
    @Test(groups = {DELIVERY}, dependsOnMethods = "checkMasterPlaylistWithDefaultStartupBitrateCDNTest")
    public void checkMasterPlaylistWithCustomStartupBitrate400CDNTest() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistUrlWithToken(videoUrl_1, videoUrl_2, videoUrl_3, videoUrl_4, videoUrl_5));

        test.addParameter(new ParameterType("startupBitrate", "400"));
        test.addParameter(new ParameterType("account", DLVR_CDN_TEST1_ACCOUNT));

        test.addHeader(new HeaderType(PRAGMA_HEADER, PRAGMA_VALUE));
        test.addHeader(new HeaderType(X_SECRET_PRAGMA_HEADER, X_SECRET_PRAGMA_VALUE));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, HeaderConstants.CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        if (!ENV_OF_INITIAL_ENDPOINT.contains("dev") && !ENV_OF_INITIAL_ENDPOINT.contains("int-uat")) {
            headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, HeaderConstants.X_CACHE_KEY, "startupBitrate=400"));
        }

        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*Created by Viacom Delivery Service.*\\s#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=360453[\\s\\S]*"));

        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=227171,BANDWIDTH=258197,FRAME-RATE=15,CODECS=\"avc1.42C00C,mp4a.40.5\",RESOLUTION=384x216"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_1)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=360453,BANDWIDTH=437994,FRAME-RATE=29.97,CODECS=\"avc1.4D401E,mp4a.40.2\",RESOLUTION=320x240"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_2)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289,BANDWIDTH=644220,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=480x360"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_3)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=856035,BANDWIDTH=1067284,FRAME-RATE=29.97,CODECS=\"avc1.4D001E,mp4a.40.2\",RESOLUTION=512x288"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_4)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=1129143,BANDWIDTH=1208040,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=576x432"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_5)));

        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);
        validators.add(headerValidator);

        testRequest(test, validators);
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("73474")
    @Test(groups = {DELIVERY}, dependsOnMethods = "checkMasterPlaylistWithCustomStartupBitrate400CDNTest")
    public void checkMasterPlaylistWithCustomStartupBitrate800CDNTest() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistUrlWithToken(videoUrl_1, videoUrl_2, videoUrl_3, videoUrl_4, videoUrl_5));

        test.addParameter(new ParameterType("startupBitrate", "800"));
        test.addParameter(new ParameterType("account", DLVR_CDN_TEST1_ACCOUNT));

        test.addHeader(new HeaderType(PRAGMA_HEADER, PRAGMA_VALUE));
        test.addHeader(new HeaderType(X_SECRET_PRAGMA_HEADER, X_SECRET_PRAGMA_VALUE));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, HeaderConstants.CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        if (!ENV_OF_INITIAL_ENDPOINT.contains("dev") && !ENV_OF_INITIAL_ENDPOINT.contains("int-uat")) {
            headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, HeaderConstants.X_CACHE_KEY, "startupBitrate=800"));
        }

        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, "[\\s\\S]*Created by Viacom Delivery Service.*\\s#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=856035[\\s\\S]*"));

        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=227171,BANDWIDTH=258197,FRAME-RATE=15,CODECS=\"avc1.42C00C,mp4a.40.5\",RESOLUTION=384x216"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_1)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=360453,BANDWIDTH=437994,FRAME-RATE=29.97,CODECS=\"avc1.4D401E,mp4a.40.2\",RESOLUTION=320x240"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_2)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=585289,BANDWIDTH=644220,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=480x360"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_3)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=856035,BANDWIDTH=1067284,FRAME-RATE=29.97,CODECS=\"avc1.4D001E,mp4a.40.2\",RESOLUTION=512x288"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_4)));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-STREAM-INF:AVERAGE-BANDWIDTH=1129143,BANDWIDTH=1208040,FRAME-RATE=29.97,CODECS=\"avc1.4D401F,mp4a.40.2\",RESOLUTION=576x432"));
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, getMediaPlaylistLink(videoUrl_5)));

        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);
        validators.add(headerValidator);

        testRequest(test, validators);
    }
}
