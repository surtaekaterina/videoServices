package com.viacom.test.videoservices.tests.mediagen.qa.mediagenparameters.deviceanddeviceosversion;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.ServiceValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_PARAMETERS_QA;

public class Test_VS_2319_device_parameter_with_value_iPod_and_deviceOsVersion_41deviceOsVersion_is_not_available_for_device_iPod extends AbstractBaseTest {

    @Features(MEDIAGEN_PARAMETERS_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26326")
    @Test(groups = {MEDIAGEN_PARAMETERS_QA})
    @Description("VS-2319: device parameter with value=iPod and deviceOsVersion=4,1(deviceOsVersion is not available for device=iPod)")
    public void test_VS_2319_device_parameter_with_value_iPod_and_deviceOsVersion_41deviceOsVersion_is_not_available_for_device_iPod() {
        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:mtv.com:421a1c9d-7add-4342-9cfc-39bde96912f5");
        //test.setNetwork("akamai");

        test.addParameter(new ParameterType("device", "iPod"));
        test.addParameter(new ParameterType("deviceOsVersion", "4,1"));


        List<TextValidatorRuleType> textValidatorRuleTypes = new ArrayList<>();
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "code=\"not_playable\""));
        textValidatorRuleTypes.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "Sorry, this video is not available for iPod"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleTypes);

        List<ServiceValidatorRuleType> serviceValidatorRuleTypes = new ArrayList<>();
        serviceValidatorRuleTypes.add(new ServiceValidatorRuleType(ServiceValidatorRuleNameType.CONTAINS, "Status: VALIDATION_PASSED"));
        ServiceValidatorType serviceValidator = new ServiceValidatorType(serviceValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(textValidator);
        validators.add(serviceValidator);

        testRequest(test, validators);
    }
}