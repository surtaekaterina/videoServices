package com.viacom.test.videoservices.model.test.types;

import com.viacom.test.videoservices.model.test.Rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JsonValidatorRuleType")
public class JsonPathValidatorRuleType extends Rule {

    @XmlAttribute(required = true)
    protected String jsonPath;
    @XmlAttribute(required = true)
    protected JsonPathValidatorRuleNameType name;
    @XmlAttribute()
    protected String value;
    @XmlAttribute()
    protected String regExp;
    @XmlAttribute()
    protected int itemPosition;

    public JsonPathValidatorRuleType(JsonPathValidatorRuleNameType name, String jsonPath, String value) {
        this.name = name;
        this.jsonPath = jsonPath;
        this.value = value;
    }

    public JsonPathValidatorRuleType(JsonPathValidatorRuleNameType name, String jsonPath, String value, String regExp, int itemPosition) {
        this.name = name;
        this.jsonPath = jsonPath;
        this.value = value;
        this.regExp = regExp;
        this.itemPosition = itemPosition;
    }
    
    public JsonPathValidatorRuleType(JsonPathValidatorRuleNameType name, String jsonPath) {
        this.name = name;
        this.jsonPath = jsonPath;
    }

    public String getJsonPath() {
        return jsonPath;
    }

    public void setJsonPath(String jsonPath) {
        this.jsonPath = jsonPath;
    }

    public JsonPathValidatorRuleNameType getName() {
        return name;
    }

    public void setName(JsonPathValidatorRuleNameType name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getRegExp() {
        return regExp;
    }

    public void setRegExp(String regExp) {
        this.regExp = regExp;
    }

    public int getItemPosition() {
        return itemPosition;
    }

    public void setItemPosition(int itemPosition) {
        this.itemPosition = itemPosition;
    }
}
