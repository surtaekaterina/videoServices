package com.viacom.test.videoservices.model;

import java.util.List;

public class WebVttContent {

	private boolean isAdSegment;
	private String segmentUrl;
	private String webVttHeader;
	private List<String> webVttSegContent;
	private float entireDuration;
	private float duration;
	
	public WebVttContent(boolean isAdSegment, String segmentUrl, String webVttHeader, float entireDuration, float duration) {
		this.isAdSegment = isAdSegment;
		this.segmentUrl = segmentUrl;
		this.webVttHeader = webVttHeader;
		this.entireDuration = entireDuration;
		this.duration = duration;
	}
	
	public WebVttContent (boolean isAdSegment, String segmentUrl, String webVttHeader, float entireDuration, float duration, List<String> webVttSegContent) {
		this(isAdSegment, segmentUrl, webVttHeader, entireDuration, duration);
		this.webVttSegContent = webVttSegContent;
	}

	public List<String> getWebVttSegContent() {
		return webVttSegContent;
	}

	public void setWebVttSegContent(List<String> webVttSegContent) {
		this.webVttSegContent = webVttSegContent;
	}

	public String getWebVttHeader() {
		return webVttHeader;
	}

	public void setWebVttHeader(String webVttHeader) {
		this.webVttHeader = webVttHeader;
	}

	public String getSegmentUrl() {
		return segmentUrl;
	}

	public void setSegmentUrl(String segmentUrl) {
		this.segmentUrl = segmentUrl;
	}

	public boolean isAdSegment() {
		return isAdSegment;
	}

	public void setAdSegment(boolean isAdSegment) {
		this.isAdSegment = isAdSegment;
	}

	public float getEntireDuration() {
		return entireDuration;
	}

	public void setEntireDuration(float entireDuration) {
		this.entireDuration = entireDuration;
	}

	public float getDuration() {
		return duration;
	}

	public void setDuration(float duration) {
		this.duration = duration;
	}
	
	
}
