package com.viacom.test.videoservices.tests.deliveryservice.readyfordeliverycheck;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.HostManager;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_1;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_2;

public class UncompletedMgidsDeliveryTest extends AbstractBaseTest {

    private static final String NONEXISTENT_NAMESPACE = "mgid:file:gsp:nonexistent:/nonexistent/nonexistent.mp4";

    private static final String POST_BODY = "{\n" +
            "    \"renditions\": [\n" +
            "           \"" + VIDEO_URL_1.getNamespaceDecoded() + "\",\n" +
            "           \"" + VIDEO_URL_2.getNamespaceDecoded() + "\",\n" +
            "           \"" + NONEXISTENT_NAMESPACE + "\"\n" +
            "    ]\n" +
            "}";

    private static final String EXPECTED_RP_BODY = "{\"complete\":false}";

    @Features(DELIVERY)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25945")
    @Test(groups = {DELIVERY})
    public void checkNonexistentMgidDeliveryTest() {
        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);

        test.setUrl(HostManager.getDeliveryOriginHost() + "api/check");

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(POST_BODY);
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("404", "Not Found", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.EQUALS, EXPECTED_RP_BODY));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }
}
