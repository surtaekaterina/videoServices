package com.viacom.test.videoservices.model.test;

public abstract class Rule {

}
