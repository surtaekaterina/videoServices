package com.viacom.test.videoservices.tests.mediagen.qa.mediagentests.authsuite_validation;

import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.*;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.MEDIAGEN_TESTS_QA;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class NotEnforcingAuthInvalidAuthTokenFreeVideoTest extends AbstractBaseTest {

    @Features(MEDIAGEN_TESTS_QA)
    @Severity(BLOCKER)
    @TestCaseId("22137874")
    @Test(groups = {MEDIAGEN_TESTS_QA})
    @Description("VS-5487: Not Enforcing Auth for the Namespace (enforceAuth:false, enableAuthLogging:false) - AuthToken is available for the request but invalid")

    public void checkAuthSuiteValidationForNotEnforcingAuthInvalidAuthTokenFreeVideoTest() {

        TestType test = new TestType();

        test.setUrl("services/MediaGenerator/mgid:arc:video:mtv.com:e4fba896-181c-42d5-a7e2-58d3972e03fb");

        test.addParameter("arcPlatforms", "all");
        test.addParameter("acceptMethods", "hls");
        test.addParameter("arcStage", "authoring");
        test.addParameter("geo", "US");
        test.addParameter("authPlatform", "desktop");
        test.addParameter("nodp", "true");

        test.addHeader("X-VIA-TVE-MEDIATOKEN", "invalidAuthTokenValue");

        Validators v = new Validators();

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.NOT_CONTAINS, XpathConstantType.NODE, "*//item", "Error - Auth failed or missing"));
        v.add(new XpathValidatorRuleType(XpathValidatorRuleNameType.EXIST, XpathConstantType.NODESET, "*//rendition"));

        testRequest(test, v.getAll());
    }

}
