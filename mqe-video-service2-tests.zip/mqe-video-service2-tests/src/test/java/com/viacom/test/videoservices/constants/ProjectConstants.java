package com.viacom.test.videoservices.constants;

public final class ProjectConstants {

	private ProjectConstants() {
	}
		
}
