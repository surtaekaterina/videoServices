package com.viacom.test.videoservices.tests;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.viacom.test.core.lab.Logger;
import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ContextExtractorParameterType;
import com.viacom.test.videoservices.model.test.types.ContextExtractorType;
import com.viacom.test.videoservices.model.test.types.HeaderType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.serviceclient.Endpoint;
import com.viacom.test.videoservices.serviceclient.Response;
import com.viacom.test.videoservices.utils.HttpUtils;
import com.viacom.test.videoservices.utils.PropertyUtils;
import com.viacom.test.videoservices.utils.XmlUtils;
import com.viacom.test.videoservices.utils.XpathUtils;
import com.viacom.test.videoservices.utils.app.MediagenHostUtils;
import com.viacom.test.videoservices.utils.test.TestContext;
import com.viacom.test.videoservices.utils.test.TestTypeUtils;
import com.viacom.test.videoservices.validation.ValidatorExecution;
import org.testng.Assert;
import org.testng.SkipException;

import javax.xml.xpath.XPathExpressionException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public abstract class AbstractBaseTest {

	private static final String HEADER_PROPERTIES = "src/test/resources/header.properties";
	
	protected TestContext testContext = new TestContext();
	   
	protected <T extends Validator> void testRequest(TestType test, List<Validator> validators) {

        String testNetwork = test.getNetwork();
        String mediagenHostNetwork = MediagenHostUtils.getEndpointType();

        if (mediagenHostNetwork != null && !testNetwork.equals("all")) {
            if (!testNetwork.equalsIgnoreCase(mediagenHostNetwork)) {
                String message = String.format("Test requires Mediagen Network: %s, actual Mediagen host is: %s",
                        testNetwork, mediagenHostNetwork);
                Logger.logMessage(message);
                throw new SkipException(message);
            }
        }

        if (test.isSecure() && !Endpoint.isSecure()) {
            String message = "This test requires HTTPS host";
            Logger.logMessage(message);
            throw new SkipException(message);
        }

        String url = Endpoint.buildUrl(test.getUrl());
        url = testContext.processValue(url);

        if (null != mediagenHostNetwork && url.contains(Endpoint.HOST)) {
            url = HttpUtils.encodeQueriesValues(url);
        }

        test.setUrl(url);

        processHeadersByTestContext(test.getHeader(), testContext);
		processPostBodyByTestContext(test.getPostbody(), testContext);
		
		Map<String, String> headers = PropertyUtils.getProperties(HEADER_PROPERTIES, false);
		addHeadersFromMapToTestHeaders(headers, test.getHeader());
		
		Response response = TestTypeUtils.executeHttpRequest(test);
		String validateMessage = ValidatorExecution.execute(validators, response);

        if(!validateMessage.isEmpty()){
            Assert.fail(validateMessage);
        }
        try {
            populateContext(test.getContextExtractor(), response, testContext);
        } catch (XPathExpressionException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

	private void processHeadersByTestContext(List<HeaderType> headers, TestContext testContext) {    	
        if (headers == null || headers.isEmpty()) {
            return;
        }
        
        for (HeaderType h : headers) {
        	h.setName(h.getName());
        	h.setValue(testContext.processValue(h.getValue()));
            Logger.logMessage("Request has header - " + h.getName() + " : " + h.getValue());
        }
    }  
    
    private void processPostBodyByTestContext(PostBodyType postBodyType, TestContext testContext) {
    	if (null != postBodyType && null != postBodyType.getString()) {
    		postBodyType.setString(testContext.processBody(postBodyType.getString()));
    	}
    }  
    
    private void addHeadersFromMapToTestHeaders(Map<String, String> headers, List<HeaderType> testHeaders) {
		if (null == headers || headers.isEmpty() || null == testHeaders) {
			return;
		}
		
		List<String> nameOfHeadersInTest = testHeaders.stream().map(HeaderType::getName).collect(Collectors.toList());
		for (Entry<String, String> headerEntry : headers.entrySet()) {
			String headerName = headerEntry.getKey();
			String headerValue = headerEntry.getValue();
			if (!nameOfHeadersInTest.contains(headerName)) {
				testHeaders.add(new HeaderType(headerName, headerValue));
			}
		}
	}
    
    private void populateContext(List<ContextExtractorType> contextExtractors, Response response, TestContext testContext) throws XPathExpressionException {
        if (contextExtractors != null) {
            for (ContextExtractorType ctx : contextExtractors) {
                List<ContextExtractorParameterType> parameters = ctx.getParameter();
                for (ContextExtractorParameterType parameter : parameters) {
                    if (parameter != null) {
                        String xpath = parameter.getXpath();
                        String regex = parameter.getRegex();
                        String jsonpath = parameter.getJsonpath();
                        String value = null;
                        if (xpath != null) {
                            value = XpathUtils.getNodeValue(XmlUtils.loadXMLFromString(response.getContentString()), xpath);
                        }
                        if (regex != null) {
                            Pattern p = Pattern.compile(regex);
                            Matcher m = p.matcher(response.getContentString());
                            if (m.find()) {
                                value = m.group();
                            }
                        }
                        if (jsonpath != null) {
                            try {
                                value = JsonPath.read(response.getContentString(), jsonpath).toString();
                            } catch (PathNotFoundException pe) {
                            }
                        }
                        testContext.putToContext(parameter.getName(), value);
                    }
                }
            }
        }
    }

    protected List<ContextExtractorType> getContextExtractors(List<ContextExtractorParameterType> c) {
        ContextExtractorType contextExtractorType = new ContextExtractorType();
        contextExtractorType.setParameter(c);

		List<ContextExtractorType> contextextractor = new ArrayList<>();
		contextextractor.add(contextExtractorType);
		
		return contextextractor;
    }

    protected List<ContextExtractorType> getContextExtractors(ContextExtractorParameterType... c) {
        return getContextExtractors(Arrays.asList(c));
    }

}