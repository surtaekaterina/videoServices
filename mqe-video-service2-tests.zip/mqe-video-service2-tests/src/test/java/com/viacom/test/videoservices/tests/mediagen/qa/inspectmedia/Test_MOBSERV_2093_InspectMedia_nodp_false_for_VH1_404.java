package com.viacom.test.videoservices.tests.mediagen.qa.inspectmedia;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.INSPECT_MEDIA_QA;

public class Test_MOBSERV_2093_InspectMedia_nodp_false_for_VH1_404 extends AbstractBaseTest {

    @Features(INSPECT_MEDIA_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26377")
    @Test(groups = {INSPECT_MEDIA_QA})
    @Description("MOBSERV-2093 InspectMedia nodp=false for VH1, 404")
    public void test_MOBSERV_2093_InspectMedia_nodp_false_for_VH1_404() {
        TestType test = new TestType();

        test.setUrl("services/InspectMedia/unicorn/vh1.com/mgid:uma:video:vh1.com:901981");

        test.setSetFollowRedirects(false);

        test.setNetwork("origin");

        test.addParameter(new ParameterType("bypass", "true"));


        List<StatusLineValidatorRuleType> statusLineValidatorRuleTypes = new ArrayList<>();
        statusLineValidatorRuleTypes.add(new StatusLineValidatorRuleType("404", null, "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(statusCodeValidator);

        testRequest(test, validators);
    }
}