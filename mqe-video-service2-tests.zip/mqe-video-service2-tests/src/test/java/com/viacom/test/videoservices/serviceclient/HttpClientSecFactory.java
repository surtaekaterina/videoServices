package com.viacom.test.videoservices.serviceclient;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;


public class HttpClientSecFactory {

	public static HttpClientBuilder create(HttpClientSecType type) {
		
		HttpClientBuilder httpClientBuilder = null;
		
		switch(type) {
		
		case TRUST_SSL:
			httpClientBuilder = getHttpClientTrustSSL();
			break;
		case COMMON_HTTP:
			httpClientBuilder = HttpClients.custom();
			break;
		default:
			break;				
		}
		
		return httpClientBuilder;
	}

	
	private static HttpClientBuilder getHttpClientTrustSSL() {
		
		SSLContextBuilder builder = new SSLContextBuilder();
		try {
			builder.loadTrustMaterial(null, new TrustStrategy(){
				@Override
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			});
		} catch (NoSuchAlgorithmException | KeyStoreException e) {
			e.printStackTrace();
		}
		
		SSLConnectionSocketFactory sslsf = null;
		try {
			sslsf = new SSLConnectionSocketFactory(builder.build(), SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		} catch (KeyManagementException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return HttpClients.custom().setSSLSocketFactory(sslsf);
	}
}
