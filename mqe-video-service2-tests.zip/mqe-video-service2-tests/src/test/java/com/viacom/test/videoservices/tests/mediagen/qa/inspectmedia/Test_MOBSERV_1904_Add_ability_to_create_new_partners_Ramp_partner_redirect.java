package com.viacom.test.videoservices.tests.mediagen.qa.inspectmedia;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HeaderType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.INSPECT_MEDIA_QA;

public class Test_MOBSERV_1904_Add_ability_to_create_new_partners_Ramp_partner_redirect extends AbstractBaseTest {

    @Features(INSPECT_MEDIA_QA)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("26406")
    @Test(groups = {INSPECT_MEDIA_QA})
    @Description("MOBSERV-1904 Add ability to create new partners: Ramp partner redirect")
    public void test_MOBSERV_1904_Add_ability_to_create_new_partners_Ramp_partner_redirect() {
        TestType test = new TestType();

        test.setUrl("services/InspectMedia/ramp/mtv.com/mgid:uma:video:mtv.com:989457");

        test.setSetFollowRedirects(false);

        test.setNetwork("origin");


        test.addHeader(new HeaderType("True-Client-IP", "207.211.41.253"));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleTypes = new ArrayList<>();
        statusLineValidatorRuleTypes.add(new StatusLineValidatorRuleType("302", null, "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleTypes);


        List<Validator> validators = new ArrayList<>();

        validators.add(statusCodeValidator);

        testRequest(test, validators);
    }
}