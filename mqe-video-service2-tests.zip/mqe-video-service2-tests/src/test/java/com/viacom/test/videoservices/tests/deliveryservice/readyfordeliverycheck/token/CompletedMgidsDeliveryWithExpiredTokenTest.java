

package com.viacom.test.videoservices.tests.deliveryservice.readyfordeliverycheck.token;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HttpMethodNameType;
import com.viacom.test.videoservices.model.test.types.PostBodyType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.TokenGenerator;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_TOKEN;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_1;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_2;
import static com.viacom.test.videoservices.utils.app.CompletedMgids.VIDEO_URL_3;
import static com.viacom.test.videoservices.utils.app.VideoUrl.postBodyDlvrApiCheck;

public class CompletedMgidsDeliveryWithExpiredTokenTest extends AbstractBaseTest {

    private static final String PATH = TokenGenerator.getUrlPathWithExpiredTokenForDeliveryService("api/check");

    @Features(DELIVERY_TOKEN)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25955")
    @Test(groups = {DELIVERY_TOKEN})
    public void checkCompletedWorkflowsDeliveryWithExpiredTokenTest() {

        TestType test = new TestType();

        test.setHttpMethod(HttpMethodNameType.POST);

        test.setUrl(PATH);

        PostBodyType postBodyType = new PostBodyType();
        postBodyType.setString(postBodyDlvrApiCheck(VIDEO_URL_1, VIDEO_URL_2, VIDEO_URL_3));
        test.setPostbody(postBodyType);

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("403", "Forbidden", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "An error occurred while processing your request."));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }
}
