package com.viacom.test.videoservices.tests.deliveryservice.master;

import com.viacom.test.videoservices.model.test.Validator;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorType;
import com.viacom.test.videoservices.model.test.types.ParameterType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TextValidatorType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.ArrayList;
import java.util.List;

import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.DLVR_CDN_TEST1_ACCOUNT;

public class MasterPlaylistNonExistentPathTest extends AbstractBaseTest {

    @Features(DELIVERY)
    @Severity(SeverityLevel.BLOCKER)
    @TestCaseId("25946")
    @Test(groups = {DELIVERY})
    public void masterPlaylistNonExistentPathTest() {
        TestType test = new TestType();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistPath("gsp.pkgtest/DeliveryTests/nonexistent/folder", ",stream_384x216_194055_2607552757,stream_480x320_616248_247501290"));
        test.addParameter(new ParameterType("account", DLVR_CDN_TEST1_ACCOUNT));

        List<StatusLineValidatorRuleType> statusLineValidatorRuleType = new ArrayList<>();
        statusLineValidatorRuleType.add(new StatusLineValidatorRuleType("404", "Not Found", "HTTP"));
        StatusLineValidatorType statusCodeValidator = new StatusLineValidatorType(statusLineValidatorRuleType);

        List<HeaderValidatorRuleType> headerValidatorRuleType = new ArrayList<>();
        headerValidatorRuleType.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, "Edge-Control", "cache-maxage=1m,!no-store"));
        HeaderValidatorType headerValidator = new HeaderValidatorType(headerValidatorRuleType);

        List<TextValidatorRuleType> textValidatorRuleType = new ArrayList<>();
        textValidatorRuleType.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "{\"errors\":[\"Playlist not found.\"]}"));
        TextValidatorType textValidator = new TextValidatorType(textValidatorRuleType);

        List<Validator> validators = new ArrayList<>();
        validators.add(statusCodeValidator);
        validators.add(headerValidator);
        validators.add(textValidator);

        testRequest(test, validators);
    }
}
