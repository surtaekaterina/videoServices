package com.viacom.test.videoservices.listeners;

import com.viacom.test.core.lab.Logger;
import com.viacom.test.core.utils.RandomDataUtils;
import com.viacom.test.videoservices.utils.IProps;
import com.viacom.test.videoservices.utils.IProps.ConfigProps;
import com.viacom.test.videoservices.utils.TestIDs;
import org.apache.commons.lang3.ArrayUtils;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.IResultMap;
import org.testng.IRetryAnalyzer;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.internal.ResultMap;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class TestListener implements IRetryAnalyzer, ITestListener, IInvokedMethodListener {

	private static final String RUN_PROPS = "runProps";
	private static final int MAX_COUNT = ConfigProps.RERUN_ON_FAILURE_COUNT;
	private Map<String, AtomicInteger> retries = new HashMap<>();
	private IResultMap failedCases = new ResultMap();

	@Override
	public void onTestStart(ITestResult result) {
		Logger.logConsoleMessage("========NEW TEST========");
        String testHash = RandomDataUtils.getCharacterString(20);

		result.setAttribute(RUN_PROPS, new Object[] { ConfigProps.ENV_OF_INITIAL_ENDPOINT });
		String id = IProps.StaticProps.TEST_ID + " " + result.getMethod().getMethodName() + " " + "(" + testHash + ")";

		TestIDs.setTestId(id.toLowerCase());
		Logger.logConsoleMessage(TestIDs.getTestId());
	}

	@Override
	public void onTestSuccess(ITestResult iTestResult) {
		Logger.logConsoleMessage("========SUCCESS========");
		TestIDs.addPassedTest(TestIDs.getTestId());
	}

	@Override
	public void onTestFailure(ITestResult result) {
		Logger.logConsoleMessage("========FAILURE========");
		// check if the test should be re-executed based on retry logic
		if (result.getMethod().getRetryAnalyzer() != null && ConfigProps.RERUN_ON_FAILURE) {
			TestListener testRetryAnalyzer = (TestListener) result.getMethod().getRetryAnalyzer();
			if (testRetryAnalyzer.getCount(result.getMethod(), result.getAttribute(RUN_PROPS)).intValue() > 0) {
				result.setStatus(ITestResult.FAILURE);
			} else {
				failedCases.addResult(result, result.getMethod());
			}
		}
		TestIDs.addFailedTest(TestIDs.getTestId());
	}

	@Override
	public void onTestSkipped(ITestResult iTestResult) {
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {
	}

	@Override
	public void onStart(ITestContext iTestContext) {
	}

	@Override
	public void onFinish(ITestContext iTestContext) {
	}

	@Override
	public boolean retry(ITestResult result) {
		boolean retry = false;
		if (ConfigProps.RERUN_ON_FAILURE) {
			if (getCount(result.getMethod(), result.getAttribute(RUN_PROPS)).intValue() > 0) {
				Logger.logConsoleMessage("RETRY TEST: " + result.getInstanceName() + "." + result.getName());
				getCount(result.getMethod(), result.getAttribute(RUN_PROPS)).decrementAndGet();
				retry = true;
			} else {
				Logger.logConsoleMessage("RETRY COMPLETE: " + result.getInstanceName() + "." + result.getName());
			}
		}
		return retry;
	}

	private AtomicInteger getCount(ITestNGMethod result, Object attribute) {
		String id = getId(result, attribute);
		retries.putIfAbsent(id, new AtomicInteger(MAX_COUNT));
		return retries.get(id);
	}

	private String getId(ITestNGMethod result, Object attribute) {
		return result.getConstructorOrMethod().getMethod().toGenericString() + ":" + ArrayUtils.toString(attribute);
	}

	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult result) {
		IRetryAnalyzer retryAnalyzer = result.getMethod().getRetryAnalyzer();
		if (retryAnalyzer != null && result.getThrowable() != null) {
			if (result.getThrowable().getClass().equals(SkipException.class)) {
				result.setStatus(ITestResult.SKIP);
			} else if (ITestResult.SKIP == result.getStatus()) {
				result.setStatus(ITestResult.FAILURE);
			}
			Reporter.setCurrentTestResult(result);
		}
	}

}