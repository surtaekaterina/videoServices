package com.viacom.test.videoservices.model.test.types;

import java.util.HashMap;
import java.util.Map;

import com.viacom.test.videoservices.model.test.Rule;

public class EqualResponseValidatorRuleType extends Rule {

	private String pathToResponse;
	private Map<String, String> replacment;

	public EqualResponseValidatorRuleType(String pathToResponse) {
		this.pathToResponse = pathToResponse;
	}
	
	public EqualResponseValidatorRuleType(String pathToResponse, Map<String, String> replacment) {
		this(pathToResponse);
		this.replacment = replacment;
	}

	public String getPathToResponse() {
		return pathToResponse;
	}

	public void setPathToResponse(String pathToResponse) {
		this.pathToResponse = pathToResponse;
	}

	public Map<String, String> getReplacment() {
		if (null == replacment) {
			this.replacment = new HashMap<>();
		}
		return this.replacment;
	}

	public void setReplacment(Map<String, String> replacment) {
		this.replacment = replacment;
	}
	
	
	
	
}
