package com.viacom.test.videoservices.tests.deliveryservice.phase2;

import com.google.common.collect.ImmutableList;
import com.viacom.test.videoservices.model.test.Validators;
import com.viacom.test.videoservices.model.test.types.ContextExtractorParameterType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.HeaderValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.JsonPathValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.StatusLineValidatorRuleType;
import com.viacom.test.videoservices.model.test.types.TestType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleNameType;
import com.viacom.test.videoservices.model.test.types.TextValidatorRuleType;
import com.viacom.test.videoservices.tests.AbstractBaseTest;
import com.viacom.test.videoservices.utils.app.DeliveryServiceUtils;
import com.viacom.test.videoservices.utils.app.StaticPackagerUtils;
import com.viacom.test.videoservices.utils.app.VideoUrlP2;
import com.viacom.test.videoservices.utils.wait.FluentWait;
import com.viacom.test.videoservices.utils.wait.predicate.impl.WaitForValidatorsPredicateImpl;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;

import java.util.UUID;

import static com.google.common.collect.ImmutableList.of;
import static com.viacom.test.videoservices.constants.HeaderConstants.ACCESS_CONTROL_ALLOW_ORIGIN;
import static com.viacom.test.videoservices.constants.HeaderConstants.CONTENT_TYPE;
import static com.viacom.test.videoservices.model.test.types.HttpMethodNameType.POST;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY;
import static com.viacom.test.videoservices.utils.IProps.GroupProps.DELIVERY_2;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.Account.DLVR_CDN_TEST1_ACCOUNT;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.CDN.DEFAULT_CDN;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.defineTShost;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getMediaPlaylistLink;
import static com.viacom.test.videoservices.utils.app.DeliveryServiceUtils.getPlaylistLink;
import static com.viacom.test.videoservices.utils.app.HostManager.getProxy2Host;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.CAPTIONS;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.SUBTITLES;
import static com.viacom.test.videoservices.utils.app.VideoUrl.PackageType.VIDEO_AUDIO;
import static java.util.concurrent.TimeUnit.SECONDS;
import static ru.yandex.qatools.allure.model.SeverityLevel.BLOCKER;

public class Phase2CaptionsSubtitlesTest extends AbstractBaseTest {

    private static final String ACCOUNT_AND_CDN = "account=" + DLVR_CDN_TEST1_ACCOUNT + "&cdn=" + DEFAULT_CDN;

    private static final String MEDIA_URL_QUERY_PARAMETERS = "\\?tk=st=.*&" + ACCOUNT_AND_CDN;

    private String TEST_NAME = "Phase2CaptionsSubtitlestest/" + UUID.randomUUID();

    private VideoUrlP2 videoUrl_10 = new VideoUrlP2.Builder().setDefaultNamespaceAndUploadPath(TEST_NAME + "/1")
            .setFileName("384x216_278_30sec.mp4").setResolution("384x216").setPackageTypes(VIDEO_AUDIO)
            .setHashcode("3469779259").setBitrate("403063").build();

    private VideoUrlP2 videoUrl_10_C = new VideoUrlP2.Builder().setDefaultNamespaceAndUploadPath(TEST_NAME + "/1")
            .setFileName("captions2.vtt").setResolution("384x216").setHashcode("3117149298").setPackageTypes(CAPTIONS)
            .setReferenceVideo(videoUrl_10, null).build();

    private VideoUrlP2 videoUrl_10_S = new VideoUrlP2.Builder().setDefaultNamespaceAndUploadPath(TEST_NAME + "/1")
            .setFileName("captions1.vtt").setResolution("384x216").setHashcode("3579110321").setPackageTypes(SUBTITLES)
            .setReferenceVideo(videoUrl_10, null).build();

    private VideoUrlP2 videoUrl_11 = new VideoUrlP2.Builder().setDefaultNamespaceAndUploadPath(TEST_NAME + "/2")
            .setFileName("384x216_2014_2streams_Baseline_15.mp4").setResolution("384x216").setPackageTypes(VIDEO_AUDIO)
            .setBitrate("194055").setHashcode("2607552757").setLanguageCode("de").build();

    private VideoUrlP2 videoUrl_11_C = new VideoUrlP2.Builder().setDefaultNamespaceAndUploadPath(TEST_NAME + "/2")
            .setFileName("captions2.vtt").setResolution("384x216").setHashcode("3117149298").setPackageTypes(CAPTIONS)
            .setReferenceVideo(videoUrl_11, "de").setLanguageCode("de").build();

    private VideoUrlP2 videoUrl_11_S = new VideoUrlP2.Builder().setDefaultNamespaceAndUploadPath(TEST_NAME + "/2")
            .setFileName("captions1.vtt").setResolution("384x216").setHashcode("3579110321").setPackageTypes(SUBTITLES)
            .setReferenceVideo(videoUrl_11, "de").setLanguageCode("de").build();

    @AfterClass(alwaysRun = true)
    public void delete() {
        StaticPackagerUtils.deleteFromNSandDB(videoUrl_10, videoUrl_10_C, videoUrl_10_S, videoUrl_11, videoUrl_11_C, videoUrl_11_S);
    }

    @Features(DELIVERY)
    @BeforeClass(alwaysRun = true)
    public void packageVideosForPhase2CaptionsSubtitlesTest() {
        Validators addMsgV = new Validators();

        addMsgV.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        addMsgV.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, "Content-Type", "application/json"));
        addMsgV.add(new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.EQUALS, "$.success", "true"));

        TestType test = new TestType();
        test.setHttpMethod(POST);

        test.setUrl(getProxy2Host() + "proxy/addMessages");
        test.setPostbody(VideoUrlP2.postBodyProxyAddMessage(videoUrl_10, videoUrl_11));

        testRequest(test, addMsgV.getAll());

        test.setUrl(getProxy2Host() + "proxy/checkService");
        test.setPostbody(VideoUrlP2.postBodyProxyCheckService(videoUrl_10, videoUrl_11));

        FluentWait.create().withTimeout(180, SECONDS).pollingEvery(3, SECONDS).until(new WaitForValidatorsPredicateImpl
                (test, new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.CONTAINS, "$.renditions.length()", "2")));

        test.setUrl(getProxy2Host() + "proxy/addMessages");
        test.setPostbody(VideoUrlP2.postBodyProxyAddMessage(videoUrl_10_C, videoUrl_10_S, videoUrl_11_S, videoUrl_11_C));

        testRequest(test, addMsgV.getAll());

        test.setUrl(getProxy2Host() + "proxy/checkService");
        test.setPostbody(VideoUrlP2.postBodyProxyCheckService(videoUrl_10_C, videoUrl_10_S, videoUrl_11_S, videoUrl_11_C));

        FluentWait.create().withTimeout(60, SECONDS).pollingEvery(3, SECONDS).until(new WaitForValidatorsPredicateImpl
                (test, new JsonPathValidatorRuleType(JsonPathValidatorRuleNameType.CONTAINS, "$.renditions.length()", "4")));
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2})
    public void checkMasterPhase2CaptionsSubtitlesTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(DeliveryServiceUtils.getMasterPlaylistPathPhase2("gsp.pkgtest/" + TEST_NAME, ",1/0/video/stream_384x216_403063_3469779259,1/0/audio/default_3469779259,1/0/captions/subtitles_default_3117149298,1/0/captions/subtitles_default_3579110321,2/0/captions/subtitles_de_3117149298,2/0/captions/subtitles_de_3579110321"));
        test.addParameter("account", DLVR_CDN_TEST1_ACCOUNT);

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "## Created by Viacom Delivery Service"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, ("#EXT-X-STREAM-INF:BANDWIDTH=1194768,AVERAGE-BANDWIDTH=483207,CODECS=\"avc1.64000d,mp4a.40.2\",RESOLUTION=384x216,AUDIO=\"audio\",NAME=\"default\",LANGUAGE=\"en\",FRAME-RATE=29.97")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*" + getMediaPlaylistLink(videoUrl_10).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"audio\",LANGUAGE=\"en\",NAME=\"default\",AUTOSELECT=YES,CHANNELS=\"2\",DEFAULT=YES,URI=\"" + getPlaylistLink(videoUrl_10.getAudioStreamUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID=\"text\",NAME=\"de\",AUTOSELECT=YES,CHARACTERISTICS=\"public.accessibility.transcribes-spoken-dialog\",LANGUAGE=\"de\",URI=\"" + getPlaylistLink(videoUrl_11_S.getCaptionsUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID=\"text\",NAME=\"de\",AUTOSELECT=YES,CHARACTERISTICS=\"public.accessibility.transcribes-spoken-dialog, public.accessibility.describes-music-and-sound\",LANGUAGE=\"de\",URI=\"" + getPlaylistLink(videoUrl_11_C.getCaptionsUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID=\"text\",NAME=\"default\",AUTOSELECT=YES,CHARACTERISTICS=\"public.accessibility.transcribes-spoken-dialog\",LANGUAGE=\"en\",URI=\"" + getPlaylistLink(videoUrl_10_S.getCaptionsUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.MATCH, ("[\\s\\S]*#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID=\"text\",NAME=\"default\",AUTOSELECT=YES,CHARACTERISTICS=\"public.accessibility.transcribes-spoken-dialog, public.accessibility.describes-music-and-sound\",LANGUAGE=\"en\",URI=\"" + getPlaylistLink(videoUrl_10_C.getCaptionsUploadPath()).replace("/", "\\/") + MEDIA_URL_QUERY_PARAMETERS + "[\\s\\S]*")));

        ContextExtractorParameterType e3 = new ContextExtractorParameterType();
        e3.setName("captions_1");
        e3.setRegex(getPlaylistLink(videoUrl_10_C.getCaptionsUploadPath()) + ".*(?=\")");

        ContextExtractorParameterType e4 = new ContextExtractorParameterType();
        e4.setName("subtitles_1");
        e4.setRegex(getPlaylistLink(videoUrl_10_S.getCaptionsUploadPath()) + ".*(?=\")");

        test.setContextextractor(getContextExtractors(of(e3, e4)));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkMasterPhase2CaptionsSubtitlesTest")
    public void checkPhase2CaptionsPlaylistTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("captions_1"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-PLAYLIST-TYPE:VOD"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-MEDIA-SEQUENCE:0"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTINF:60.000000,"));

        for (int i = 0; i < 3; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_10_C.getCaptionSegmentUploadPathByIndex(i)));
        }

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-ENDLIST"));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkMasterPhase2CaptionsSubtitlesTest")
    public void checkPhase2CaptionSegmentsTest() {

        Validators v = new Validators();
        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "text/vtt"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        Validators v1 = new Validators();
        Validators v3 = new Validators();

        v1.add(new TextValidatorRuleType(TextValidatorRuleNameType.STARTS_WITH, "WEBVTT\nX-TIMESTAMP-MAP=LOCAL:00:00:00.000,MPEGTS:178200\n" +
                "\n00:00:00.968 --> 00:00:03.670 size:100% position:85% align:end line:10%\n<b>♪♪</b>"));
        v1.add(new TextValidatorRuleType(TextValidatorRuleNameType.ENDS_WITH, "00:00:58.559 --> 00:01:00.194 position:15% align:start\n" +
                "<b>'cause they was innocent</b>\n" +
                "<b>on that (bleep),</b>"));

        v3.add(new TextValidatorRuleType(TextValidatorRuleNameType.STARTS_WITH, "WEBVTT\nX-TIMESTAMP-MAP=LOCAL:00:00:00.000,MPEGTS:178200\n" +
                "\n00:01:57.885 --> 00:02:00.687\n<b>I'm there every step of</b>\n<b>the way with you, bro.</b>"));
        v3.add(new TextValidatorRuleType(TextValidatorRuleNameType.ENDS_WITH, "00:02:03.690 --> 00:02:07.060 position:15% align:start\n" +
                "<b>(bleep) ain't fair</b>\n<b>at all, bro.</b>"));

        ImmutableList.of(v1, v3).forEach(va -> va.add(v));

        TestType test = new TestType();
        test.setUrl(defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_10_C.getCaptionSegmentUploadPathByIndex(0));
        testRequest(test, v1.getAll());

        test = new TestType();
        test.setUrl(defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_10_C.getCaptionSegmentUploadPathByIndex(2));
        testRequest(test, v3.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkMasterPhase2CaptionsSubtitlesTest")
    public void checkPhase2SubtitlesPlaylistTest() {
        TestType test = new TestType();
        Validators v = new Validators();

        test.setUrl(testContext.getValueFromContext("subtitles_1"));

        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));

        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "application/vnd.apple.mpegurl"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTM3U"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-VERSION:4"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-PLAYLIST-TYPE:VOD"));
        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-MEDIA-SEQUENCE:0"));

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXTINF:60.000000,"));

        for (int i = 0; i < 3; i++) {
            v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_10_S.getCaptionSegmentUploadPathByIndex(i)));
        }

        v.add(new TextValidatorRuleType(TextValidatorRuleNameType.CONTAINS, "#EXT-X-ENDLIST"));

        testRequest(test, v.getAll());
    }

    @Features(DELIVERY)
    @Severity(BLOCKER)
    @TestCaseId("")
    @Test(groups = {DELIVERY_2}, dependsOnMethods = "checkMasterPhase2CaptionsSubtitlesTest")
    public void checkPhase2SubtitlseSegmentsTest() {

        Validators v = new Validators();
        v.add(new StatusLineValidatorRuleType("200", "OK", "HTTP"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.CONTAINS, CONTENT_TYPE, "text/vtt"));
        v.add(new HeaderValidatorRuleType(HeaderValidatorRuleNameType.EXIST, ACCESS_CONTROL_ALLOW_ORIGIN, "*"));

        Validators v1 = new Validators();
        Validators v2 = new Validators();

        v1.add(new TextValidatorRuleType(TextValidatorRuleNameType.STARTS_WITH, "WEBVTT\nX-TIMESTAMP-MAP=LOCAL:00:00:00.000,MPEGTS:178200\n" +
                "\n1\n00:00:02.601 --> 00:00:13.133\nTest Captions"));
        v1.add(new TextValidatorRuleType(TextValidatorRuleNameType.ENDS_WITH, "6\n00:00:53.501 --> 00:01:03.167\n" +
                "(CC1)EIA-608 table 5\nExtended Character Set -Spanish:\nÁÉÓÚÜü‘¡"));

        v2.add(new TextValidatorRuleType(TextValidatorRuleNameType.STARTS_WITH, "WEBVTT\nX-TIMESTAMP-MAP=LOCAL:00:00:00.000,MPEGTS:178200\n" +
                "\n106\n00:03:59.667 --> 00:04:02.000\n(CC1) Demonstration of"));
        v2.add(new TextValidatorRuleType(TextValidatorRuleNameType.ENDS_WITH, "115\n00:04:19.000 --> 00:04:28.000\n" +
                "End of Test\nCaption file courtesy of\nDTV Access Project, WGBH-NCAM"));

        ImmutableList.of(v1, v2).forEach(va -> va.add(v));

        TestType test = new TestType();
        test.setUrl(defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_10_S.getCaptionSegmentUploadPathByIndex(0));
        testRequest(test, v1.getAll());

        test = new TestType();
        test.setUrl(defineTShost(DEFAULT_CDN, DLVR_CDN_TEST1_ACCOUNT) + videoUrl_10_S.getCaptionSegmentUploadPathByIndex(4));
        testRequest(test, v2.getAll());

    }
}
