package com.viacom.test.videoservices.model.test.types;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum ByteValidatorRuleNameType {

    @XmlEnumValue("equals")
    EQUALS("equals");

    private final String value;

    ByteValidatorRuleNameType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ByteValidatorRuleNameType fromValue(String v) {
        for (ByteValidatorRuleNameType c : ByteValidatorRuleNameType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v.toString());
    }
}
